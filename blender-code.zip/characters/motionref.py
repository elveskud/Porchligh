# Motion reference: one short clip per move in motion.py, plus a contact sheet and a combined reel.
#   Blender --background --python motionref.py             -> refs/motion/<move>.mp4, motion_sheet.png, motion_reel.mp4
#   ONLY=take,cheer Blender --background --python motionref.py
import os, sys, subprocess, shutil
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from toon import *
import cast, props, locations, motion

OUT = os.path.join(HERE, "refs", "motion")
os.makedirs(OUT, exist_ok=True)
ONLY = set(filter(None, os.environ.get("ONLY", "").split(",")))
VOICES = os.path.join(HERE, "refs", "voices")


def ffmpeg(*args):
    subprocess.run(["ffmpeg", "-v", "error", "-y", *args], check=True)


def label(cam, body, sub, ortho, h_px):
    k = (ortho / h_px) / (7.5 / 600)
    bar = empty("lbl", cam, (0, -ortho / 2 + 0.55 * k), -10)
    bar.scale = (k, k, 1)
    shape("lbl_bg", rect(-30, -0.55, 30, 0.55), OFFBLACK, bar, 0.0, ol=0, smooth=0)
    text("lbl_t", body, 0.5, ORANGE, bar, (0, 0.12), 0.01)
    text("lbl_s", sub, 0.3, CHALK, bar, (0, -0.3), 0.01, font="Nunito-Variable.ttf")


def stage(sc):
    shape("floor", rect(-40, -3, 40, 0), "#E8E0D2", None, -5, ol=0, smooth=0)
    stroke("floor_line", [(-40, 0), (40, 0)], 0.06, "#CFC6B6", None, -4.9)


# each clip: (name, call shown on screen, frames, w, h, build(sc) -> (camera framing, audio or None))
def c_idle(sc):
    stage(sc); c = cast.riot(); a = motion.Anim(c); a.bake(0, 89)
    return (0.4, 6.3, 14), None

def c_take(sc):
    stage(sc); c = cast.riot(); a = motion.Anim(c); motion.take(a, 14); a.bake(0, 59)
    return (0.4, 6.8, 15), None

def c_double_take(sc):
    stage(sc); c = cast.riot(); a = motion.Anim(c); motion.double_take(a, 8, 1.0); a.bake(0, 74)
    return (0.4, 6.8, 15), None

def c_laugh(sc):
    stage(sc); c = cast.riot(); a = motion.Anim(c); motion.laugh(a, 10, 66); a.bake(0, 79)
    return (0.4, 6.5, 14), None

def c_nervous(sc):
    stage(sc); c = cast.bunny(); set_visible(c.extras["sweat"], False)
    a = motion.Anim(c); motion.nervous(a, 8, 80); a.bake(0, 89)
    return (0.2, 6.8, 15), None

def c_yell(sc):
    stage(sc); c = cast.bear(); a = motion.Anim(c); motion.yell(a, 8, 60, side=1); a.bake(0, 69)
    return (0.8, 6.3, 15), None

def c_wave(sc):
    stage(sc); c = cast.riot(); a = motion.Anim(c); motion.wave(a, 8, 62); a.bake(0, 69)
    return (0.4, 6.5, 15), None

def c_cheer(sc):
    stage(sc); c = cast.riot(); a = motion.Anim(c); motion.cheer(a, 8, 18); a.bake(0, 79)
    return (0.4, 7.4, 16), None

def c_point(sc):
    stage(sc); c = cast.raccoon(); a = motion.Anim(c); motion.point_at(a, 10, 1, 30); a.bake(0, 59)
    return (1.2, 6.3, 15), None

def c_facepalm(sc):
    stage(sc); c = cast.riot(); a = motion.Anim(c); motion.facepalm(a, 10, 30); a.bake(0, 59)
    return (0.4, 6.5, 14), None

def c_shrug(sc):
    stage(sc); c = cast.raccoon(); a = motion.Anim(c); motion.shrug(a, 10, 24); a.bake(0, 54)
    return (0.4, 6.3, 15), None

def c_hop(sc):
    stage(sc); c = cast.bunny(); set_visible(c.extras["sweat"], False)
    a = motion.Anim(c); a.expr(0, "happy"); motion.hop(a, 8); motion.hop(a, 30); a.bake(0, 59)
    return (0.2, 7.0, 15), None

def c_talk(sc):
    stage(sc); c = cast.riot(); a = motion.Anim(c)
    wav = os.path.join(VOICES, "riot.wav")
    line = "Hey, I'm Riot! Grab your friends, it's game night."
    n = motion.talk(a, 8, wav, text=line)
    a.bake(0, n + 28)
    props.word_captions("cap", sc.camera, motion.word_times(line, wav), 8, ortho=13, y_px=1250)
    return (0.4, 6.8, 13), (wav, 8), n + 29

def c_look(sc):
    stage(sc)
    r, p = cast.riot(), cast.bunny()
    r.root.location.x, p.root.location.x = -3.2, 3.2
    set_visible(p.extras["sweat"], False)
    ar, ap = motion.Anim(r), motion.Anim(p)
    ar.look(10, 1.0, 6); ap.look(16, -1.0, 6)
    ar.expr(10, "cocky"); ap.expr(22, "nervous")
    ar.look(50, 0.0, 8); ap.look(54, 0.0, 8)
    ar.bake(0, 69); ap.bake(0, 69)
    return (0.3, 6.6, 19), None

def c_props(sc):
    sc.display.shading.background_color = (lin(0xF5 / 255), lin(0xF0 / 255), lin(0xE8 / 255))
    card = props.prompt_card("card", "dare", "Do 20 jumping jacks without stopping.", (0, 14.5), 1, w=10)
    bub = props.speech_bubble("bub", "NO WAY!", (-2.6, 8.6), 2, tail=(1.2, -2.0), color=RED)
    st = props.stamp("st", "DARE ACCEPTED", (0, 4.6), 3)
    em = props.emote("em", "exclaim", (3.6, 8.4), 3, 1.2)
    cf = props.confetti("cf", (0, 9), 4, spread=4)
    pf = props.puff("pf", (3.0, 1.0), 3)
    for o in (card, bub, st, em, pf):
        set_visible(o, False, 0)
    motion.card_flip_in(card, 6)
    motion.pop_in(bub, 24)
    motion.pop_in(em, 30)
    motion.float_up(em, 36, 64)
    motion.slam_in(st, 44)
    motion.burst(cf, 50)
    motion.puff_out(pf, 70)
    cam = motion.CamAnim(sc.camera, (0, 9.5, 22))
    cam.shake(44, 12, 0.35)
    cam.bake(0, 89)
    return None, None

def c_camera(sc):
    loc = locations.campfire()
    for fn, i in ((cast.bear, 0), (cast.bunny, 1), (cast.riot, 2), (cast.raccoon, 3)):
        c = fn()
        loc.seat(c, i)
        if fn is cast.bunny:
            set_visible(c.extras["sweat"], False)
        motion.Anim(c).bake(0, 89)
    motion.flicker(loc.extras["flames"], 0, 89, 0.1)
    cam = motion.CamAnim(sc.camera, loc.cam)
    cam.push(10, 34, (loc.seats[2][0], 8.6, 12))
    cam.shake(46, 14, 0.45)
    cam.push(60, 80, loc.cam, "out")
    cam.bake(0, 89)
    return None, None


CLIPS = [
    ("idle", "Anim(c) · automatic", "breathing, blinks, tail sway, ear twitches", 90, 720, 720, c_idle),
    ("talk", "talk(a, frame, wav, text) + word_captions", "Rhubarb mouth shapes, head bobs, word-by-word captions", 0, 720, 720, c_talk),
    ("look", "a.look(frame, t)", "head turns: characters face each other", 70, 720, 720, c_look),
    ("take", "take(a, frame, 'shocked')", "squash > stretch + pop > land > wobble", 60, 720, 720, c_take),
    ("double_take", "double_take(a, frame, toward)", "glance, away, freeze... snap back", 75, 720, 720, c_double_take),
    ("laugh", "laugh(a, f0, f1)", "bouncing belly laugh, paws on belly", 80, 720, 720, c_laugh),
    ("nervous", "nervous(a, f0, f1)", "shrink, shiver, darting eyes, sweat", 90, 720, 720, c_nervous),
    ("yell", "yell(a, f0, f1, side)", "puff up, lean in, head shake, jab", 70, 720, 720, c_yell),
    ("wave", "wave(a, f0, f1)", "overshoot up, 2.5Hz wave, head tilt", 70, 720, 720, c_wave),
    ("cheer", "cheer(a, frame)", "crouch > jump > hang > land squash", 80, 720, 720, c_cheer),
    ("point", "point_at(a, frame, side)", "wind-up > snap with overshoot > hold", 60, 720, 720, c_point),
    ("facepalm", "facepalm(a, frame)", "paw to face, head sinks, recover", 60, 720, 720, c_facepalm),
    ("shrug", "shrug(a, frame)", "arms flick out, shoulders up, tilt", 55, 720, 720, c_shrug),
    ("hop", "hop(a, frame)", "squash on take-off and landing", 60, 720, 720, c_hop),
    ("props", "prop moves", "card_flip_in · pop_in · float_up · slam_in · burst · puff_out", 90, 540, 960, c_props),
    ("camera", "CamAnim", "push-in · shake · pull back · fire flicker", 90, 540, 960, c_camera),
]

made = []
for name, call, sub, n, w, h, build in CLIPS:
    if ONLY and name not in ONLY:
        continue
    sc = reset()
    setup_render(sc, w, h)
    cam = camera(sc, 0, 7, 14)
    res = build(sc)
    frame, audio = res[:2]
    n = res[2] if len(res) > 2 else n
    if frame:
        cam.location.x, cam.location.y = frame[0], frame[1]
        cam.data.ortho_scale = frame[2]
    label(cam, call, sub, cam.data.ortho_scale if h >= w else cam.data.ortho_scale * h / w, h)
    sc.frame_start, sc.frame_end = 0, n - 1
    fdir = os.path.join(OUT, "frames", name)
    shutil.rmtree(fdir, ignore_errors=True)
    sc.render.filepath = os.path.join(fdir, "f_")
    bpy.ops.render.render(animation=True)
    mp4 = os.path.join(OUT, f"{name}.mp4")
    if audio:
        wav, start = audio
        ffmpeg("-framerate", "30", "-i", os.path.join(fdir, "f_%04d.png"), "-i", wav, "-filter_complex",
               f"[1]adelay={int(start / 30 * 1000)}|{int(start / 30 * 1000)},apad[a]", "-map", "0:v", "-map", "[a]",
               "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18", "-c:a", "aac", "-shortest", mp4)
    else:
        ffmpeg("-framerate", "30", "-i", os.path.join(fdir, "f_%04d.png"), "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18", mp4)
    # contact strip: 6 frames across the clip
    picks = [round(i * (n - 1) / 5) for i in range(6)]
    sel = "+".join(f"eq(n\\,{p})" for p in picks)
    ffmpeg("-i", mp4, "-vf", f"select='{sel}',scale=-2:300,tile=6x1", "-frames:v", "1", os.path.join(OUT, f"{name}_strip.png"))
    shutil.rmtree(fdir, ignore_errors=True)
    made.append(name)

# sheet + reel from every clip that exists
names = [c[0] for c in CLIPS if os.path.exists(os.path.join(OUT, f"{c[0]}.mp4"))]
ins = []
for nm in names:
    ins += ["-i", os.path.join(OUT, f"{nm}_strip.png")]
ffmpeg(*ins, "-filter_complex", "".join(f"[{i}]scale=1800:-2,pad=1800:ih+8:0:0:0x121212[s{i}];" for i in range(len(names)))
       + "".join(f"[s{i}]" for i in range(len(names))) + f"vstack={len(names)}", os.path.join(OUT, "motion_sheet.png"))
parts, filt = [], ""
for i, nm in enumerate(names):
    parts += ["-i", os.path.join(OUT, f"{nm}.mp4")]
    filt += f"[{i}:v]scale=720:720:force_original_aspect_ratio=decrease,pad=720:720:(ow-iw)/2:(oh-ih)/2:color=0xF5F0E8,setsar=1,fps=30[v{i}];"
filt += "".join(f"[v{i}]" for i in range(len(names))) + f"concat=n={len(names)}:v=1:a=0[v]"
ffmpeg(*parts, "-filter_complex", filt, "-map", "[v]", "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "20", os.path.join(OUT, "motion_reel.mp4"))
print("MOTION DONE", made)
