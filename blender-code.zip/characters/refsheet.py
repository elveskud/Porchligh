# Character reference sheets (model sheets), rendered piece by piece and stitched with ffmpeg:
#   header · body + 8 expressions · head turns · 8 poses · lip-sync mouths · palette -> refs/<name>_sheet.png
#   Riot's costumes side by side                                              -> refs/riot_costumes.png
#   the cast line-up with names                                               -> refs/lineup.png
# Run:  Blender --background --python refsheet.py      (ONLY=pip to redo one character)
import os, sys, subprocess
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from toon import *
import cast

REFS = os.path.join(HERE, "refs")
PARTS = os.path.join(REFS, "parts")
os.makedirs(PARTS, exist_ok=True)
ONLY = os.environ.get("ONLY")

SHEETS = [
    ("riot", cast.riot, {}, "RIOT", "Main character · the host · cocky, hyped, never mean"),
    ("riot_mafia", cast.riot, {"costume": "mafia"}, "RIOT · MAFIA", "Mafia costume · pinstripes, fedora, round shades"),
    ("bash", cast.bear, {}, "BASH", "The loud one · accuses everyone, first to get voted out"),
    ("pip", cast.bunny, {}, "PIP", "The nervous one · always sweating, always innocent"),
    ("rocco", cast.raccoon, {}, "ROCCO", "The snacker · never stops eating, never notices anything"),
]
EXPRS = ["hype", "cocky", "drumroll", "shocked", "laughing", "suspicious", "nervous", "yelling"]
POSES = ["point", "wave", "cheer", "thumbs", "shrug", "crossed", "facepalm", "explain"]
TURNS = [(-1.0, "LOOK LEFT"), (-0.5, "3/4 LEFT"), (0.5, "3/4 RIGHT"), (1.0, "LOOK RIGHT")]
VISEMES = [("vA", "A · M B P"), ("vB", "B · K S T"), ("vC", "C · EH AE"), ("vD", "D · AA"),
           ("vE", "E · AO ER"), ("vF", "F · OO W"), ("vG", "G · F V"), ("vH", "H · L")]
COSTUMES = [("hoodie", "DEFAULT"), ("mafia", "MAFIA"), ("dare", "TRUTH OR DARE"), ("coach", "ALIAS"), ("host", "TRIVIA")]


def ffmpeg(*args):
    subprocess.run(["ffmpeg", "-v", "error", "-y", *args], check=True)


def cam_label(cam, ortho, aspect, h=600):
    k = (ortho / h) / (7.5 / 600)  # same on-screen size whatever the zoom / resolution
    bar = empty("lbl", cam, (0, -ortho / 2 + 0.42 * k), -10)
    bar.scale = (k, k, 1)
    shape("lbl_bg", rect(-3.75 * aspect * 2, -0.42, 3.75 * aspect * 2, 0.42), OFFBLACK, bar, 0.0, ol=0, smooth=0)
    return text("lbl_t", "", 0.5, CHALK, bar, (0, -0.02), 0.01)


def header(x0, title, sub):
    g = empty("hdr", None, (x0, 0), 0)
    shape("hdr_bg", rect(-12, -1, 12, 1), OFFBLACK, g, 0.0, ol=0, smooth=0)
    shape("hdr_bar", rect(-12, -1, -11.75, 1), ORANGE, g, 0.01, ol=0, smooth=0)
    text("hdr_t", title, 1.0, ORANGE, g, (-11.2, 0.05), 0.02, align="LEFT")
    text("hdr_s", sub, 0.5, CHALK, g, (11.3, 0.0), 0.02, align="RIGHT")
    text("hdr_brand", "FRIENDZY CAST", 0.32, "#8A8A99", g, (11.3, 0.62), 0.02, align="RIGHT")


def swatches(x0, palette):
    g = empty("sw", None, (x0, 0), 0)
    shape("sw_bg", rect(-12, -1.5, 12, 1.5), CHALK, g, -0.1, ol=0, smooth=0)
    n = len(palette)
    w = 24 / n
    for i, (label, hexv) in enumerate(palette):
        cx = -12 + w * (i + 0.5)
        shape(f"sw{i}", rect(cx - w / 2 + 0.35, 0.0, cx + w / 2 - 0.35, 1.15), hexv, g, 0.0, ol=0.05, smooth=0)
        text(f"sw{i}_l", label, 0.42, OFFBLACK, g, (cx, -0.45), 0.01)
        text(f"sw{i}_h", hexv.upper(), 0.36, "#6A6A78", g, (cx, -0.98), 0.01)


def render(sc, cam, x, y, ortho, w, h, path):
    sc.render.resolution_x, sc.render.resolution_y = w, h
    cam.location.x, cam.location.y = x, y
    cam.data.ortho_scale = ortho
    still(sc, path)


for key, fn, kw, title, sub in SHEETS:
    if ONLY and ONLY != key:
        continue
    sc = reset()
    setup_render(sc, 800, 1200)
    c = fn(**kw)
    default = c.current
    bpy.context.view_layer.update()
    cam = camera(sc, 0, 0, 10)
    p = lambda name: os.path.join(PARTS, f"{key}_{name}.png")

    header(-500, title, sub)
    render(sc, cam, -500, 0, 24, 2400, 200, p("header"))
    swatches(500, c.palette)
    render(sc, cam, 500, 0, 24, 2400, 300, p("swatches"))

    lbl = cam_label(cam, 14.5, 800 / 1200, 1200)
    lbl.data.body = "FRONT"
    render(sc, cam, 0.9, 5.7, 14.5, 800, 1200, p("body"))
    for ob in [lbl.parent] + list(lbl.parent.children_recursive):
        bpy.data.objects.remove(ob, do_unlink=True)

    head = c.extras["head"].matrix_world.translation
    lbl = cam_label(cam, 7.5, 400 / 600)
    for e in EXPRS:
        c.expr(e)
        if "sweat" in c.extras:
            set_visible(c.extras["sweat"], e in ("nervous", "shocked", "drumroll"))
        lbl.data.body = e.upper()
        render(sc, cam, head.x, head.y + 1.9, 7.5, 400, 600, p(e))
    for ob in [lbl.parent] + list(lbl.parent.children_recursive):
        bpy.data.objects.remove(ob, do_unlink=True)

    c.expr(default)
    lbl = cam_label(cam, 7.5, 1, 600)
    for t, name in TURNS:
        c.turn(t)
        lbl.data.body = name
        render(sc, cam, head.x, head.y + 1.9, 7.5, 600, 600, p(f"turn_{t}"))
    c.turn(0)
    for ob in [lbl.parent] + list(lbl.parent.children_recursive):
        bpy.data.objects.remove(ob, do_unlink=True)

    # lip-sync mouth chart (Rhubarb shapes)
    mouth = c.extras["head"].matrix_world @ next(m for m in c.mouths.values()).parent.location
    lbl = cam_label(cam, 3.2, 1, 300)
    for key_, name in VISEMES:
        for k, g in c.mouths.items():
            set_visible(g, k == key_)
        lbl.data.body = name
        render(sc, cam, mouth.x, mouth.y + 0.25, 3.2, 300, 300, p(f"mouth_{key_}"))
    c.expr(default)
    for ob in [lbl.parent] + list(lbl.parent.children_recursive):
        bpy.data.objects.remove(ob, do_unlink=True)

    lbl = cam_label(cam, 15.5, 1, 600)
    for ps in POSES:
        c.pose(ps)
        c.expr({"cheer": "hype", "facepalm": "nervous", "shrug": "suspicious", "wave": "happy",
                "present": "hype", "explain": "cocky"}.get(ps, default))
        lbl.data.body = ps.upper()
        render(sc, cam, 0.3, 6.6, 15.5, 600, 600, p(f"pose_{ps}"))
    c.pose("mic" if kw.get("costume") == "host" else "idle")
    c.expr(default)
    bpy.ops.wm.save_as_mainfile(filepath=os.path.join(REFS, f"{key}.blend"))

    ins = []
    names = (["header", "body"] + EXPRS + [f"turn_{t}" for t, _ in TURNS] + [f"pose_{ps}" for ps in POSES]
             + [f"mouth_{k}" for k, _ in VISEMES] + ["swatches"])
    for name in names:
        ins += ["-i", p(name)]
    ffmpeg(*ins, "-filter_complex",
           "[2][3][4][5]hstack=4[r1];[6][7][8][9]hstack=4[r2];[r1][r2]vstack[g];[1][g]hstack[top];"
           "[10][11][12][13]hstack=4[turns];[14][15][16][17]hstack=4[p1];[18][19][20][21]hstack=4[p2];"
           "[22][23][24][25][26][27][28][29]hstack=8[mouths];"
           "[0][top][turns][p1][p2][mouths][30]vstack=7", os.path.join(REFS, f"{key}_sheet.png"))

# Riot's costumes
if not ONLY or ONLY == "costumes":
    sc = reset()
    setup_render(sc, 480, 960)
    cam = camera(sc, 0, 0, 10)
    lbl = cam_label(cam, 16, 480 / 960, 960)
    for i, (cos, name) in enumerate(COSTUMES):
        c = cast.riot(costume=cos)
        c.root.location.x = i * 30
        lbl.data.body = name
        render(sc, cam, i * 30 + 0.6, 6.4, 16, 480, 960, os.path.join(PARTS, f"costume_{cos}.png"))
    header(-500, "RIOT · COSTUMES", "One costume per flagship game · the eye mask always shows")
    render(sc, cam, -500, 0, 24, 2400, 200, os.path.join(PARTS, "costumes_header.png"))
    bpy.ops.wm.save_as_mainfile(filepath=os.path.join(REFS, "riot_costumes.blend"))
    ins = []
    for cos, _ in COSTUMES:
        ins += ["-i", os.path.join(PARTS, f"costume_{cos}.png")]
    ffmpeg("-i", os.path.join(PARTS, "costumes_header.png"), *ins, "-filter_complex",
           "[1][2][3][4][5]hstack=5[row];[0][row]vstack", os.path.join(REFS, "riot_costumes.png"))

# line-up with names on the floor
if not ONLY or ONLY == "lineup":
    sc = reset()
    setup_render(sc, 2400, 1200)
    for fn, x, name in ((cast.bear, -8.6, "BASH"), (cast.bunny, -3.1, "PIP"), (cast.riot, 2.4, "RIOT"), (cast.raccoon, 8.4, "ROCCO")):
        c = fn()
        c.root.location.x = x
        text(f"lu_{name}", name, 0.8, OFFBLACK, None, (x, -0.95), 1)
    shape("lu_floor", rect(-14, -0.25, 14, -0.15), "#D8D0C0", None, -1, ol=0, smooth=0)
    for h in (4, 8, 12):
        stroke(f"lu_h{h}", [(-13.5, h), (-12.6, h)], 0.06, "#B8B0A0", None, -1)
        text(f"lu_ht{h}", f"{h}", 0.4, "#8A8A99", None, (-13.05, h + 0.35), -1)
    camera(sc, 0.0, 5.6, 28)
    still(sc, os.path.join(REFS, "lineup.png"))
    bpy.ops.wm.save_as_mainfile(filepath=os.path.join(REFS, "lineup.blend"))
