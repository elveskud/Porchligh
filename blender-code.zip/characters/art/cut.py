# Cuts the Gemini art sheets into separate transparent pieces.
#   ../../voices/.venv/bin/python cut.py riot      -> riot/parts/<sheet>_<n>.png + riot/parts/_index.png
# White background -> transparent; white areas enclosed by an outline (eye whites, teeth) stay solid.
# Pieces are found as connected shapes (small gaps merged); tiny bits and text labels are dropped by size.
import os, sys, json
import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage

HERE = os.path.dirname(os.path.abspath(__file__))
who = sys.argv[1]
SRC, OUT = os.path.join(HERE, who, "src"), os.path.join(HERE, who, "parts")
os.makedirs(OUT, exist_ok=True)
manifest = {}
thumbs = []
for fn in sorted(os.listdir(SRC)):
    if not fn.lower().endswith((".jpg", ".png")):
        continue
    sheet = os.path.splitext(fn)[0]
    rgb = np.array(Image.open(os.path.join(SRC, fn)).convert("RGB")).astype(np.int16)
    lo = rgb.min(axis=2)
    ink = lo < 232
    solid = ndimage.binary_fill_holes(ndimage.binary_closing(ink, iterations=2))
    merged = ndimage.binary_dilation(solid, iterations=5)
    labels, n = ndimage.label(merged)
    H, W = lo.shape
    for k, sl in enumerate(ndimage.find_objects(labels), 1):
        h, w = sl[0].stop - sl[0].start, sl[1].stop - sl[1].start
        area = (labels[sl] == k).sum()
        if area < H * W * 0.0006:
            continue  # specks
        bits = ndimage.label(ink[sl])[1]
        if h < H * 0.07 and bits >= 4:
            continue  # text labels: a short row of separate letters (a drawn line is one piece)
        y0, y1 = max(0, sl[0].start - 4), min(H, sl[0].stop + 4)
        x0, x1 = max(0, sl[1].start - 4), min(W, sl[1].stop + 4)
        mine = (labels[y0:y1, x0:x1] == k) & solid[y0:y1, x0:x1]
        inner = ndimage.binary_erosion(mine, iterations=2)
        soft = np.clip((240 - lo[y0:y1, x0:x1]) / 18.0, 0, 1)  # anti-aliased edge from the outline
        alpha = np.where(inner, 1.0, soft * mine)
        piece = np.dstack([rgb[y0:y1, x0:x1].astype(np.uint8), (alpha * 255).astype(np.uint8)])
        name = f"{sheet}_{len([m for m in manifest if m.startswith(sheet + '_')]):02d}"
        Image.fromarray(piece).save(os.path.join(OUT, name + ".png"))
        manifest[name] = {"src": fn, "box": [int(x0), int(y0), int(x1), int(y1)], "size": [int(x1 - x0), int(y1 - y0)]}
        thumbs.append((name, Image.fromarray(piece)))
# splits for pieces drawn in one go that the rig needs in two: name -> [(new name, top fraction, bottom fraction)]
SPLITS = json.load(open(os.path.join(HERE, who, "splits.json"))) if os.path.exists(os.path.join(HERE, who, "splits.json")) else {}
for name, parts_ in SPLITS.items():
    im = Image.open(os.path.join(OUT, name + ".png"))
    for new, t0, t1 in parts_:
        crop = im.crop((0, int(im.height * t0), im.width, int(im.height * t1)))
        crop.save(os.path.join(OUT, new + ".png"))
        manifest[new] = {"src": manifest[name]["src"], "split_of": name, "size": list(crop.size)}
        thumbs.append((new, crop))
json.dump(manifest, open(os.path.join(OUT, "_manifest.json"), "w"), indent=1)

# index sheet: every piece with its name, on a checkerboard so transparency shows
cols, cell = 8, 220
rows = (len(thumbs) + cols - 1) // cols
sheet_img = Image.new("RGB", (cols * cell, rows * (cell + 24)), (240, 236, 228))
d = ImageDraw.Draw(sheet_img)
for i, (name, im) in enumerate(thumbs):
    x, y = (i % cols) * cell, (i // cols) * (cell + 24)
    for cx in range(0, cell, 20):
        for cy in range(0, cell, 20):
            if (cx + cy) // 20 % 2:
                d.rectangle([x + cx, y + cy, x + cx + 19, y + cy + 19], fill=(222, 216, 206))
    t = im.copy()
    t.thumbnail((cell - 12, cell - 12))
    sheet_img.paste(t, (x + (cell - t.width) // 2, y + (cell - t.height) // 2), t)
    d.text((x + 4, y + cell + 4), name, fill=(20, 20, 20))
sheet_img.save(os.path.join(OUT, "_index.png"))
print(len(thumbs), "pieces")
