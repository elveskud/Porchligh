# Friendzy Cast — Reference Guide

The single source of truth for Friendzy social videos: who the characters are, how they look, sound
and move, where they hang out, and the graphics they use. Everything is generated from code, so
every video stays on-model.

## What's here

| Reference | File(s) | Made by |
|---|---|---|
| Model sheets: body, 8 expressions, head turns, 8 poses, palette | `refs/riot_sheet.png`, `riot_mafia_sheet.png`, `bash_sheet.png`, `pip_sheet.png`, `rocco_sheet.png` | `refsheet.py` |
| Riot's 5 costumes | `refs/riot_costumes.png` | `refsheet.py` |
| Cast line-up with heights | `refs/lineup.png` | `refsheet.py` |
| Graphics kit: cards, captions, bubbles, stamps, emotes, FX, end card | `refs/graphics_kit.png` | `propsheet.py` |
| Locations: empty, with cast, safe-zone guide | `refs/loc_<set>_{empty,cast,guide}.png`, `refs/locations_overview.png` | `locref.py` |
| Voice samples, one per character | `refs/voices/<name>.wav` | `../voices/speak.py samples` |
| **Motion library: a clip per move, contact sheet, reel** | `refs/motion/*.mp4`, `motion_sheet.png`, `motion_reel.mp4` | `motionref.py` |
| Editable Blender files | `refs/*.blend` | all of the above |

Code: `toon.py` (drawing toolkit) · `cast.py` (characters) · `motion.py` (moves) · `props.py` (graphics kit) · `locations.py` (sets).

**Regenerate** (Blender = `/Applications/Blender.app/Contents/MacOS/Blender`):
```bash
Blender --background --python refsheet.py      # ONLY=pip | ONLY=costumes | ONLY=lineup
Blender --background --python propsheet.py
Blender --background --python locref.py        # ONLY=car, SCALE=40 for quick previews
```

## Style rules
- Flat colours with a thick off-black outline (`#121212`, 0.09 units). No gradients, no shading, no textures.
- Front-facing cutout style. Use `c.turn()` for 3/4 looks; there are no side or back views.
- Brand palette first: Frenzy Orange `#FF6B00`, Party Red `#E8192C`, Electric Yellow `#FFD600`, Chalk `#F5F0E8`, Off-Black `#121212`.
- Fonts: **Boogaloo** for everything on screen; Nunito only for small UI labels.
- **Riot is always the main character and the only fox.** The friends support his jokes.
- **Family-friendly, always:**
  - Cartoon props only; the Mafia knife is an icon, never used on anyone.
  - No rude gestures. The pointing finger sits on the side of the paw for this reason, so never centre it.
  - Nobody is mean. The joke is the situation, never a person.

---

# Character bible

## Riot 🦊 — the host (main character)
`cast.riot(costume="hoodie" | "mafia" | "dare" | "coach" | "host")`

- **Who:** Friendzy's mascot and the host of every game night. A clever, mischievous trickster who
  lives for chaos. Cocky, hyped, quick, and never mean.
- **Plays it:** He's always one step ahead, and he's usually the twist. In Mafia he's the quiet one
  who's secretly the Mafia.
- **Voice:** slightly higher than the base voice, playful (`pitch +1.5, exaggeration 0.65`).
  Sample: `refs/voices/riot.wav`.
- **Says things like:**
  - "Let's gooo!"
  - "Ooh, tough one."
  - "No way they do this."
  - "Shhh… heh."
  - "Friendzy. Let the chaos begin."
- **Default face:** `hype`. In the `mafia` and `dare` costumes it's `cocky`.
- **Never:** sad for long, cruel, or the butt of a mean joke. When he loses, it's a big dramatic "Oof."

**Look**

| Part | Colour |
|---|---|
| Fur | `#FF6B00` |
| Muzzle, cheek fluff, tail tip, ear tufts | `#F7E6C8` |
| **Eye mask (signature, always visible)** | `#FFD600` |
| Inner ears | `#A3122A` |
| Hoodie | `#1E1E1E` with `#FF6B00` zip, piping, cuffs, hem and strings |

Key features:
- tall ears with red insides and cream tufts
- yellow eye masks that sweep up and out
- spiky cream cheek fluff and a pointed chin
- a grin that sits higher on his right
- a big tail with a jagged cream tip

He matches the app art (`riot-reference-pose`, `riot-game-mafia`).

**Costumes** (one per flagship game; `refs/riot_costumes.png`)

| Costume | Game | Look | Handles |
|---|---|---|---|
| `hoodie` | default | Black hoodie, orange zip, piping and strings | — |
| `mafia` | Mafia | Pinstripe suit `#2B2B33`, red tie, fedora, round shades | `extras["hat"]`, `extras["glasses"]` |
| `dare` | Truth or Dare | Little red devil horns | — |
| `coach` | Alias | Navy visor, whistle on an orange lanyard, clipboard | `extras["visor"]`, `extras["clipboard"]` |
| `host` | Trivia | Purple sparkle blazer `#6A3FD0`, red bow tie, gold buttons, mic | `extras["mic"]` (default pose `mic`) |

## Bash 🐻 — the loud one
`cast.bear()`

- **Who:** Big and loud, he jumps to conclusions. He accuses everyone, is wrong every time, and
  never learns.
- **Plays it:** He's the first to point and the first to get voted out. He drives on road trips,
  badly, while arguing.
- **Voice:** deep and over the top (`pitch -4, exaggeration 1.0`). Sample: `refs/voices/bash.wav`.
- **Says things like:**
  - "IT'S HIM!"
  - "I KNOW it was you!"
  - "Trust me on this one."
- **Look:** fur `#8A5A3B`, muzzle `#E2BF94`, red hoodie `#E8192C`. The widest body, with thick heavy brows.
- **Default face:** `happy`. He switches to `yelling` the moment anything happens.

## Pip 🐰 — the nervous one
`cast.bunny()`

- **Who:** Sweet, anxious and completely innocent. Pip always looks guilty and never is.
- **Plays it:** Gets accused, sweats, protests, and is right all along.
- **Voice:** high and shaky (`pitch +5, exaggeration 0.8`). Sample: `refs/voices/pip.wav`.
- **Says things like:**
  - "Wh-what?! I'm innocent!"
  - "I didn't do it, I swear!"
  - "Can we play something else?"
- **Look:**
  - Fur `#EEE8F2`, inner ears `#F6A6BF`, blush `#F7B8CB`, blue hoodie `#3D6DFF`.
  - Buck teeth, big eyes, and one floppy ear.
- **Default face:** `nervous`. Toggle the sweat drops with `set_visible(c.extras["sweat"], True/False)`.

## Rocco 🦝 — the snacker
`cast.raccoon()`

- **Who:** Chill, always eating, never paying attention. He's the deadpan comic relief, and every
  so often he's the only one who notices the truth.
- **Plays it:** Munches through everything, then delivers the punchline with his mouth full or
  drops his chips at the twist.
- **Voice:** relaxed, a touch low (`pitch -1, exaggeration 0.55`). Sample: `refs/voices/rocco.wav`.
- **Says things like:**
  - "Mm… who's him?"
  - "…YOU?!"
  - "You gonna finish those?"
- **Look:** fur `#8D8F9C`, mask `#34343E`, white `#F4F2F6`, green hoodie `#22B573`, striped tail.
- **Default face:** `happy`. Extra: `extras["chips"]`, the chip bag in his left paw.

## The Narrator (off-screen)
- The deep, dramatic game voice, used for Mafia announcements and reveals.
- Voice: `pitch -5, exaggeration 0.35`. Sample: `refs/voices/narrator.wav`.
- Example: "Night falls on the village…"

## How they work together
- Riot sets things up, or is the twist.
- Bash escalates.
- Pip panics.
- Rocco undercuts it all with a deadpan line.

Use one of them as the "target" of a prompt, and the other three react.

---

# Animation reference

## Expressions (shared by the whole cast)
`c.expr(name, frame=None)` swaps the mouth and sets the brows, pupils and eyes.

| Name | Use |
|---|---|
| `hype` | Riot's default, game start |
| `cocky` | Smug, knows something |
| `drumroll` | Gritted teeth before a reveal |
| `shocked` | Twist reveals |
| `laughing` | After a funny moment (closed `^ ^` eyes) |
| `suspicious` | Squinting at someone |
| `nervous` | Pip's default, being accused |
| `yelling` | Accusing (Bash) |
| `happy` | Neutral friendly (friends' default) |
| `side_eye_l` / `side_eye_r` | Glancing suspiciously left or right |

## Lip sync (Rhubarb + 8 mouth shapes)
`motion.talk(a, frame, wav, text=line)` runs **Rhubarb Lip Sync** on the voice. Rhubarb is in `../tools/`
and needs Rosetta, which is installed. It picks a mouth shape for every sound, using these shapes (the
mouth chart row on each model sheet):

| Shape | Sounds | Look |
|---|---|---|
| `vA` | M B P | lips pressed |
| `vB` | K S T, most consonants | teeth together, lips apart |
| `vC` | EH AE | open |
| `vD` | AA | wide open |
| `vE` | AO ER | rounded |
| `vF` | OO W | puckered |
| `vG` | F V | top teeth on the lower lip |
| `vH` | L | open, tongue up |

The rest position uses the current expression's mouth. Passing the spoken `text` makes the shapes more
accurate. Results are cached next to the wav. If Rhubarb is missing, talk() falls back to loudness-based
flapping. Head bobs follow the stressed syllables.

## Arms, elbows and hands
Arms have two parts: the upper arm turns at the shoulder and the forearm turns at the elbow. Each arm ends
in a swappable hand:

| Hand | Use |
|---|---|
| `paw` | Resting |
| `open` | Waves, shrugs, "ta-da", facepalm |
| `fist` | Cheering, nervous wringing |
| `point` | Index finger, set on the side of the paw so it never reads as rude |
| `thumbs` | Thumbs up |

- `c.arm(side, shoulder_deg, elbow=deg)` sets the angles. Angles swing outward and up from hanging down; shoulder plus elbow is where the forearm points, so 180 is straight up.
- `c.hand(side, "open")` swaps the hand.
- `c.reach(side, (x, y))` uses two-joint IK to put a hand exactly on a point; the elbow bends outward.

## Poses
`c.pose(name, frame=None)` sets the shoulder, elbow and hand for both arms.

| Pose | Notes |
|---|---|
| `idle` | Relaxed (the default) |
| `point` | Straight arm to the viewer's right, index finger |
| `wave` | Forearm up, open hand (`motion.wave` waves it from the elbow) |
| `cheer` | Both arms up, fists |
| `thumbs` | Forearm up, thumbs up |
| `shrug` | Forearms out, palms open |
| `crossed` | Forearms folded across the chest |
| `facepalm` | Open hand on the face (IK; the arm moves in front of the head) |
| `present` | "Ta-da", open palm out toward a card or prompt |
| `explain` | Forearm up, finger up |
| `mic` | Host pose, mic held up by the face |

## Cel shading and ink
- **Cel shading is automatic:** every builder calls `cast.cel(c)`.
- **Shadows:** big coloured shapes get a crescent on the lower-right, as if lit from the top-left. Shadows on light colours are warm, never grey.
- **Dark shapes** like the hoodie get a lighter rim on the lit side instead.
- **Outlines** are thicker on the shadow side, like inked lines (`toon.INK_DIR`).
- **Shape-specific:** shadows only go on that shape's own fill, so they hide and move with it.

## Head turns
`c.turn(t, frame=None)`, where `t` runs from -1 (look left) through 0 (front) to 1 (look right).
The face slides toward the side the character is looking at, the far eye narrows, and the ears
shift the other way. Use it whenever two characters talk to each other.

## Rig
- `c.root`: move or scale the whole character. Seated characters use 0.72 scale.
- `c.extras["head"]`: tilt or bob the head.
- Arms: `c.arms[±1]` (shoulder), `c.elbows[±1]`, `c.hands[±1][name]`, plus `c.arm()`, `c.hand()`, `c.reach()` and `c.ik()`.
- `c.blink(frame)`.
- Also available: `c.legs[±1]`, `c.extras["tail"]`, and `c.extras["ear±1"]` (pivots at the ear base, so ears spring), plus the costume handles above.

---

# Motion library (`motion.py`, `refs/motion/`)

Use these moves instead of hand-keying, so every video moves the same polished way.

**Reference files** (made by `motionref.py`; re-render one with `ONLY=take,cheer`):
- `refs/motion/<move>.mp4`: one clip per move
- `motion_sheet.png`: 6 frames per move
- `motion_reel.mp4`: every move back to back, about 40 seconds

```python
a = motion.Anim(riot)            # one per character; idle life is automatic
motion.take(a, 30, "shocked")    # moves start at a frame and stack with each other
motion.talk(a, 60, "vo/line.wav")
a.look(90, 1.0)                  # head turn toward the viewer's right
a.expr(95, "cocky")              # expression change (snaps over 2 frames)
a.bake(0, 150)                   # always last: keys every frame
```

**Acting controls (Oct 28 animation pass)**
- `motion.ACT` (default 1.0) scales every performance at once: talk, listen, laugh, takes, yells, points. Lower it for a calmer video.
- `"lean"` (degrees, + = toward the viewer's right) bends the torso at the hips (`HIP` = 3.2); the legs stay planted and the head stays upright for a few frames before following (overlap). Moves lean on their own: listeners toward the speaker, points and yells into it, takes away from what they see, facepalms slump, laughs rock.
- `talk()` is pose-to-pose: the head snaps to a new held tilt on each stressed syllable (the torso tilts the other way), and a free paw gestures on the strongest beats in the character's `GESTURE_STYLE` (Riot and Bash big, Pip small, Rocco almost never). A line ending in `?` ends on open palms. `gestures=False` turns them off; paws already used by a move, the phone, the mic, the clipboard or the chips are never borrowed.
- Fast vertical moves smear (stretch up to 10%) and the head drags a frame behind.
- `CamAnim.DRIFT` gives every shot a slow handheld drift, and `CamAnim.bake` calls `locations.ambient()`, which animates each set's own light: campfire flicker and rising embers, lamp breathing, village lamp buzz and dips, game-show spotlights, party-room beams sweeping across the couch.

**Automatic life (all in `Anim.bake`, nothing to call)**
- Eyes: blink on big head turns, one blink in four is a double, slow blinks on sleepy/smug/cocky, small eye darts during holds, eyes lead a head turn by ~3 frames, pupils shrink in shock/anger and widen when excited or pouting (`PUPIL_SIZE`). Sly faces raise one brow (`BROW_ASYM`).
- Head turns start with a small dip the other way (anticipation).
- Every fall that stops squashes (landing); the forearm drags behind fast shoulder swings and whips past (follow-through), and the paw stretches on the fastest frames (smear).
- Talking: a breath in before every line, the jaw drops and the mouth stretches on loud syllables, the head stretches on stressed words.
- Ears (`EAR_MOOD`) and tail (`TAIL_MOOD`: sway, speed, carriage) act with the expression; hoodie strings and Riot's tie swing; hats and visors lag the head.
- Face colour and marks (`FACE_TINT`, built by `cast.face_fx`): red face when yelling (and a little when laughing or pouting), blue dread lines when shocked, an anger vein while yelling, sparkles on switching to hype or laughing, tears after ~1 s of laughing, Zzz when sleepy.
- Quiet stretches get personality fidgets (`FIDGETS`): Riot bounces, Bash huffs, Pip glances around, Rocco eats a chip.
- Laughs have personalities: Riot's belly laugh, Bash doubles over pounding a fist, Pip giggles behind a paw, Rocco chuckles.
- Every `take()` gets a comic impact frame (yellow burst + action lines, `impact_frame=False` to skip) and the camera punches in and shakes on it (`IMPACTS`).
- Sets: wall shadows behind the cast in the living room and party room (`cast.wall_shadow`), dark out-of-focus foreground in the bottom corners of vertical wide shots (`locations.FOREGROUND`, faster parallax).
- Stickers (`Anim(idle=False)`) get none of the timed extras, so their loops stay exact.

**New expressions:** `smug`, `disgusted`, `pouting`. **New hands:** `peace`, `three`, `horns`.
**New moves:** `clap(a, f0, f1)`, `count(a, f, n=3)` (1-2-3 on the fingers), `sign(a, f, "peace"|"horns"|...)`, `rock_on(a, f)`, `gloom(a, f0, f1)` (rain cloud + slump), `impact(c, f)`. Any move can IK a paw anywhere with the `reach±1` channel `(x, y, weight, hand)`.

| Move | Call | Timing (30fps) |
|---|---|---|
| Idle life | automatic in `Anim` | Breath every 2.6s, a blink every 2–3.5s, tail sway, an ear twitch every 3–5s |
| Talk | `talk(a, frame, wav)` | Rhubarb lip sync with each mouth held at least 2 frames; a nod plus a brow flash on stressed syllables (angry faces push the brows down instead) |
| Listen | `listen(a, f0, f1, toward, beats)` | Leans toward the speaker and nods with a brow lift after each phrase end. `beats = [start + e for e in phrase_ends(wav)]`; nods are staggered per character |
| Look | `a.look(frame, t, dur=6)` | Head turn with about 7% overshoot; the body leans after it 3 frames later; use it whenever characters talk to each other |
| Take | `take(a, f, expr)` | Squash 3f → stretch and pop up 4f → fall 5f → land squash 2f → wobble settle 16f |
| Double take | `double_take(a, f, toward)` | Glance 4f → away → freeze about 0.5s → snap back with a take |
| Laugh | `laugh(a, f0, f1, beat=None)` | Bounce speed differs per character (4–7f), head rocking, paws on the belly, `^ ^` eyes. Start group laughs 4–9f apart |
| Nervous | `nervous(a, f0, f1)` | Shrinks 4%, shivers, eyes dart every 16f, sweat appears |
| Yell | `yell(a, f0, f1, side)` | Puffs up 6%, leans in, head shakes, finger jab with overshoot |
| Wave | `wave(a, f0, f1)` | Arm overshoots up, then a 2.5 Hz wave and a head tilt |
| Cheer | `cheer(a, f, hold)` | Crouch 5f → jump with arms out 8f → hang 3f → fall → land squash → settle |
| Point | `point_at(a, f, side, hold)` | Wind-up 4f (arm dips, body leans away) → snap with overshoot → hold → relax |
| Facepalm | `facepalm(a, f, hold)` | Paw to face 6f, head sinks, hold, recover 8f |
| Shrug | `shrug(a, f, hold)` | Arms flick out with overshoot, shoulders up, head tilt, smirk |
| Hop | `hop(a, f)` | A small happy hop that squashes on take-off and landing |

**Follow-through is automatic.** Ears and tail are springs: they lag behind jumps, moves, head tilts and head turns, then settle. They're capped so they flick rather than flop.

**Also automatic in `bake()`:**
- Every expression change gets a blink that hides the swap, plus a small squash and brow pop.
- Raised arms drift slowly (about 2°) through holds, so a held point or cheer never freezes.
- Brows and eye squash are keyed every frame. Squints, sleepy eyes and blinks hold correctly while heads turn.

**Prop moves:**

| Call | Use |
|---|---|
| `card_flip_in(card, f)` | The prompt reveal |
| `pop_in` / `pop_out` | Bubbles, emotes, labels; overshoot plus a small wiggle |
| `slam_in(stamp, f)` | Stamps and titles; always pair it with a camera shake |
| `float_up` | Emotes drifting away |
| `burst(confetti, f)` | Confetti |
| `puff_out` | Someone vanishes |
| `flicker(flames, f0, f1)` | Fire and glow |

**Camera:** `cam = motion.CamAnim(sc.camera, loc.cam, loc.parallax)`, then:
- `cam.intro()` first: opens slightly wide and settles in over 12f, so the hook moves from frame 0
- `cam.push(f0, f1, (x, y, ortho))` for eased moves
- `cam.cut(f, framing)`
- `cam.shake(f, dur, amp)`
- `cam.hud(captions)` keeps camera-attached overlays the same size through zooms
- `cam.bake(f0, f1)`

Far layers of each set trail the camera, which gives depth (parallax).

**Captions:**
```python
cam.hud(props.word_captions("c1", cam_obj, motion.word_times(line, wav), start_frame))
```
- 1–3 words at a time, in bold white Boogaloo with a thick outline; the current word pops in yellow.
- They sit just above the bottom safe zone and never run into the right-hand buttons.
- Word timings come from Rhubarb's voiced span and the script text.

**Quality rules:**
1. Every big action gets anticipation.
2. Every arrival overshoots and settles.
3. Hold a pose for at least 8 frames so it reads.
4. Nobody ever freezes completely, because idle keeps running.
5. Slams always come with a shake and a sound.
6. Keep the camera still while someone delivers a punchline: land the move before the line (`push(..., line - 1)`), hold, then `cut` wide after.
7. Fire confetti from above the heads (y ≈ 14.5–15) so it rains down instead of covering faces.
8. Nobody just stares: give listeners `listen()`, unless they're mid-reaction (being yelled at, called out).

---

# Graphics kit (`props.py`, `refs/graphics_kit.png`)

Built to match the app:
- **Sticker cards:** asymmetric corners, an off-black outline, a flat offset shadow and a slight tilt
  (`StickerCardModifier.swift`).
- **Category colours** from `FZColor`: wild `#FF8A3D`, funny `#E8B23D`, brain `#3F87C7`, social `#3FAE8E`.

| Call | What |
|---|---|
| `prompt_card(name, game, prompt)` | App-style prompt card. `game` is one of `truth`, `dare`, `challenge`, `mafia`, `nhie`, `wyr`, `mlt`, `hottakes`, `alias`, `trivia`, and it sets the header and category colour. Text wraps automatically. |
| `caption_box(name, text)` | Hook caption: dark box, white text. Keep it lowercase and short. |
| `speech_bubble(name, text, tail=(dx, dy))` | The tail points at the speaker's mouth |
| `stamp(name, word)` | ELIMINATED / DARE ACCEPTED / GUILTY (slam it in with scale) |
| `pill(name, text)` | Small label ("Civilian.") |
| `title(name, word)` | Big outlined slam word (MAFIA) |
| `emote(name, kind)` | Reactions: `sweat`, `anger`, `sparkle`, `question`, `exclaim`, `heart`, `zzz` |
| `timer(name, sec)` | Countdown badge (Alias) |
| `puff`, `confetti` | FX: someone vanishes, a celebration |
| `juice_box`, `phone` | Held props; the phone shows the app |
| `end_card(name, line)` | Orange end card with graffiti FRIENDZY plus one line. Leave the lower half for Riot. |

Real prompts live in the app: `Friendzy/Models/*PromptLibrary.swift` and `GamePrompt*.swift`.

---

# Locations

Built in `locations.py`. Each set is 9:16 with 4 seat anchors: `loc.seat(character, index)` sits a
character so the furniture in front hides their legs. The default framing is `camera(sc, *loc.cam)`.

| Set | Builder | Good for |
|---|---|---|
| **Game Night HQ** (day) | `living_room("day")` | Truth or Dare, Most Likely To, Would You Rather |
| **Game Night HQ** (night) | `living_room("night")` | Mafia: moonlit window, lamp off |
| **Road Trip** | `car()` | 🚗 car-friendly games, Road Trip pack |
| **Campfire** | `campfire()` | Never Have I Ever, Hot Takes, stories |
| **Trivia Night** (game-show stage) | `game_show()` | Trivia: bulb-lit TRIVIA NIGHT sign (`extras["bulbs"]`), three contestant podiums with buzzers and score screens (`extras["podiums" / "buzzers" / "screens"]`), host lectern on seat 2 for Riot (`cast.riot("host")`) |
| **Night Village** (town square) | `village_night()` | Mafia: moon, clock tower, rooftops with lit windows (`extras["windows"]`, switch them off when night falls), street lamp (`extras["glow"]`), a long bench (Riot in `cast.riot("mafia")`) |
| **Party Room** | `party_room()` | Room games (Comeback, Who Said That?, Close Call, Spy): wall TV with a ROOM CODE (`extras["tv"]`, `extras["code"]` text), disco ball (`extras["disco"]`), bunting, balloons, dance-floor tiles, long orange couch; everyone holds their own `props.phone` |

16:9: `locations.widen(loc)` works for every set except the car: it spreads the seats (`SPREAD` 5.2), swaps in longer front furniture (log, couch, bench; the podiums move with the seats), fits signs/TVs into the band above the heads and sets `loc.cam_h`. Plates: `refs/loc_<set>_wide.png`.

Plates: `refs/loc_<set>_empty.png` (the set alone), `_cast.png` (cast seated) and `_guide.png`
(numbered seats plus safe zones).

Signature props:
- **Game Night HQ:** a FRIENDZY "LET THE CHAOS BEGIN" poster, a phone showing the app (`loc.extras["phone"]`), popcorn, a juice box.
- **Road Trip:** a Riot air freshener on the mirror (`loc.extras["freshener"]`, swing it); Bash drives and Riot rides shotgun.
- **Campfire:** an orange tent, string lights, and the fire (`loc.extras["flames"]`, scale-flicker it).

Seat order:
- **Living room and campfire:** 0 to 3, left to right.
- **Car:** 0 and 1 are the back row, 2 is the front passenger (left), 3 is the driver (right).

## Safe zones (TikTok / Reels / Shorts)
On a 1080×1920 frame the app UI covers these areas. Keep faces, captions and punchlines out of them:
- **Top:** 220 px.
- **Bottom:** 440 px, for the caption and audio bar.
- **Right:** a 140 px column of buttons, from the bottom zone up to 1100 px.

Every set's default camera is nudged left so seat 3 clears the buttons. Check with `_guide.png`.

## Lighting and depth (built into every set)
Lighting is drawn with see-through overlays:
- **Game Night HQ, day:** a sunbeam through the window and a glowing lamp.
- **Game Night HQ, night:** a cool blue tint and a moonbeam.
- **Road Trip:** sunlight.
- **Campfire:** firelight washing over the cast. Animate it with `motion.flicker(loc.extras["glow"], ...)`.
- **Every set:** a soft vignette.

`loc.parallax` lists the far layers: the campfire sky and trees, the living-room back wall, and the view
through the car's rear window. `locations.drive(loc, f0, f1)` animates the road trip: trees and road
markings stream away, the cabin bumps and the air freshener swings.

---

# Voices (`../voices/`) — 100% generated

**Engines** (both local and free; licences allow commercial use):
- **Kokoro** (Apache-2.0) gives each character a *different* base voice.
- **Chatterbox** (MIT) clones that voice and acts the line with emotion.

**Base voices** (made by `make_refs.py` into `voices/refs/<who>.wav`):

| Character | Kokoro voice | Sound |
|---|---|---|
| Riot | `am_puck` | Playful |
| Bash | `am_onyx` | Deep |
| Pip | `af_sky` | Young and light |
| Rocco | `am_michael` | Laid-back |
| Narrator | `bm_george` | Dramatic British |

- **Per-character settings:** `speak.py` → `CHARACTERS` holds a small pitch offset, the exaggeration and the cfg. Don't change these per video.
- **Generating lines:** `.venv/bin/python speak.py job.json OUTDIR`, or add a named script to `SCRIPTS`. Templates do this for you.
- **Reference samples:** `refs/voices/<name>.wav`.
- **Setup gotcha:** the install needs `setuptools<81`.

# Sound kit (`../audio/sfxkit.py`) — 100% generated, nothing pre-recorded

Every sound is synthesized: filtered noise, envelopes, FM bells, synth brass and a Schroeder reverb.
Listen to them all in `refs/sounds/_sound_reel.wav`; each one is also its own file.

- **Effects:**
  - Impacts: slam, stamp, boom, crash
  - Movement: whoosh, swish, pop, card flip, slide whistle up/down, boing
  - Bright: ting, sparkle
  - Timing: tick, clock, drumroll
  - Everyday: crunch, slurp, fire, popper, tap, record scratch
- **Stings:** `dun_dun_dunnn`, `fanfare`, `sad_trombone`, `suspense`.
- **Music beds:** `bed("hype" | "suspense" | "chill", bars)` gives drums, bass and chords, and loops.
- **Mixing:** `Mix` handles timeline mixing. Music ducks under voices, effects dip slightly, and the master is set to **-14 LUFS** (the TikTok/Reels standard) with a -1 dB ceiling.

# Making a new video
Use the template engine in `../templates/`. `make.py` does voices, timing, sound, render, encode and QA in
one command. Read `../templates/WRITING.md` first: hooks, rules, prompt picking and the tracker.

For a custom one-off video:
1. **Script and beats:** the hook in the first second, 12–16 seconds, and Riot drives the twist.
2. **Voices:** generate with `speak.py` (job file).
3. **Scene:**
   - pick a set and seat the cast
   - animate with `motion.Anim` moves and `talk()`
   - add `props`
   - use `CamAnim` with parallax and the captions HUD
4. **Sound:** use `sfxkit.Mix`.
5. **QA:** run `make.py`'s checks, or at least the contact sheet with safe zones.
