# Graphics kit reference sheet: every reusable prop/graphic from props.py, labelled with the call that makes it.
#   Blender --background --python propsheet.py      -> refs/graphics_kit.png + refs/graphics_kit.blend
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from toon import *
import props

sc = reset()
setup_render(sc, 2400, 2300)


def label(t, x, y):
    text(f"lbl_{t}", t, 0.5, "#6A6A78", None, (x, y), 5, font="Nunito-Variable.ttf")


def head(t, y):
    shape(f"sec_{t}", rect(-24, y - 0.6, 24, y + 0.6), OFFBLACK, None, 4, ol=0, smooth=0)
    text(f"sec_{t}_t", t, 0.7, ORANGE, None, (-23.2, y - 0.02), 5, align="LEFT")


# header
shape("hdr_bg", rect(-24, 27, 24, 30), OFFBLACK, None, 0, ol=0, smooth=0)
shape("hdr_bar", rect(-24, 27, -23.5, 30), ORANGE, None, 1, ol=0, smooth=0)
text("hdr_t", "GRAPHICS KIT", 1.6, ORANGE, None, (-22.6, 28.5), 1, align="LEFT")
text("hdr_s", "props.py · sticker style from the app · category colours from FZColor", 0.7, CHALK, None, (22.8, 28.4), 1, align="RIGHT")

head("PROMPT CARDS  ·  props.prompt_card(name, game, prompt)", 25.3)
cards = [("dare", "Do 20 jumping jacks without stopping."),
         ("mlt", "Most likely to send a voice note that's 5 minutes long."),
         ("trivia", "Which planet has the most moons?"),
         ("nhie", "Never have I ever answered 'I'm on my way' when I hadn't even left yet.")]
for i, (game, txt) in enumerate(cards):
    x = -18 + i * 12
    props.prompt_card(f"card_{game}", game, txt, (x, 20.2), 1, w=10.2, tilt=(-3, 2, -2, 3)[i])
    label(f"'{game}'  ·  {props.GAMES[game][1]}", x, 15.6)

head("TEXT  ·  caption_box · speech_bubble · stamp · pill · title", 13.6)
props.caption_box("cap", "every friend group\nhas one", (-15.5, 9.8), 1, w=13)
label("caption_box(name, text)", -15.5, 6.9)
props.speech_bubble("bub", "IT'S HIM!!", (-1.5, 10.6), 1, tail=(-1.6, -2.3), color=RED)
label("speech_bubble(name, text, tail=)", -1.5, 6.9)
props.stamp("stamp", "DARE ACCEPTED", (11.0, 10.6), 1)
props.pill("pill", "Civilian.", (11.0, 8.2), 1)
label("stamp(name, word) · pill(name, text)", 11.0, 6.9)
props.title("ttl", "GUILTY", (20.0, 10.0), 1, size=1.9)
label("title(name, word)", 20.0, 6.9)

head("REACTIONS  ·  props.emote(name, kind)", 5.0)
for i, kind in enumerate(("sweat", "anger", "sparkle", "question", "exclaim", "heart", "zzz")):
    x = -20 + i * 5.2
    shape(f"emo_bg{i}", ell(x, 1.6, 1.7, 1.7), "#EDE6DA", None, 0, ol=0)
    props.emote(f"emo_{kind}", kind, (x - (0.4 if kind == "zzz" else 0), 1.4), 1, 1.3)
    label(kind, x, -0.9)
props.timer("tmr", 10, (17.5, 1.6), 1)
label("timer(name, sec)", 17.5, -0.9)

head("FX + PROPS  ·  puff · confetti · juice_box · phone · end_card", -2.9)
props.puff("pf", (-19.5, -7.0), 1)
label("puff(name)", -19.5, -10.4)
props.confetti("cf", (-10.5, -7.0), 1, spread=3.2)
label("confetti(name)", -10.5, -10.4)
props.juice_box("jb", None, (-3.5, -7.6), 1)
props.phone("ph", None, (-0.5, -7.2), 1, 1.3)
label("juice_box · phone", -2.0, -10.4)
ec = props.end_card("end", "Mafia · free on Friendzy", (15.0, -9.1), 1)
ec.scale = (0.36, 0.36, 1)
label("end_card(name, line)", 15.0, -14.6)

camera(sc, 0, 7.0, 48)
still(sc, os.path.join(HERE, "refs", "graphics_kit.png"))
bpy.ops.wm.save_as_mainfile(filepath=os.path.join(HERE, "refs", "graphics_kit.blend"))
