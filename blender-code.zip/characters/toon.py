# Flat 2D cutout toolkit for Friendzy cartoons (Blender Workbench, top-down ortho camera).
# Shapes are lists of control points; a point written as (x, y, "s") stays a sharp corner,
# everything else is rounded with Chaikin smoothing. Higher z draws in front.
import bpy, bmesh, math, os
from mathutils import Vector
from mathutils.geometry import tessellate_polygon

HERE = os.path.dirname(os.path.abspath(__file__))
FONTS = os.path.join(HERE, "../../Friendzy/Resources/Fonts")
OUTLINE = "#121212"
OL = 0.09  # default outline width
INK_DIR = (0.55, -0.83)  # outlines are thicker on this side (away from the top-left light), like inked lines
LIGHT = (-0.6, 0.8)      # cel light comes from the top-left
rad = math.radians

# brand palette
ORANGE, RED, YELLOW, OFFBLACK = "#FF6B00", "#E8192C", "#FFD600", "#121212"
CHALK, CHARCOAL, CORAL = "#F5F0E8", "#1E1E1E", "#FF4757"


def reset():
    bpy.ops.wm.read_factory_settings(use_empty=True)
    return bpy.context.scene


def lin(c):
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4


def mat(h, alpha=1.0):
    key = h if alpha >= 1 else f"{h}@{alpha:.3f}"
    m = bpy.data.materials.get(key)
    if not m:
        m = bpy.data.materials.new(key)
        r, g, b = (int(h[i:i + 2], 16) / 255 for i in (1, 3, 5))
        m.diffuse_color = (lin(r), lin(g), lin(b), alpha)
    return m


def link(o):
    bpy.context.scene.collection.objects.link(o)
    return o


def empty(name, parent=None, loc=(0, 0), z=0.0):
    o = link(bpy.data.objects.new(name, None))
    o.parent = parent
    o.location = (loc[0], loc[1], z)
    return o


# ---------- geometry ----------

def _split(pts):
    return [Vector((p[0], p[1])) for p in pts], [len(p) > 2 for p in pts]


def chaikin(pts, it=3, closed=True):
    v, sharp = _split(pts)
    if not closed:
        sharp[0] = sharp[-1] = True
    for _ in range(it):
        nv, ns = [], []
        n = len(v)
        for i in range(n if closed else n - 1):
            j = (i + 1) % n
            a, b = v[i], v[j]
            if sharp[i]:
                nv.append(a); ns.append(True)
            nv.append(a.lerp(b, 0.12 if sharp[i] else 0.25)); ns.append(False)
            nv.append(a.lerp(b, 0.88 if sharp[j] else 0.75)); ns.append(False)
        if not closed:
            nv.append(v[-1]); ns.append(True)
        v, sharp = nv, ns
    return [(p.x, p.y) for p in v]


def area(pts):
    n = len(pts)
    return sum(pts[i][0] * pts[(i + 1) % n][1] - pts[(i + 1) % n][0] * pts[i][1] for i in range(n)) / 2


def ccw(pts):
    return pts if area(pts) > 0 else pts[::-1]


def offset(pts, w, ink=True):
    """Outline polygon around pts; with ink=True the line swells on the shadow side (0.78x .. 1.33x)."""
    n, out = len(pts), []
    d = Vector(INK_DIR)
    for i in range(n):
        p0, p1, p2 = Vector(pts[i - 1]), Vector(pts[i]), Vector(pts[(i + 1) % n])
        e1, e2 = (p1 - p0), (p2 - p1)
        if e1.length < 1e-9 or e2.length < 1e-9:
            out.append(tuple(p1)); continue
        e1.normalize(); e2.normalize()
        n1, n2 = Vector((e1.y, -e1.x)), Vector((e2.y, -e2.x))
        m = n1 + n2
        m = n1 if m.length < 1e-6 else m.normalized()
        wi = w * (0.78 + 0.55 * max(0.0, m.dot(d))) if ink else w
        convex = e1.x * e2.y - e1.y * e2.x > 0
        if convex and m.dot(n1) < 0.7:  # sharp tip: bevel instead of a long miter spike
            out.append(tuple(p1 + n1 * wi))
            out.append(tuple(p1 + m * wi))
            out.append(tuple(p1 + n2 * wi))
        else:
            out.append(tuple(p1 + m * (wi / max(m.dot(n1), 0.7))))
    return out


def cap(poly, p, n, teeth=0, depth=0.0):
    """Part of a (smoothed) polygon on the +n side of the line through p, optionally with a
    zigzag cut edge whose teeth point back along -n (fur tips, tail flames)."""
    P = [Vector(q[:2]) for q in poly]
    p, n = Vector(p), Vector(n).normalized()
    out, cut = [], []
    for i in range(len(P)):
        a, b = P[i], P[(i + 1) % len(P)]
        da, db = (a - p).dot(n), (b - p).dot(n)
        if da >= 0:
            out.append(a); cut.append(False)
        if (da >= 0) != (db >= 0):
            out.append(a.lerp(b, da / (da - db))); cut.append(True)
    res = []
    for i, q in enumerate(out):
        res.append((q.x, q.y))
        j = (i + 1) % len(out)
        if teeth and cut[i] and cut[j]:
            for k in range(1, 2 * teeth):
                m = q.lerp(out[j], k / (2 * teeth))
                if k % 2:
                    m = m - n * depth
                res.append((m.x, m.y))
    return res


def ell(cx, cy, rx, ry, n=36, rot=0.0):
    c, s = math.cos(rot), math.sin(rot)
    out = []
    for i in range(n):
        a = 2 * math.pi * i / n
        x, y = rx * math.cos(a), ry * math.sin(a)
        out.append((cx + x * c - y * s, cy + x * s + y * c))
    return out


def rect(x0, y0, x1, y1):
    return [(x0, y0, "s"), (x1, y0, "s"), (x1, y1, "s"), (x0, y1, "s")]


def mirror(half):
    """half: right side from bottom-centre up to top-centre (x>=0)."""
    return half + [(-p[0],) + tuple(p[1:]) for p in reversed(half[1:-1])]


def mx(pts, s):
    return [(p[0] * s,) + tuple(p[1:]) for p in pts]


def move(pts, dx, dy):
    return [(p[0] + dx, p[1] + dy) + tuple(p[2:]) for p in pts]


def stroke_pts(path, w0, w1=None, it=3):
    """Closed outline polygon of a tapered brush stroke along an open path."""
    w1 = w0 if w1 is None else w1
    c = chaikin(path, it, closed=False) if len(path) > 2 else [tuple(p[:2]) for p in path]
    v = [Vector(p) for p in c]
    n = len(v)
    left, right = [], []
    for i in range(n):
        d = (v[min(i + 1, n - 1)] - v[max(i - 1, 0)]).normalized()
        nrm = Vector((-d.y, d.x))
        t = i / (n - 1)
        w = (w0 + (w1 - w0) * t) * (math.sin(math.pi * t) ** 0.35 if w0 == w1 else 1) / 2
        w = max(w, 0.012)
        left.append(v[i] + nrm * w)
        right.append(v[i] - nrm * w)
    return [tuple(p) for p in left + right[::-1]]


# ---------- objects ----------

def _mesh(name, pts, color, parent, z, alpha=1.0):
    me = bpy.data.meshes.new(name)
    verts = [Vector((x, y, 0)) for x, y in pts]
    tris = tessellate_polygon([verts])  # handles concave outlines (bmesh ngon fill does not)
    me.from_pydata(verts, [], [tuple(t) for t in tris])
    me.materials.append(mat(color, alpha))
    o = link(bpy.data.objects.new(name, me))
    o.parent = parent
    o.location.z = z
    return o


def light(name, pts, color, alpha, parent=None, z=0.0, smooth=3):
    """See-through overlay (light pools, beams, tints): no outline, alpha-blended."""
    p = chaikin(pts, smooth) if smooth else [tuple(q[:2]) for q in pts]
    return _mesh(name, ccw(p), color, parent, z, alpha)


def glow(name, center, rx, ry, color, alpha=0.06, rings=6, parent=None, z=0.0):
    """Soft radial glow: stacked translucent ellipses, brightest in the middle."""
    g = empty(name, parent, center, z)
    for i in range(rings):
        k = 1 - i / rings
        light(f"{name}{i}", ell(0, 0, rx * k, ry * k, n=48), color, alpha, g, i * 0.001)
    return g


def vignette(name, cx, cy, w, h, parent=None, z=0.0, strength=0.1, steps=12):
    """Darkened frame edges: translucent black sheets with shrinking oval holes."""
    g = empty(name, parent, (cx, cy), z)
    for i in range(steps):
        k = 1.28 - 0.04 * i
        outer = [(-w, -h), (w, -h), (w, h), (-w, h)]
        inner = [(math.cos(2 * math.pi * j / 64) * w * 0.62 * k, math.sin(2 * math.pi * j / 64) * h * 0.62 * k) for j in range(64)]
        verts = [Vector((x, y, 0)) for x, y in outer + inner]
        tris = tessellate_polygon([verts[:4], verts[4:]])
        me = bpy.data.meshes.new(f"{name}{i}")
        me.from_pydata(verts, [], [tuple(t) for t in tris])
        me.materials.append(mat("#05050A", strength / steps * 2))
        o = link(bpy.data.objects.new(f"{name}{i}", me))
        o.parent, o.location.z = g, i * 0.001
    return g


def shape(name, pts, color, parent=None, z=0.0, ol=OL, smooth=3):
    """Filled smooth shape with an outline mesh tucked behind it. Returns the fill object;
    the outline is parented to it so hiding/scaling the fill carries the outline along."""
    p = chaikin(pts, smooth) if smooth else [tuple(q[:2]) for q in pts]
    p = ccw(p)
    o = _mesh(name, p, color, parent, z)
    o["hex"] = color
    if ol > 0:
        line = _mesh(name + "_ol", offset(p, ol), OUTLINE, o, -0.004)
        line.location.z = -0.004
    return o


# ---------- cel shading ----------

def _hex_shift(h, dv, ds=0.0):
    import colorsys
    r, g, b = (int(h[i:i + 2], 16) / 255 for i in (1, 3, 5))
    hh, ss, vv = colorsys.rgb_to_hsv(r, g, b)
    r, g, b = colorsys.hsv_to_rgb(hh, min(1, ss * (1 + ds)), min(1, max(0, vv * dv if dv < 1 else vv + (1 - vv) * (dv - 1))))
    return "#%02X%02X%02X" % (round(r * 255), round(g * 255), round(b * 255))


def _prism(name, pts, z0, z1):
    verts = [Vector((x, y, z0)) for x, y in pts] + [Vector((x, y, z1)) for x, y in pts]
    n = len(pts)
    tris = tessellate_polygon([verts[:n]])
    faces = [tuple(reversed(t)) for t in tris] + [tuple(i + n for i in t) for t in tris]
    faces += [(i, (i + 1) % n, (i + 1) % n + n, i + n) for i in range(n)]
    me = bpy.data.meshes.new(name)
    me.from_pydata(verts, [], faces)
    me.validate()
    return link(bpy.data.objects.new(name, me))


def crescent(fill, color, d, toward=LIGHT, z=0.0015):
    """Cel band along the edge of `fill` facing away from `toward`: fill minus (fill shifted toward the light).
    Parented to the fill, so it hides/moves with it. Returns the new object or None."""
    pts = [(v.co.x, v.co.y) for v in fill.data.vertices]
    if len(pts) < 3:
        return None
    a = _prism("_cA", pts, -0.5, 0.5)
    b = _prism("_cB", [(x + toward[0] * d, y + toward[1] * d) for x, y in pts], -1.0, 1.0)
    mod = a.modifiers.new("cut", "BOOLEAN")
    mod.operation, mod.object, mod.solver = "DIFFERENCE", b, "EXACT"
    dg = bpy.context.evaluated_depsgraph_get()
    me = bpy.data.meshes.new_from_object(a.evaluated_get(dg))
    for o in (a, b):
        m_ = o.data
        bpy.data.objects.remove(o, do_unlink=True)
        bpy.data.meshes.remove(m_)
    bm = bmesh.new()
    bm.from_mesh(me)
    bmesh.ops.delete(bm, geom=[f for f in bm.faces if f.normal.z < 0.5], context="FACES")
    bmesh.ops.delete(bm, geom=[v for v in bm.verts if not v.link_faces], context="VERTS")
    if not bm.faces:
        bm.free()
        bpy.data.meshes.remove(me)
        return None
    for v in bm.verts:
        v.co.z = 0.0
    bm.to_mesh(me)
    bm.free()
    me.materials.clear()
    me.materials.append(mat(color))
    o = link(bpy.data.objects.new(fill.name + "_cel", me))
    o.parent = fill
    o.location = (0, 0, z)
    return o


def stroke(name, path, w, color=OUTLINE, parent=None, z=0.0, w1=None):
    return _mesh(name, ccw(stroke_pts(path, w, w1)), color, parent, z)


def text(name, body, size, color, parent=None, loc=(0, 0), z=0.0, font="Boogaloo-Regular.ttf", align="CENTER"):
    cu = bpy.data.curves.new(name, "FONT")
    cu.body = body
    f = bpy.data.fonts.get(font) or bpy.data.fonts.load(os.path.join(FONTS, font))
    f.name = font
    cu.font, cu.size = f, size
    cu.align_x, cu.align_y = align, "CENTER"
    cu.materials.append(mat(color))
    o = link(bpy.data.objects.new(name, cu))
    o.parent = parent
    o.location = (loc[0], loc[1], z)
    return o


def set_visible(o, vis, frame=None):
    for ob in [o] + list(o.children_recursive):
        ob.hide_render = not vis
        ob.hide_viewport = not vis
        if frame is not None:
            ob.keyframe_insert("hide_render", frame=frame)
            ob.keyframe_insert("hide_viewport", frame=frame)


# ---------- scene ----------

def setup_render(sc, w=1080, h=1920, fps=30, bg=CHALK):
    sc.render.engine = "BLENDER_WORKBENCH"
    sc.display.shading.light = "FLAT"
    sc.display.shading.color_type = "TEXTURE"  # flat colours for shapes, the image for cut-outs
    sc.display.shading.background_type = "VIEWPORT"
    r, g, b = (lin(int(bg[i:i + 2], 16) / 255) for i in (1, 3, 5))
    sc.display.shading.background_color = (r, g, b)
    sc.world = sc.world or bpy.data.worlds.new("w")
    sc.world.color = (r, g, b)
    sc.display.render_aa = "16"
    sc.view_settings.view_transform = "Standard"
    sc.render.resolution_x, sc.render.resolution_y = w, h
    sc.render.fps = fps
    sc.render.image_settings.file_format = "PNG"


def camera(sc, x=0, y=0, ortho=20):
    cd = bpy.data.cameras.new("cam")
    cd.type = "ORTHO"
    cd.ortho_scale = ortho
    cd.sensor_fit = "VERTICAL"  # ortho = frame height in every format (9:16 already did this via AUTO)
    cd.clip_end = 200
    cam = link(bpy.data.objects.new("cam", cd))
    cam.location = (x, y, 60)
    sc.camera = cam
    return cam


def still(sc, path, frame=0):
    sc.frame_set(frame)
    sc.render.filepath = path
    bpy.ops.render.render(write_still=True)


# ---------- image cut-outs (art drawn outside Blender, see art/) ----------

def img(name, path, parent=None, anchor=(0, 0), ppu=100.0, z=0.0, rot=0.0, flip=False, loc=(0, 0)):
    """A transparent PNG as a flat cut-out. `anchor` is the pixel (x, y from the top-left) that sits at the
    object's origin; `ppu` = image pixels per scene unit; `flip` mirrors it left-right."""
    im = bpy.data.images.get(path) or bpy.data.images.load(path)
    im.name = path
    w, h = im.size
    ax, ay = anchor
    if flip:
        ax = w - ax
    x0, x1 = -ax / ppu, (w - ax) / ppu
    y0, y1 = -(h - ay) / ppu, ay / ppu
    me = bpy.data.meshes.new(name)
    me.from_pydata([(x0, y0, 0), (x1, y0, 0), (x1, y1, 0), (x0, y1, 0)], [], [(0, 1, 2, 3)])
    uv = me.uv_layers.new()
    corners = [(1, 0), (0, 0), (0, 1), (1, 1)] if flip else [(0, 0), (1, 0), (1, 1), (0, 1)]
    for i, lp in enumerate(me.loops):
        uv.data[i].uv = corners[lp.vertex_index]
    m = bpy.data.materials.get("img:" + path)
    if not m:
        m = bpy.data.materials.new("img:" + path)
        m.use_nodes = True
        nt = m.node_tree
        t = nt.nodes.new("ShaderNodeTexImage")
        t.image = im
        t.interpolation = "Cubic"
        bsdf = nt.nodes.get("Principled BSDF")
        nt.links.new(t.outputs["Color"], bsdf.inputs["Base Color"])
        nt.links.new(t.outputs["Alpha"], bsdf.inputs["Alpha"])
        nt.nodes.active = t
    me.materials.append(m)
    o = link(bpy.data.objects.new(name, me))
    o.parent = parent
    o.location = (loc[0], loc[1], z)
    o.rotation_euler.z = rot
    return o
