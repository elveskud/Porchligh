# Quick look at one character: full body + head close-up.
#   WHO=riot COSTUME=mafia EXPR=shocked Blender --background --python preview.py
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from toon import *
import cast

who = os.environ.get("WHO", "riot")
out = os.environ.get("OUT", os.path.join(HERE, "test"))
sc = reset()
setup_render(sc, 900, 900)
kw = {"costume": os.environ["COSTUME"]} if "COSTUME" in os.environ else {}
c = getattr(cast, who)(**kw)
if "EXPR" in os.environ:
    c.expr(os.environ["EXPR"])
cam = camera(sc, 0, 6.0, 14)
still(sc, os.path.join(out, f"{who}_body.png"))
head = c.extras["head"].matrix_world.translation
cam.location.x, cam.location.y = head.x, head.y + 2.2
cam.data.ortho_scale = 7.5
still(sc, os.path.join(out, f"{who}_head.png"))
