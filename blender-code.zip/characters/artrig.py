# Riot built from the drawn art pack (art/riot/parts, cut by art/cut.py) instead of code-drawn shapes.
# Same rig contract as cast.riot(): expressions, visemes, poses, hands, IK, ears/tail springs, head turns,
# so motion.py, props.py and every template work unchanged.
#   c = artrig.riot(costume="hoodie" | "mafia" | "dare" | "coach" | "host")
import os
from toon import *
import cast

PARTS = os.path.join(HERE, "art", "riot", "parts")
P = lambda n: os.path.join(PARTS, n + ".png")
MASK = "#F6D903"  # sampled from the head art

# head art landmarks (pixels in 01_head_00.png, 696x683), head scale 130 px/unit
HEAD_PPU, HEAD_W, HEAD_H = 130.0, 696, 683
CHIN = (348, 683)
EYE_HOLE = {-1: (223, 257), 1: (473, 257)}
HOLE_RX, HOLE_RY = 0.43, 0.34
MOUTH_PX = (348, 470)

# mouth key -> (piece, pixels per unit, extra scale)
TALK = 224.0
MOUTHS = {
    "vA": ("05_mouths_talk_03", TALK, 1.0), "vB": ("05_mouths_talk_02", TALK, 1.0),
    "vC": ("05_mouths_talk_01", TALK, 1.0), "vD": ("05_mouths_talk_00", TALK, 1.0),
    "vE": ("05_mouths_talk_04", TALK, 1.0), "vF": ("05_mouths_talk_06", TALK, 1.0),
    "vG": ("05_mouths_talk_07", TALK, 1.0), "vH": ("05_mouths_talk_05", TALK, 1.0),
    "grin": ("06c_smile_00", 560.0, 1.0), "smile": ("06c_smile_00", 680.0, 1.0),
    "smirk": ("06d_smirk_00", 560.0, 1.0), "flat": ("05_mouths_talk_03", TALK, 0.8),
    "wobble": ("05_mouths_talk_03", TALK, 0.65), "grit": ("05_mouths_talk_02", TALK, 1.1),
    "shock": ("05_mouths_talk_04", TALK, 0.9), "yell": ("05_mouths_talk_00", TALK, 1.15),
    "laugh": ("05_mouths_talk_05", TALK, 1.15),
}


def hp(px, py):
    """Head-art pixel -> head-local units (head origin is 0.4 above the chin)."""
    return ((px - CHIN[0]) / HEAD_PPU, (CHIN[1] - py) / HEAD_PPU - 0.4)


def size_of(name):
    im = bpy.data.images.get(P(name)) or bpy.data.images.load(P(name))
    im.name = P(name)
    return im.size


def centred(name, parent, ppu, z=0.0, s=1.0, rot=0.0, flip=False, loc=(0, 0)):
    w, h = size_of(name)
    o = img(f"riot_{name}", P(name), parent, (w / 2, h / 2), ppu / s, z, rot, flip, loc)
    return o


class ArtRiot(cast.Character):
    def turn(self, t, frame=None):
        """Cheap 3/4: the whole face slides toward the look direction and narrows a touch; ears counter-slide."""
        f = self.extras["face"]
        f.location.x = 0.32 * t
        f.scale.x = 1 - 0.06 * abs(t)
        for s in (-1, 1):
            e = self.extras[f"ear{s}"]
            if "bx" not in e:
                e["bx"] = e.location.x
            e.location.x = e["bx"] - 0.12 * t
        if frame is not None:
            f.keyframe_insert("location", frame=frame)
            f.keyframe_insert("scale", frame=frame)
            for s in (-1, 1):
                self.extras[f"ear{s}"].keyframe_insert("location", frame=frame)


def driven_lid(eye_root, lid, line, top, h):
    """Eyelid coverage follows the eye root's y-scale (set by expressions and blinks): 1 = open, 0.1 = shut."""
    for obj, path, idx, expr in ((lid, "scale", 1, "max(0.001, min(1.0, 1.0 - s))"),
                                 (line, "location", 1, f"{top} - max(0.0, min(1.0, 1.0 - s)) * {h}")):
        d = obj.driver_add(path, idx).driver
        d.type = "SCRIPTED"
        v = d.variables.new()
        v.name, v.type = "s", "TRANSFORMS"
        v.targets[0].id = eye_root
        v.targets[0].transform_type = "SCALE_Y"
        v.targets[0].transform_space = "LOCAL_SPACE"
        d.expression = expr


def riot(costume="hoodie"):
    c = ArtRiot("riot")
    body = empty("riot_body", c.root, (0, 0), 0.0)

    # tail (behind), legs, torso
    tail = empty("riot_tail", body, (0.35, 3.25), -0.6)
    img("riot_tail_img", P("11_tail_00"), tail, (318, 880), 225.0, 0.0)
    c.extras["tail"] = tail
    for s in (-1, 1):
        leg = empty(f"riot_leg{s}", body, (0.55 * s, 3.3), -0.1)
        img(f"riot_leg{s}_img", P("10_legs_00"), leg, (240, 10), 241.0, 0.0, flip=(s == 1))
        c.legs[s] = leg
    shape("riot_hips", ell(0, 3.05, 0.95, 0.5), "#F06A0A", body, -0.2, ol=0)  # fills the gap between the legs
    torso_piece = {"mafia": ("12_costumes_01", (186, 470), 205.0)}.get(costume, ("torso_v2_cropped", (266, 812), 241.0))
    img("riot_torso", P(torso_piece[0]), body, torso_piece[1], torso_piece[2], 0.0, loc=(0, 3.18 if costume != "mafia" else 3.05))

    # arms: upper sleeve + forearm + hands (art is a right arm; the left is mirrored)
    for s in (-1, 1):
        a = empty(f"riot_arm{s}", body, (0.98 * s, 5.85), 0.15)
        img(f"riot_upper{s}", P("arm_upper"), a, (138, 30), 277.0, 0.0, flip=(s == -1))
        el = empty(f"riot_elbow{s}", a, (0, -1.35), 0.02)
        img(f"riot_fore{s}", P("arm_fore"), el, (138, 40), 277.0, 0.0, flip=(s == -1))
        root = empty(f"riot_hand{s}", el, (0, -1.25), 0.01)
        root.scale.x = s
        hands = {}
        for key, (piece, anchor, rot) in {"paw": ("09_hands_00", (132, 20), 0.0), "open": ("09_hands_01", (150, 20), 0.0),
                                          "fist": ("09_hands_02", (123, 20), 0.0),
                                          "point": ("09_hands_04", (20, 140), -math.pi / 2),
                                          "thumbs": ("09_hands_03", (30, 230), -math.pi / 2)}.items():
            g = empty(f"riot_hand{s}_{key}", root)
            img(f"riot_hand{s}_{key}_img", P(piece), g, anchor, 440.0, 0.0, rot)
            set_visible(g, key == "paw")
            hands[key] = g
        c.hands[s], c.hand_state[s], c.extras[f"hand{s}"] = hands, "paw", root
        a["x0"], a["y0"], a["z0"], a["L1"], a["L2"] = 0.98 * s, 5.85, 0.15, 1.35, 1.7
        c.arms[s], c.elbows[s] = a, el

    # head: face group (head art + features) so the whole face can slide for head turns
    head = empty("riot_head", body, (0, 6.15), 0.4)
    c.extras["head"] = head
    face = empty("riot_face", head, (0, 0), 0.0)
    c.extras["face"] = face
    img("riot_headart", P("01_head_00"), face, (CHIN[0], CHIN[1]), HEAD_PPU, 0.0, loc=(0, -0.4))
    for s in (-1, 1):
        ex, ey = hp(196 if s == -1 else 500, 118)
        ear = empty(f"riot_ear{s}", head, (ex, ey), -0.1)
        img(f"riot_ear{s}_img", P("02_ear_00"), ear, (287, 800), 270.0, 0.0, flip=(s == -1))
        ear.rotation_euler.z = rad(-16) * s
        c.extras[f"ear{s}"] = ear

    for s in (-1, 1):
        hx, hy = hp(*EYE_HOLE[s])
        eye_root = empty(f"riot_eye{s}", face, (hx, hy), 0.03)  # scale.y drives the lid (expressions, blinks)
        opened = empty(f"riot_eye{s}_open", face, (0, 0), 0.0)
        p = empty(f"riot_pupil{s}", opened, (hx, hy - 0.04), 0.03)
        p["x0"], p["y0"] = hx, hy - 0.04
        centred("03_eyes_v2_03", p, 271.0)
        top = hy + HOLE_RY + 0.02
        lid = empty(f"riot_lid{s}", opened, (hx, top), 0.05)
        shape(f"riot_lid{s}_s", rect(-HOLE_RX - 0.06, -2 * HOLE_RY - 0.04, HOLE_RX + 0.06, 0), MASK, lid, 0.0, ol=0, smooth=0)
        line = empty(f"riot_lidline{s}", opened, (hx, top), 0.06)
        stroke(f"riot_lidline{s}_s", [(-HOLE_RX, 0.02), (0, -0.04), (HOLE_RX, 0.02)], 0.09, OUTLINE, line, 0.0)
        driven_lid(eye_root, lid, line, top, 2 * HOLE_RY + 0.04)
        arc = empty(f"riot_eye{s}_arc", face, (hx, hy), 0.05)
        shape(f"riot_eye{s}_cover", ell(0, 0, HOLE_RX + 0.03, HOLE_RY + 0.03), MASK, arc, 0.0, ol=0)
        centred("03_eyes_v2_06", arc, 240.0, 0.01, rot=math.pi, loc=(0, 0.02))
        set_visible(arc, False)
        c.eyes.append(eye_root)
        c.pupils.append((s, p))
        c.eye_states.append((opened, arc))
        bx, by = hp(EYE_HOLE[s][0] + 4 * s, 180)
        b = empty(f"riot_brow{s}", face, (bx, by), 0.07)
        b["y0"] = by
        centred("04_brows_02" if s == -1 else "04_brows_03", b, 276.0)
        c.brows.append((s, b))

    mx_, my_ = hp(*MOUTH_PX)
    m = empty("riot_mouth", face, (mx_, my_), 0.06)
    for key, (piece, ppu, k) in MOUTHS.items():
        g = empty(f"riot_m_{key}", m)
        centred(piece, g, ppu, 0.0, k)
        c.mouths[key] = g

    # costume accessories
    if costume == "mafia":
        hat = empty("riot_hat", head, hp(348, 120), 0.3)
        centred("12_costumes_00", hat, 75.0, loc=(0, 0.55))
        c.extras["hat"] = hat
        g = empty("riot_glasses", face, hp(348, 257), 0.1)
        centred("12_costumes_03", g, 64.0)
        c.extras["glasses"] = g
    elif costume == "dare":
        for s, piece in ((-1, "12_costumes_04"), (1, "12_costumes_05")):
            centred(piece, head, 150.0, 0.02, rot=-0.25 * s, loc=hp(250 if s == -1 else 446, 105))
    elif costume == "coach":
        vis = empty("riot_visor", face, hp(348, 160), 0.2)
        centred("12_costumes_07", vis, 58.0)
        c.extras["visor"] = vis
        centred("12_costumes_10", body, 190.0, 0.05, loc=(0.05, 5.0))
        clip = empty("riot_clipboard", c.extras["hand-1"], (0.0, -0.45), -0.02)
        centred("12_costumes_08", clip, 130.0)
        c.extras["clipboard"] = clip
    elif costume == "host":
        mic = empty("riot_mic", c.extras["hand1"], (0.0, -0.35), 0.03)
        centred("12_costumes_09", mic, 140.0, rot=math.pi)
        c.extras["mic"] = mic

    # this hand art has the thumb across the fist, so thumbs-up is done with a level forearm
    c.poses = dict(cast.POSES, thumbs={1: (22, 68, "thumbs"), -1: cast.REST})
    c.extras["thumbs_elbow"] = 68
    c.pose("mic" if costume == "host" else "idle")
    c.expr({"mafia": "cocky", "dare": "cocky"}.get(costume, "hype"))
    c.palette = [("Fur", "#FF6B00"), ("Cream", "#F5E6C5"), ("Eye mask", MASK), ("Inner ear", "#A3122A"),
                 ("Hoodie", "#1E1E1E"), ("Outline", OUTLINE)]
    return c
