# Every character in one place: how to build them and how they move, stand and sound.
#   import roster; c = roster.make("bash"); c = roster.make("riot", "lifeguard")
# Existing cast keeps its hand-built drawing functions (cast.riot, cast.bear, ...). New characters are mostly data:
# an `animal` spec (fur, outfit, ears, tail, nose, extras) drawn by roster.animal() with the same shared parts
# (Character class, arms, hands, eyes, brows, lip-sync mouths), so every face, pose, move and walk works for them.
from toon import *
import cast
from cast import (Character, add_eye, add_brow, add_mouths, hoodie_torso, build_arm, friend_body, cel,
                  OUTLINE, RED, YELLOW)

# walk: (stride deg, bob, step frames, arm swing deg, sway deg); height: x the set's character scale
PROFILES = {
    "riot":  dict(build=lambda cos=None: cast.riot(cos or "hoodie"), height=1.0, walk=(24, 0.22, 10, 18, 2), voice="riot"),
    "bash":  dict(build=lambda cos=None: cast.bear(), height=1.1, walk=(18, 0.10, 13, 12, 5), voice="bash"),
    "pip":   dict(build=lambda cos=None: cast.bunny(), height=0.92, walk=(16, 0.14, 8, 10, 1), voice="pip"),
    "rocco": dict(build=lambda cos=None: cast.raccoon(), height=1.0, walk=(12, 0.05, 13, 6, 3), voice="rocco"),
}
DEFAULT = dict(height=1.0, walk=(20, 0.14, 11, 14, 1), gesture=(0.6, 0.8), face="happy")


def profile(name):
    """A character's profile with defaults filled in."""
    return {**DEFAULT, **PROFILES.get(name, {})}


def make(name, costume=None):
    """Build any character by name (costume where the character has them)."""
    p = PROFILES.get(name)
    if p is None:
        raise SystemExit(f"roster: unknown character {name!r} ({', '.join(PROFILES)})")
    if "animal" in p:
        return animal(name, p["animal"])
    return p["build"](costume)


def add(name, **prof):
    """Register a character (e.g. from an episode's own cast list)."""
    PROFILES[name] = prof


# ---------- the parametric animal ----------

def _outfit_body(c, fur, kind, color, trim, wb, wt):
    """Body for any outfit. Hoodie = the friends' body; others share legs and arms but change the top."""
    if kind == "hoodie":
        return friend_body(c, fur, color, trim, wb=wb, wt=wt)
    n = c.name
    body = empty(f"{n}_body", c.root, (0, 0), 0.0)
    for s in (-1, 1):
        leg = empty(f"{n}_leg{s}", body, (0.72 * s, 3.2), -0.1)
        shape(f"{n}_leg{s}_f", [(-0.45, 0.2), (0.45, 0.2), (0.4, -2.6), (-0.4, -2.6)], fur, leg, 0.0)
        shape(f"{n}_foot{s}", ell(0.2 * s, -2.85, 0.72, 0.38), fur, leg, 0.02)
        c.legs[s] = leg
    if kind == "dress":
        shape(f"{n}_torso", mirror([(0, 2.3), (wb + 0.5, 2.3, "s"), (wt, 5.6), (wt - 0.4, 6.3), (0, 6.4)]), color, body, 0.0)
        stroke(f"{n}_hem", [(-wb - 0.4, 2.45), (wb + 0.4, 2.45)], 0.12, trim, body, 0.01)
    else:
        hoodie_torso(c, body, color, trim, w_bot=wb, w_top=wt)
        if kind == "shirt":
            shape(f"{n}_collar", [(-0.6, 6.4, "s"), (0.6, 6.4, "s"), (0.0, 5.7, "s")], trim, body, 0.02, ol=0.05, smooth=0)
            for y in (5.2, 4.5, 3.8):
                shape(f"{n}_btn{y}", ell(0, y, 0.08, 0.08, n=10), trim, body, 0.03, ol=0)
        elif kind == "cardigan":
            shape(f"{n}_shirt", [(-0.55, 6.4, "s"), (0.55, 6.4, "s"), (0.3, 3.1, "s"), (-0.3, 3.1, "s")], "#F4EEE2", body, 0.02, ol=0.05, smooth=0)
            for y in (5.4, 4.6, 3.8):
                shape(f"{n}_btn{y}", ell(0.42, y, 0.09, 0.09, n=10), trim, body, 0.03, ol=0)
        elif kind == "vest":
            shape(f"{n}_shirt", [(-0.7, 6.4, "s"), (0.7, 6.4, "s"), (0.0, 4.6, "s")], "#FFFFFF", body, 0.02, ol=0.05, smooth=0)
            for y in (4.3, 3.7):
                shape(f"{n}_btn{y}", ell(0.15, y, 0.08, 0.08, n=10), trim, body, 0.03, ol=0)
    sleeve = color if kind != "vest" else fur
    for s in (-1, 1):
        build_arm(c, s, body, ((wt - 0.12) * s, 6.0), sleeve, trim if kind != "vest" else fur, fur)
        c.arm(s, 10, elbow=8)
    head = empty(f"{n}_head", body, (0, 6.15), 0.4)
    c.extras["head"] = head
    return body, head


def _ears(c, head, kind, fur, inner, size=1.0):
    n = c.name
    for s in (-1, 1):
        if kind == "none":
            continue
        if kind == "round":
            ear = empty(f"{n}_ear{s}", head, (1.35 * s, 2.75), -0.05)
            shape(f"{n}_ear{s}_f", ell(0.2 * s, 0.3, 0.72 * size, 0.68 * size), fur, ear, 0.0)
            shape(f"{n}_ear{s}_in", ell(0.2 * s, 0.25, 0.4 * size, 0.38 * size), inner, ear, 0.01, ol=0)
        elif kind == "pointed":
            ear = empty(f"{n}_ear{s}", head, (1.3 * s, 2.6), -0.05)
            pts = [(0.4, 0.0), (0.85 * size, 1.9 * size, "s"), (1.6 * size, 0.35)]
            shape(f"{n}_ear{s}_f", move(mx(pts, s), -0.4 * s, 0), fur, ear, 0.0)
            shape(f"{n}_ear{s}_in", move(mx([(0.65, 0.25), (0.88 * size, 1.4 * size, "s"), (1.35 * size, 0.45)], s), -0.4 * s, 0),
                  inner, ear, 0.01, ol=0)
        elif kind in ("long", "floppy"):
            ear = empty(f"{n}_ear{s}", head, (0.65 * s, 2.7), -0.05)
            shape(f"{n}_ear{s}_f", [(-0.45, 0.0), (0.45, 0.0), (0.5, 1.6 * size), (0.0, 3.0 * size), (-0.5, 1.6 * size)], fur, ear, 0.0)
            shape(f"{n}_ear{s}_in", [(-0.2, 0.3), (0.2, 0.3), (0.22, 1.6 * size), (0.0, 2.6 * size), (-0.22, 1.6 * size)], inner, ear, 0.005, ol=0)
            ear.rotation_euler.z = rad(-10) * s if kind == "long" else rad(-70) * s
        elif kind == "horns":
            ear = empty(f"{n}_ear{s}", head, (0.8 * s, 3.0), -0.05)
            shape(f"{n}_horn{s}", mx([(0.0, 0.0), (0.45, 0.1), (0.9, 0.9), (1.2, 1.9, "s"), (0.6, 1.0), (0.1, 0.5)], s), inner, ear, 0.0)
            shape(f"{n}_ear{s}_f", ell(1.0 * s, -0.35, 0.6, 0.3, rot=rad(-20) * s), fur, ear, -0.01)
        c.extras[f"ear{s}"] = ear


def _tail(c, body, kind, fur, dark):
    n = c.name
    if kind == "none":
        return
    tail = empty(f"{n}_tail", body, (1.2, 3.4), -0.6)
    if kind == "round":
        shape(f"{n}_tail_f", ell(0.4, 0.0, 0.55, 0.5), fur, tail, 0.0)
    elif kind in ("big", "ringed"):
        tp = chaikin([(0, -0.3), (1.2, -0.4), (2.3, 0.2), (2.9, 1.2), (3.0, 2.3), (2.55, 2.9), (2.25, 2.2), (2.0, 1.3), (1.2, 0.5), (0, 0.35)], 3)
        shape(f"{n}_tail_f", tp, fur, tail, 0.0, smooth=0)
        if kind == "ringed":
            for i, (p, nn) in enumerate((((1.1, 0), (1, 0)), ((2.3, 0.6), (0.7, 0.7)), ((2.85, 1.7), (0.1, 1.0)))):
                band = cap(cap(tp, p, nn), (p[0] + nn[0] * 0.45, p[1] + nn[1] * 0.45), (-nn[0], -nn[1]))
                shape(f"{n}_stripe{i}", band, dark, tail, 0.01, ol=0, smooth=0)
    elif kind == "feathers":  # a big fan of feathers behind the body (a peacock)
        tail.location = (0, 4.5, -0.8)
        for i in range(9):
            a = rad(-80 + i * 20)
            tip = (math.sin(a) * 4.2, math.cos(a) * 4.2)
            g = empty(f"{n}_feather{i}", tail, (0, 0), i * 0.001)
            shape(f"{n}_feather{i}_f", [(0, 0), (tip[0] * 0.5 + math.cos(a) * 0.5, tip[1] * 0.5 - math.sin(a) * 0.5), tip,
                                        (tip[0] * 0.5 - math.cos(a) * 0.5, tip[1] * 0.5 + math.sin(a) * 0.5)], dark, g, 0.0)
            shape(f"{n}_feather{i}_eye", ell(tip[0] * 0.82, tip[1] * 0.82, 0.32, 0.32), "#E8B83A", g, 0.01, ol=0.04)
            shape(f"{n}_feather{i}_eye2", ell(tip[0] * 0.82, tip[1] * 0.82, 0.15, 0.15), "#2A4FA0", g, 0.02, ol=0)
    c.extras["tail"] = tail


def animal(name, a):
    """A new character drawn from a spec dict:
    fur, muzzle, inner (ear/horn colour), dark (mask/tail rings/feathers), outfit=(kind, colour, trim) with kind in
    hoodie|shirt|cardigan|vest|dress, ears=round|pointed|long|floppy|horns|none (+ ear_size), tail=round|big|ringed|
    feathers|none, nose=round|triangle|beak (+ nose_color), face_w (head width), eye_size, brows (colour), extras:
    a list from glasses, hat, shell, beard, mask, cheeks, sweat."""
    fur, muz = a.get("fur", "#A08060"), a.get("muzzle", "#F2E2C8")
    inner, dark = a.get("inner", "#E0A0A0"), a.get("dark", "#3A3A44")
    kind, col, trim = a.get("outfit", ("hoodie", "#6A8ACB", "#3E5E9E"))
    wb, wt = a.get("width", (1.65, 1.75))
    c = Character(name)
    body, head = _outfit_body(c, fur, kind, col, trim, wb, wt)
    ex = a.get("extras", [])
    if "shell" in ex:  # a turtle's shell rises behind the shoulders
        shape(f"{name}_shell", mirror([(0, 2.7), (wt + 1.0, 3.1), (wt + 1.3, 5.2), (wt + 0.6, 7.3), (0, 7.9)]), a.get("shell", "#5E8C4A"), body, -0.3)
        for i, (x, y) in enumerate(((-2.4, 4.0), (2.4, 4.0), (-2.6, 5.4), (2.6, 5.4), (-2.0, 6.7), (2.0, 6.7))):
            shape(f"{name}_scute{i}", ell(x, y, 0.42, 0.34), a.get("shell_dark", "#41683A"), body, -0.29, ol=0)
    _tail(c, body, a.get("tail", "none"), fur, dark)
    _ears(c, head, a.get("ears", "round"), fur, inner, a.get("ear_size", 1.0))
    w = a.get("face_w", 1.0)
    shape(f"{name}_face", mirror([(0, -0.15), (1.0 * w, 0.0), (1.8 * w, 0.55), (2.2 * w, 1.45), (2.05 * w, 2.4), (1.4 * w, 3.1), (0, 3.38)]),
          fur, head, 0.0)
    if "mask" in ex:
        shape(f"{name}_mask", mirror([(0, 1.55), (0.55, 1.45), (1.3, 1.35), (2.1 * w, 1.5, "s"), (1.75, 2.35), (1.0, 2.42), (0.4, 2.2), (0, 2.1)]),
              dark, head, 0.01, ol=0)
    if a.get("nose", "round") != "beak":
        shape(f"{name}_muzzle", ell(0, 0.72, 1.1 * w, 0.72), muz, head, 0.01, ol=0)
    es = a.get("eye_size", 1.0)
    for s in (-1, 1):
        add_eye(c, head, s, (0.85 * s * w, 1.95), 0.32 * es, 0.34 * es, 0.03, lid="glasses" not in ex)
        add_brow(c, head, s, (0.85 * s * w, 2.55 + 0.1 * (es - 1)), [(-0.42, -0.04), (0.0, 0.04), (0.42, 0.04)], 0.2, 0.16, 0.05,
                 color=a.get("brows", OUTLINE))
        if "cheeks" in ex:
            shape(f"{name}_blush{s}", ell(1.3 * s * w, 1.2, 0.28, 0.14), "#F7B8CB", head, 0.012, ol=0)
    nose = a.get("nose", "round")
    if nose == "beak":
        shape(f"{name}_nose", [(-0.55, 1.45), (0.55, 1.45), (0.0, 0.55, "s")], a.get("nose_color", "#F2A33A"), head, 0.06, ol=0.05, smooth=1)
        add_mouths(c, head, (0, 0.42), 0.055, w=0.6)
    else:
        if nose == "triangle":
            shape(f"{name}_nose", [(-0.3, 1.32), (0.3, 1.32), (0, 1.05, "s")], a.get("nose_color", "#E07A8A"), head, 0.06, ol=0.04, smooth=1)
        else:
            shape(f"{name}_nose", ell(0, 1.22, 0.38, 0.25), a.get("nose_color", OUTLINE), head, 0.06, ol=0)
        add_mouths(c, head, (0, 0.55), 0.06, w=0.8)
    if "beard" in ex:
        shape(f"{name}_beard", [(-0.35, 0.2), (0.35, 0.2), (0.15, -1.1, "s"), (-0.15, -1.1, "s")], a.get("beard", "#F4F0E8"), head, 0.04, ol=0.04)
    if "glasses" in ex:
        g = empty(f"{name}_glasses", head, (0, 1.95), 0.08)
        for s in (-1, 1):
            stroke(f"{name}_lens{s}", [(0.85 * s * w + 0.42 * math.cos(2 * math.pi * k / 24), 0.4 * math.sin(2 * math.pi * k / 24)) for k in range(25)],
                   0.07, OUTLINE, g, 0.0)
        stroke(f"{name}_bridge", [(-0.43 * w, 0.05), (0, 0.12), (0.43 * w, 0.05)], 0.07, OUTLINE, g, 0.0)
        c.extras["glasses"] = g
    if "hat" in ex:
        hat = empty(f"{name}_hat", head, (0, 3.05), 0.3)
        shape(f"{name}_hat_crown", [(-1.3, 0.15, "s"), (1.3, 0.15, "s"), (1.1, 1.3), (0, 1.5), (-1.1, 1.3)], a.get("hat", "#6B4A2E"), hat, 0.0)
        shape(f"{name}_hat_brim", [(-2.4, 0.0), (-1.5, 0.3), (1.5, 0.3), (2.4, 0.0), (2.3, -0.22), (0, -0.04), (-2.3, -0.22)], a.get("hat", "#6B4A2E"), hat, 0.02)
        c.extras["hat"] = hat
    c.expr(a.get("face", "happy"))
    c.palette = [("Fur", fur), ("Muzzle", muz), ("Outfit", col), ("Trim", trim)]
    cel(c)
    return c
