# Friendzy graphics kit + props for videos. Every builder returns an empty you can move, scale and key.
# Matches the app: sticker cards (asymmetric corners, off-black outline, flat offset shadow, slight tilt)
# and the category colours from FZColor (wild / funny / brain / social).
#
#   card = props.prompt_card("c1", "dare", "Do your best impression of someone here.", (0, 12), 30)
#   props.emote("e1", "anger", (2, 10), 25)
import math, textwrap, random
from toon import *

# app category colours (Friendzy/DesignSystem FZColor): icon, badge background, badge text
CATEGORY = {
    "wild":   ("#FF8A3D", "#FFD2B3", "#9A3000"),
    "funny":  ("#E8B23D", "#FBEFD2", "#8A6608"),
    "brain":  ("#3F87C7", "#DCEAF7", "#185FA5"),
    "social": ("#3FAE8E", "#C9EEE1", "#0F6E56"),
}
# game -> (card header, category)
GAMES = {
    "truth": ("TRUTH", "wild"), "dare": ("DARE", "wild"), "challenge": ("CHALLENGE", "wild"), "mafia": ("MAFIA", "wild"),
    "nhie": ("NEVER HAVE I EVER", "social"), "wyr": ("WOULD YOU RATHER", "social"),
    "mlt": ("MOST LIKELY TO", "funny"), "hottakes": ("HOT TAKE", "funny"),
    "alias": ("ALIAS", "brain"), "trivia": ("TRIVIA", "brain"),
}


def rrect4(x0, y0, x1, y1, r, n=6):
    """Rounded rect with per-corner radii r = (bottom-right, top-right, top-left, bottom-left)."""
    pts = []
    for (cx, cy, a0), rr in zip(((x1, y0, -90), (x1, y1, 0), (x0, y1, 90), (x0, y0, 180)), r):
        rr = max(rr, 0.001)
        sx = -1 if cx == x1 else 1
        sy = 1 if cy == y0 else -1
        ox, oy = cx + sx * rr, cy + sy * rr
        pts += [(ox + rr * math.cos(rad(a0 + 90 * i / n)), oy + rr * math.sin(rad(a0 + 90 * i / n))) for i in range(n + 1)]
    return pts


def outlined_text(name, body, size, color, parent, loc, z, ol_w=0.07, ol_color=OUTLINE, align="CENTER"):
    """Text with a solid outline behind it (Boogaloo); returns (fill, outline)."""
    t = text(name, body, size, color, parent, loc, z, align=align)
    o = text(name + "_ol", body, size, ol_color, parent, loc, z - 0.01, align=align)
    o.data.offset = ol_w
    return t, o


def wrap(body, width, size):
    per_line = max(8, int(width / (size * 0.47)))
    return "\n".join(textwrap.wrap(body, per_line))


# ---------- cards & text ----------

def prompt_card(name, game, prompt, loc=(0, 0), z=0, w=8.6, tilt=-3, size=0.78):
    """The app's sticker card: category header, big prompt text, FRIENDZY footer."""
    header, cat = GAMES[game]
    icon, badge, badge_text = CATEGORY[cat]
    body = wrap(prompt, w - 1.4, size)
    lines = body.count("\n") + 1
    h = 3.1 + lines * size * 1.25
    g = empty(name, None, loc, z)
    g.rotation_euler.z = rad(tilt)
    corners = (0.35, 0.9, 0.35, 0.9)
    shape(name + "_shadow", move(rrect4(-w / 2, -h / 2, w / 2, h / 2, corners), 0.22, -0.28), OFFBLACK, g, -0.05, ol=0, smooth=0)
    shape(name + "_bg", rrect4(-w / 2, -h / 2, w / 2, h / 2, corners), "#FFFFFF", g, 0.0, ol=0.1, smooth=0)
    shape(name + "_band", rrect4(-w / 2, h / 2 - 1.35, w / 2, h / 2, (0.0, 0.9, 0.35, 0.0)), icon, g, 0.01, ol=0, smooth=0)
    pill_w = len(header) * 0.27 + 1.0
    shape(name + "_pill", rrect4(-pill_w / 2, h / 2 - 1.1, pill_w / 2, h / 2 - 0.25, (0.42,) * 4), badge, g, 0.02, ol=0, smooth=0)
    text(name + "_hdr", header, 0.5, badge_text, g, (0, h / 2 - 0.68), 0.03)
    t = text(name + "_txt", body, size, OFFBLACK, g, (0, -0.15), 0.02)
    t.data.space_line = 1.05
    text(name + "_foot", "FRIENDZY", 0.42, icon, g, (0, -h / 2 + 0.55), 0.02)
    g["h"] = h
    return g


def caption_box(name, body, loc=(0, 0), z=0, w=10.8, size=1.35):
    """Hook caption: dark rounded box, white Boogaloo text (lowercase reads native on TikTok)."""
    g = empty(name, None, loc, z)
    lines = body.count("\n") + 1
    h = lines * size * 1.2 + 0.9
    shape(name + "_bg", rrect4(-w / 2, -h / 2, w / 2, h / 2, (0.6,) * 4), OFFBLACK, g, -0.05, ol=0, smooth=0)
    text(name + "_t", body, size, "#FFFFFF", g, (0, 0), 0.0)
    return g


def speech_bubble(name, body, loc=(0, 0), z=0, tail=(-1.2, -2.0), color=OFFBLACK, size=1.15):
    """White bubble; tail points from the bubble toward (loc + tail), i.e. the speaker's mouth."""
    g = empty(name, None, loc, z)
    w = max(3.0, len(max(body.split("\n"), key=len)) * size * 0.5 + 1.4)
    lines = body.count("\n") + 1
    h = lines * size * 1.15 + 0.9
    tx, ty = tail
    base = max(-w / 2 + 0.6, min(w / 2 - 0.6, tx * 0.6))
    pts = [(-w / 2, -h / 2), (base - 0.5, -h / 2), (tx, ty, "s"), (base + 0.5, -h / 2), (w / 2, -h / 2),
           (w / 2 + 0.2, 0), (w / 2, h / 2), (-w / 2, h / 2), (-w / 2 - 0.2, 0)]
    shape(name + "_bg", pts, "#FFFFFF", g, 0.0, ol=0.12, smooth=2)
    text(name + "_t", body, size, color, g, (0, 0), 0.02)
    return g


def stamp(name, word, loc=(0, 0), z=0, color=RED, tilt=-11, w=None):
    """Rubber stamp: ELIMINATED, DARE ACCEPTED, GUILTY... (slam it in with scale)."""
    w = w or len(word) * 0.62 + 1.2
    g = empty(name, None, loc, z)
    g.rotation_euler.z = rad(tilt)
    shape(name + "_card", rect(-w / 2, -0.85, w / 2, 0.85), CHALK, g, -0.02, ol=0, smooth=0)
    stroke(name + "_ring", [(-w / 2 + 0.15, -0.7), (w / 2 - 0.15, -0.7, "s"), (w / 2 - 0.15, 0.7, "s"), (-w / 2 + 0.15, 0.7, "s"),
                            (-w / 2 + 0.15, -0.7, "s"), (w / 2 - 0.15, -0.7)], 0.24, color, g, 0.0)
    text(name + "_t", word, 1.3, color, g, (0, -0.02), 0.01)
    return g


def pill(name, body, loc=(0, 0), z=0, bg=OFFBLACK, fg=CHALK, size=1.1):
    w = len(body) * size * 0.5 + 1.2
    g = empty(name, None, loc, z)
    shape(name + "_bg", rrect4(-w / 2, -0.65, w / 2, 0.65, (0.6,) * 4), bg, g, 0.0, ol=0.06, smooth=0)
    text(name + "_t", body, size, fg, g, (0, -0.02), 0.01)
    return g


def title(name, word, loc=(0, 0), z=0, color=RED, size=2.4):
    """Big outlined slam title (MAFIA, GUILTY, DARE)."""
    g = empty(name, None, loc, z)
    outlined_text(name + "_t", word, size, color, g, (0, 0), 0.0, 0.12)
    return g


def timer(name, seconds, loc=(0, 0), z=0, color=CATEGORY["brain"][0]):
    """Round countdown badge (Alias)."""
    g = empty(name, None, loc, z)
    shape(name + "_ring", ell(0, 0, 1.25, 1.25, n=48), color, g, 0.0, ol=0.1)
    shape(name + "_face", ell(0, 0, 0.98, 0.98, n=48), "#FFFFFF", g, 0.01, ol=0)
    g["label"] = text(name + "_t", str(seconds), 1.15, OFFBLACK, g, (0, -0.05), 0.02)
    return g


def mark(name, kind, loc=(0, 0), z=0, r=1.0):
    """Alias answer buttons: "tick" (green, correct) or "cross" (red, skip), like the app's ✅ / ❌."""
    g = empty(name, None, loc, z)
    color = CATEGORY["social"][0] if kind == "tick" else RED
    shape(name + "_bg", ell(0, 0, r, r, n=40), color, g, 0.0, ol=0.1)
    if kind == "tick":
        stroke(name + "_s", [(-0.48 * r, 0.02 * r), (-0.12 * r, -0.36 * r), (0.52 * r, 0.38 * r)], 0.26 * r, "#FFFFFF", g, 0.02)
    else:
        for i, s in enumerate((1, -1)):
            stroke(f"{name}_s{i}", [(-0.42 * r, -0.42 * r * s), (0.42 * r, 0.42 * r * s)], 0.26 * r, "#FFFFFF", g, 0.02)
    return g


def scoreboard(name, rows, loc=(0, 0), z=0, w=9.0):
    """Sticker-card scoreboard: rows = [(team, score)], the first row is the winner (yellow score)."""
    h = 1.9 + 1.35 * len(rows)
    g = empty(name, None, loc, z)
    g.rotation_euler.z = rad(2)
    corners = (0.35, 0.9, 0.35, 0.9)
    shape(name + "_shadow", move(rrect4(-w / 2, -h / 2, w / 2, h / 2, corners), 0.22, -0.28), OFFBLACK, g, -0.05, ol=0, smooth=0)
    shape(name + "_bg", rrect4(-w / 2, -h / 2, w / 2, h / 2, corners), OFFBLACK, g, 0.0, ol=0.1, smooth=0)
    text(name + "_hdr", "SCORE", 0.75, CATEGORY["brain"][0], g, (0, h / 2 - 0.75), 0.02)
    for i, (team, score) in enumerate(rows):
        y = h / 2 - 1.95 - i * 1.35
        text(f"{name}_t{i}", team, 0.95, "#FFFFFF", g, (-w / 2 + 0.7, y), 0.02, align="LEFT")
        text(f"{name}_s{i}", str(score), 1.2, YELLOW if i == 0 else "#9AA3B5", g, (w / 2 - 1.0, y), 0.02)
    return g


# ---------- Truth or Dare (TruthOrDareChoiceView / TruthOrDareRevealView) ----------

def td_choice(name, player, loc=(0, 0), z=0, w=8.4, h=9.6):
    """The app's choice screen in a phone: "<player>'s Turn", "Choose:", an orange TRUTH and a red DARE button.
    Buttons are the children <name>_truth / <name>_dare (scale-bump them for a tap); <name>_flash is a white
    overlay on DARE, hidden by default."""
    g = empty(name, None, loc, z)
    g.rotation_euler.z = rad(2)
    shape(name + "_shadow", move(rrect4(-w / 2, -h / 2, w / 2, h / 2, (0.8,) * 4), 0.22, -0.28), OFFBLACK, g, -0.05, ol=0, smooth=0)
    shape(name + "_body", rrect4(-w / 2, -h / 2, w / 2, h / 2, (0.8,) * 4), OFFBLACK, g, 0.0, ol=0.1, smooth=0)
    shape(name + "_screen", rrect4(-w / 2 + 0.3, -h / 2 + 0.3, w / 2 - 0.3, h / 2 - 0.3, (0.55,) * 4), CHALK, g, 0.01, ol=0, smooth=0)
    text(name + "_turn", f"{player}'s Turn", 0.95, OFFBLACK, g, (0, h / 2 - 1.3), 0.02)
    text(name + "_choose", "Choose:", 0.6, "#6B6862", g, (0, h / 2 - 2.2), 0.02)
    bw = w - 1.6
    for kind, col, y in (("truth", ORANGE, 0.2), ("dare", RED, -2.6)):
        b = empty(f"{name}_{kind}", g, (0, y), 0.03)
        shape(f"{name}_{kind}_bg", rrect4(-bw / 2, -1.05, bw / 2, 1.05, (0.45,) * 4), col, b, 0.0, ol=0.06, smooth=0)
        text(f"{name}_{kind}_t", kind.upper(), 1.25, "#FFFFFF", b, (0, -0.04), 0.02)
        if kind == "dare":
            fl = light(f"{name}_flash", rrect4(-bw / 2, -1.05, bw / 2, 1.05, (0.45,) * 4), "#FFFFFF", 0.7, b, 0.04, smooth=0)
            fl.hide_render = fl.hide_viewport = True
            g["flash"] = fl.name
    return g


def mystery_card(name, loc=(0, 0), z=0, w=8.4, h=6.6):
    """The face-down card: white, a big grey "?" and "Tap to reveal"."""
    g = empty(name, None, loc, z)
    shape(name + "_shadow", move(rrect4(-w / 2, -h / 2, w / 2, h / 2, (0.7,) * 4), 0.18, -0.24), "#C9C6C0", g, -0.05, ol=0, smooth=0)
    shape(name + "_bg", rrect4(-w / 2, -h / 2, w / 2, h / 2, (0.7,) * 4), "#FFFFFF", g, 0.0, ol=0.1, smooth=0)
    text(name + "_q", "?", 3.2, "#B8B6B2", g, (0, 0.6), 0.02)
    text(name + "_tap", "Tap to reveal", 0.65, "#6B6862", g, (0, -1.9), 0.02)
    return g


def td_card(name, kind, prompt, loc=(0, 0), z=0, w=8.4, size=0.8):
    """The revealed prompt card: solid orange (truth) or Party Red (dare), white text, Riot head sticker top right."""
    body = wrap(prompt, w - 1.4, size)
    h = max(6.6, 2.0 + (body.count("\n") + 1) * size * 1.25)
    g = empty(name, None, loc, z)
    col = ORANGE if kind == "truth" else RED
    shape(name + "_shadow", move(rrect4(-w / 2, -h / 2, w / 2, h / 2, (0.7,) * 4), 0.18, -0.24), OFFBLACK, g, -0.05, ol=0, smooth=0)
    shape(name + "_bg", rrect4(-w / 2, -h / 2, w / 2, h / 2, (0.7,) * 4), col, g, 0.0, ol=0.1, smooth=0)
    t = text(name + "_txt", body, size, "#FFFFFF", g, (0, 0), 0.02)
    t.data.space_line = 1.05
    head = empty(name + "_riot", g, (w / 2 - 0.3, h / 2 + 0.1), 0.05)  # riot-icon-head sticker, tilted like the app
    head.rotation_euler.z = rad(-6)
    for s in (-1, 1):
        shape(f"{name}_ear{s}", [(0.35 * s, 0.35), (0.85 * s, 1.25, "s"), (0.95 * s, 0.1)], ORANGE, head, 0.0, ol=0.06, smooth=0)
    shape(name + "_face", ell(0, 0, 1.0, 0.85), ORANGE, head, 0.01, ol=0.07)
    shape(name + "_mask", [(-0.95, 0.35), (-0.15, 0.05, "s"), (0.15, 0.05, "s"), (0.95, 0.35), (0.8, -0.15, "s"), (-0.8, -0.15, "s")],
          YELLOW, head, 0.02, ol=0.04)
    for s in (-1, 1):
        shape(f"{name}_eye{s}", ell(0.42 * s, 0.1, 0.11, 0.13), OFFBLACK, head, 0.03, ol=0)
    shape(name + "_muzzle", ell(0, -0.45, 0.5, 0.35), "#F7E6C8", head, 0.025, ol=0)
    shape(name + "_nose", ell(0, -0.32, 0.12, 0.09), OFFBLACK, head, 0.03, ol=0)
    g["h"] = h
    return g


def reveal_card(name, top, big, loc=(0, 0), z=0, color=OFFBLACK, tint=None, w=8.0, h=5.6, big_size=1.9):
    """The app's reveal cards (Mafia "YOU ARE / Mafia", "Pip was... / a Civilian", Trivia answers): a white card
    with a small grey line on top and one big word, optionally on a tinted panel (e.g. yellow for the role)."""
    g = empty(name, None, loc, z)
    shape(name + "_shadow", move(rrect4(-w / 2, -h / 2, w / 2, h / 2, (0.7,) * 4), 0.18, -0.24), "#C9C6C0", g, -0.05, ol=0, smooth=0)
    shape(name + "_bg", rrect4(-w / 2, -h / 2, w / 2, h / 2, (0.7,) * 4), "#FFFFFF", g, 0.0, ol=0.1, smooth=0)
    if tint:
        shape(name + "_tint", rrect4(-w / 2 + 0.35, -h / 2 + 0.35, w / 2 - 0.35, h / 2 - 0.35, (0.45,) * 4), tint, g, 0.01, ol=0, smooth=0)
    text(name + "_top", top, 0.7, "#6B6862", g, (0, h / 2 - 1.3), 0.02)
    text(name + "_big", big, big_size, color, g, (0, -0.45), 0.02)
    return g


def trivia_card(name, question, options, loc=(0, 0), z=0, w=10.0, size=0.78, header="TRIVIA", letters=True, row_size=0.62):
    """The app's Trivia question: the question on top, then rows A-D. Each row has hidden highlight children
    <name>_good<i> (yellow tint + orange border, the right answer) and <name>_bad<i> (red tint + border, a wrong pick)
    to switch on with set_visible."""
    body = wrap(question, w - 1.2, size)
    qh = (body.count("\n") + 1) * size * 1.25
    rh, gap = 1.25, 0.28
    n = len(options)
    h = 1.2 + qh + 0.6 + n * rh + (n - 1) * gap + 0.7
    g = empty(name, None, loc, z)
    shape(name + "_shadow", move(rrect4(-w / 2, -h / 2, w / 2, h / 2, (0.7,) * 4), 0.2, -0.26), OFFBLACK, g, -0.05, ol=0, smooth=0)
    shape(name + "_bg", rrect4(-w / 2, -h / 2, w / 2, h / 2, (0.7,) * 4), CHALK, g, 0.0, ol=0.1, smooth=0)
    text(name + "_hdr", header, 0.5, CATEGORY["brain"][2], g, (0, h / 2 - 0.6), 0.02)
    t = text(name + "_q", body, size, OFFBLACK, g, (0, h / 2 - 1.2 - qh / 2), 0.02)
    t.data.space_line = 1.05
    y = h / 2 - 1.2 - qh - 0.6 - rh / 2
    for i, opt in enumerate(options):
        row = empty(f"{name}_row{i}", g, (0, y), 0.02)
        pts = rrect4(-w / 2 + 0.5, -rh / 2, w / 2 - 0.5, rh / 2, (0.3,) * 4)
        shape(f"{name}_row{i}_bg", pts, "#FFFFFF", row, 0.0, ol=0.06, smooth=0)
        good = shape(f"{name}_good{i}", pts, "#FFF2B3", row, 0.005, ol=0.12, smooth=0)
        bad = shape(f"{name}_bad{i}", pts, "#FAD1D5", row, 0.006, ol=0.12, smooth=0)
        for o, col in ((good, ORANGE), (bad, RED)):  # coloured border: recolour the outline mesh
            for ch in o.children:
                ch.data.materials.clear()
                ch.data.materials.append(mat(col))
            set_visible(o, False)
        if letters:
            text(f"{name}_row{i}_l", "ABCD"[i], 0.62, "#6B6862", row, (-w / 2 + 1.2, -0.02), 0.01)
        text(f"{name}_row{i}_t", opt, row_size, OFFBLACK, row, (0.3 if letters else 0.0, -0.02), 0.01)
        y -= rh + gap
    g["h"] = h
    return g


def quote_card(name, label, quote, loc=(0, 0), z=0, w=9.0, size=0.9):
    """A featured answer (Who Said That?, Comeback): small label, the quote in big curly quotes."""
    body = wrap(f"\u201c{quote}\u201d", w - 1.4, size)
    h = 2.4 + (body.count("\n") + 1) * size * 1.25
    g = empty(name, None, loc, z)
    g.rotation_euler.z = rad(-2)
    shape(name + "_shadow", move(rrect4(-w / 2, -h / 2, w / 2, h / 2, (0.35, 0.9, 0.35, 0.9)), 0.22, -0.28), OFFBLACK, g, -0.05, ol=0, smooth=0)
    shape(name + "_bg", rrect4(-w / 2, -h / 2, w / 2, h / 2, (0.35, 0.9, 0.35, 0.9)), "#FFFFFF", g, 0.0, ol=0.1, smooth=0)
    text(name + "_lbl", label, 0.5, CATEGORY["social"][2], g, (0, h / 2 - 0.7), 0.02)
    t = text(name + "_q", body, size, OFFBLACK, g, (0, -0.35), 0.02)
    t.data.space_line = 1.05
    g["h"] = h
    return g


# ---------- reactions ----------

def emote(name, kind, loc=(0, 0), z=0, s=1.0):
    """Manga-style reaction marks to float near a head: sweat, anger, sparkle, question, exclaim, heart, zzz."""
    g = empty(name, None, loc, z)
    g.scale = (s, s, 1)
    if kind == "sweat":
        for i, (x, y, r) in enumerate(((0, 0.3, 0.32), (0.55, -0.35, 0.2))):
            shape(f"{name}{i}", [(x, y + r * 1.9, "s"), (x + r, y), (x, y - r), (x - r, y)], "#7FD3FF", g, 0.0, ol=0.05)
    elif kind == "anger":
        for i, a in enumerate((45, 135, 225, 315)):
            ca, sa = math.cos(rad(a)), math.sin(rad(a))
            stroke(f"{name}{i}", [(ca * 0.15, sa * 0.15), (ca * 0.42 + sa * 0.15, sa * 0.42 - ca * 0.15), (ca * 0.62, sa * 0.62)],
                   0.16, RED, g, 0.0)
    elif kind == "sparkle":
        for i, (x, y, r) in enumerate(((0, 0, 0.55), (0.75, 0.55, 0.28), (-0.6, 0.6, 0.2))):
            shape(f"{name}{i}", [(x + math.cos(math.pi * k / 4) * (r if k % 2 == 0 else r * 0.3),
                                  y + math.sin(math.pi * k / 4) * (r if k % 2 == 0 else r * 0.3), "s") for k in range(8)],
                  YELLOW, g, 0.0, ol=0.04, smooth=0)
    elif kind in ("question", "exclaim"):
        outlined_text(name + "_t", "?" if kind == "question" else "!", 1.8, YELLOW if kind == "exclaim" else "#FFFFFF", g, (0, 0), 0.0, 0.1)
    elif kind == "heart":
        pts = [(0, -0.6, "s"), (0.6, 0.0), (0.55, 0.45), (0.25, 0.55), (0, 0.3, "s"), (-0.25, 0.55), (-0.55, 0.45), (-0.6, 0.0)]
        shape(name + "_h", pts, CORAL, g, 0.0, ol=0.07)
    elif kind == "zzz":
        for i, (x, y, sz) in enumerate(((0, 0, 0.9), (0.6, 0.6, 0.65), (1.05, 1.05, 0.45))):
            outlined_text(f"{name}{i}", "z", sz, "#FFFFFF", g, (x, y), 0.0, 0.07)
    return g


def puff(name, loc=(0, 0), z=0, color="#D8D6E6"):
    """Cartoon smoke puff (someone vanishes / gets eliminated)."""
    g = empty(name, None, loc, z)
    rnd = random.Random(len(name))
    for i in range(7):
        a = 2 * math.pi * i / 7
        shape(f"{name}{i}", ell(math.cos(a) * 1.3, math.sin(a) * 1.5, rnd.uniform(0.8, 1.15), rnd.uniform(0.8, 1.1)), color, g, i * 0.002, ol=0.08)
    shape(f"{name}_c", ell(0, 0, 1.4, 1.6), color, g, 0.02, ol=0)
    return g


def confetti(name, loc=(0, 0), z=0, n=26, spread=5.0, seed=1):
    """Static confetti burst (animate each child outward for a pop)."""
    g = empty(name, None, loc, z)
    rnd = random.Random(seed)
    for i in range(n):
        x, y = rnd.uniform(-spread, spread), rnd.uniform(-spread * 0.6, spread * 0.6)
        piece = empty(f"{name}{i}", g, (x, y), i * 0.001)
        piece.rotation_euler.z = rnd.uniform(0, math.pi)
        col = (ORANGE, RED, YELLOW, "#3F87C7", "#3FAE8E", "#FFFFFF")[i % 6]
        shape(f"{name}{i}_s", rect(-0.14, -0.28, 0.14, 0.28), col, piece, 0.0, ol=0.03, smooth=0)
    return g


# ---------- held props ----------

def juice_box(name, parent=None, loc=(0, 0), z=0):
    g = empty(name, parent, loc, z)
    shape(name + "_box", rect(-0.5, -0.7, 0.5, 0.7), YELLOW, g, 0.0, smooth=0)
    shape(name + "_label", ell(0, -0.05, 0.3, 0.3), ORANGE, g, 0.01, ol=0)
    stroke(name + "_straw", [(0.25, 0.7), (0.25, 1.5), (-0.2, 1.95), (-0.65, 2.05)], 0.11, CORAL, g, -0.02)
    return g


def pizza_slice(name, parent=None, loc=(0, 0), z=0, s=1.0):
    """A slice of pineapple pizza (Hot Takes), point down."""
    g = empty(name, parent, loc, z)
    g.scale = (s, s, 1)
    shape(name + "_cheese", [(-0.75, 0.55, "s"), (0.75, 0.55, "s"), (0, -1.0, "s")], "#FFD45C", g, 0.0, smooth=0)
    shape(name + "_crust", rrect4(-0.85, 0.45, 0.85, 0.8, (0.15,) * 4), "#D9944A", g, 0.01, smooth=0)
    for k, (x, y) in enumerate(((-0.25, 0.2), (0.22, 0.05), (0.0, -0.4))):
        shape(f"{name}_pine{k}", rect(x - 0.12, y - 0.1, x + 0.12, y + 0.1), YELLOW, g, 0.02, ol=0.03, smooth=0)
    return g


def book(name, parent=None, loc=(0, 0), z=0, color="#3D6DFF"):
    """A hardback book seen from the side (Challenges: balance it on your head)."""
    g = empty(name, parent, loc, z)
    shape(name + "_cover", rrect4(-1.2, -0.3, 1.2, 0.3, (0.08,) * 4), color, g, 0.0, smooth=0)
    shape(name + "_pages", rect(-1.05, -0.18, 1.12, 0.18), CHALK, g, 0.01, ol=0, smooth=0)
    for k in (-0.06, 0.06):
        stroke(f"{name}_line{k}", [(-1.0, k), (1.08, k)], 0.03, "#C9C6C0", g, 0.02)
    return g


def app_phone(name, shot, parent=None, loc=(0, 0), z=0, h=6.0):
    """A phone showing a REAL app screenshot (feature beats): off-black body, the PNG as its screen. h = screen height."""
    g = empty(name, parent, loc, z)
    w = h * 1206 / 2622  # iPhone capture aspect
    shape(name + "_body", rrect4(-w / 2 - 0.22, -h / 2 - 0.22, w / 2 + 0.22, h / 2 + 0.22, (0.5,) * 4), OFFBLACK, g, 0.0, smooth=0)
    im = bpy.data.images.get(shot) or bpy.data.images.load(shot)
    img(name + "_screen", shot, g, anchor=(im.size[0] / 2, im.size[1] / 2), ppu=im.size[1] / h, z=0.02)
    return g


def phone(name, parent=None, loc=(0, 0), z=0, s=1.0):
    """A phone showing the Friendzy app (orange screen, F logo)."""
    g = empty(name, parent, loc, z)
    shape(name + "_body", rrect4(-0.55 * s, -0.95 * s, 0.55 * s, 0.95 * s, (0.18 * s,) * 4), OFFBLACK, g, 0.0, smooth=0)
    shape(name + "_screen", rrect4(-0.45 * s, -0.82 * s, 0.45 * s, 0.82 * s, (0.1 * s,) * 4), ORANGE, g, 0.01, ol=0, smooth=0)
    text(name + "_logo", "F", 0.9 * s, CHALK, g, (0, -0.05 * s), 0.02)
    return g


def end_card(name, line, loc=(0, 0), z=0, seed=4, fmt="vertical", line2=None):
    """Orange end card framed for a camera at loc with ortho 22: graffiti FRIENDZY + one line
    ('Mafia · free on Friendzy'). Letters are children <name>_l0..7 so they can pop in one by one.
    Vertical: leave the lower half for Riot. Horizontal (16:9): logo + line on the left, leave the right
    third for Riot (about x = loc.x + 11)."""
    g = empty(name, None, loc, z)
    hw = 6.2 if fmt == "vertical" else 19.6
    shape(name + "_bg", rect(-hw, -11, hw, 11), ORANGE, g, -0.1, ol=0, smooth=0)  # one frame at ortho 22
    rnd = random.Random(seed)
    lx, ly, sy = (-5.1, 6.0, 2.9) if fmt == "vertical" else (-16.6, 2.4, -3.0)
    ls, step, ss = (3.3, 1.46, 1.15) if fmt == "vertical" else (4.8, 2.12, 2.3)  # letter size, spacing, line size
    dots = (-6.2, 6.2, 3.6, 8.6) if fmt == "vertical" else (-18.5, 0.0, -0.6, 6.2)
    for i in range(46):
        x, y = rnd.uniform(dots[0], dots[1]), rnd.uniform(dots[2], dots[3])
        shape(f"{name}_dot{i}", ell(x, y, 0.07, 0.07, n=8), OFFBLACK if i % 3 else YELLOW, g, 0.0, ol=0)
    for i, ch in enumerate("FRIENDZY"):
        l = empty(f"{name}_l{i}", g, (lx + i * step, ly + (0.3 if i % 2 else -0.2)), 0.1)
        l.rotation_euler.z = rad(rnd.uniform(-9, 9))
        outlined_text(f"{name}_l{i}_t", ch, ls, YELLOW, l, (0, 0), 0.0, 0.14)
    sub = empty(name + "_sub", g, (0 if fmt == "vertical" else lx + 3.5 * step, sy), 0.1)
    outlined_text(name + "_sub_t", line if fmt == "vertical" else line.replace(" · ", "\n"), ss, "#FFFFFF", sub, (0, 0), 0.0, 0.08)
    if line2:  # optional smaller second line (episodes: the app line under "Next episode: ...")
        l2 = empty(name + "_sub2", g, (sub.location.x, sy - (1.6 if fmt == "vertical" else 2.9)), 0.1)
        outlined_text(name + "_sub2_t", line2, ss * 0.75, CHALK, l2, (0, 0), 0.0, 0.07)
    return g


# ---------- word-by-word captions ----------

def word_captions(name, cam, words, frame0, ortho=22.0, y_px=1300, size=1.45, max_chars=14, fps=30, fmt="vertical", y_frac=None):
    """TikTok-style captions: 1-3 word chunks, bold white Boogaloo with a thick outline, the current word
    pops in Electric Yellow. `words` = [(word, t0, t1)] in seconds from frame0 (see motion.word_times).
    Built at ortho 22 inside one holder parented to the camera; the holder is scaled by ortho/22 so the
    captions keep the same on-screen size (register it with CamAnim.hud() if the camera zooms).
    y_px is measured from the top of a 1080x1920 frame (default sits just above the bottom safe zone)."""
    chunks, cur = [], []
    for w in words:
        if cur and (len(" ".join(x[0] for x in cur + [w])) > max_chars or len(cur) == 3 or cur[-1][0][-1] in ".!?,"):
            chunks.append(cur)
            cur = []
        cur.append(w)
    if cur:
        chunks.append(cur)
    hold = empty(f"{name}_hud", cam, (0, 0), -8)
    hold.scale = (ortho / 22.0, ortho / 22.0, 1)
    y = (0.5 - (y_frac if y_frac is not None else y_px / 1920)) * 22.0  # y_frac: fraction down the frame (any format)
    max_w = 10.4 if fmt == "vertical" else 24.0  # vertical: keep clear of the right-hand buttons
    for ci, chunk in enumerate(chunks):
        g = empty(f"{name}_c{ci}", hold, (0, y), 0)
        pieces = []
        for wi, (word, t0, t1) in enumerate(chunk):
            body = word.upper()
            wr = empty(f"{name}_c{ci}w{wi}", g, (0, 0), 0)
            white, ol = outlined_text(f"{name}_c{ci}w{wi}_w", body, size, "#FFFFFF", wr, (0, 0), 0.0, 0.13, align="LEFT")
            yel = text(f"{name}_c{ci}w{wi}_y", body, size, YELLOW, wr, (0, 0), 0.005, align="LEFT")
            pieces.append((wr, white, yel, t0, t1))
        bpy.context.view_layer.update()
        space = size * 0.6
        widths = [p[1].dimensions.x for p in pieces]
        total = sum(widths) + space * (len(pieces) - 1)
        if total > max_w:
            g.scale = (max_w / total, max_w / total, 1)
        x = -total / 2
        for (wr, white, yel, t0, t1), wdt in zip(pieces, widths):
            wr.location.x = x
            x += wdt + space
        start = frame0 + round(chunk[0][1] * fps)
        nxt = frame0 + round(chunks[ci + 1][0][1] * fps) if ci + 1 < len(chunks) else frame0 + round(chunk[-1][2] * fps) + 12
        end = min(nxt, frame0 + round(chunk[-1][2] * fps) + 14)
        set_visible(g, False, 0)
        set_visible(g, True, start)
        set_visible(g, False, end)
        for wr, white, yel, t0, t1 in pieces:
            f0, f1 = frame0 + round(t0 * fps), frame0 + round(t1 * fps)
            set_visible(yel, False, 0)
            set_visible(yel, True, f0)
            set_visible(yel, False, max(f1, f0 + 3))
            for fr, s in ((f0 - 1, 1.0), (f0 + 2, 1.16), (f0 + 5, 1.0)):
                wr.scale = (s, s, 1)
                wr.keyframe_insert("scale", frame=fr)
    return hold
