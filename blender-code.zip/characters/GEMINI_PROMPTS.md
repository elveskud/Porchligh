# Riot art pack: prompts for Gemini

Send these to Gemini **in order, in one chat**, so the style stays consistent. Attach the app's Riot art to
the first message, and again whenever the style drifts. The art is in
`Friendzy/Assets.xcassets/riot-reference-pose` and `riot-icon-head`; use `riot-game-mafia` for the Mafia costume.

Save every image as a PNG named as shown, e.g. `01_head.png`, and put them all in
`Blender/characters/art/riot/`.

---

## 0. Style lock (send first)

```
I'm making a 2D cutout animation of this character (attached): Riot, an orange cartoon fox mascot.
I need his body parts drawn SEPARATELY so they can be animated like a puppet. For every image I ask for:

- Match the attached character exactly: same face, proportions, yellow eye mask, red inner ears,
  cream muzzle and chest fluff, big tail with cream tip, black hoodie with orange zip and trim.
- Front view, facing the viewer.
- Flat cartoon colours with one darker shadow tone. Thick, even black outline. No gradients,
  no textures, no glow, no drop shadows, no text, no watermark.
- Plain solid white background. Each part complete and not touching any other part.
- Same scale in every image: the head is about 40% of the image width.
- Colours: fur #FF6B00, fur shadow #D9530A, cream #F7E6C8, eye mask #FFD600, inner ear #A3122A,
  hoodie #1E1E1E, hoodie trim #FF6B00, outline #121212.
- Square image, 2048x2048.

Reply "ready" and I'll ask for the parts one by one.
```

## 1. Head: `01_head.png`
```
Draw only Riot's head, front view: fur, cream muzzle and cheek fluff, the yellow eye mask, and the black nose.
NO ears, NO eyes, NO eyebrows, NO mouth (leave the eye areas inside the mask and the muzzle blank).
```

## 2. Ear: `02_ear.png`
```
Draw only ONE of Riot's ears (his right ear), standing straight up: orange outside, red inner ear,
cream fur tufts at the base. Nothing else.
```

## 3. Eyes: `03_eyes.png`
```
Sprite sheet of Riot's eyes only, in a row, each one separate:
1) open eye, white with black pupil looking forward
2) the black pupil alone (with its small white shine)
3) half-closed cocky eye
4) wide shocked eye
5) closed happy eye (an upside-down U arc, like ^)
6) closed blinking eye (a flat line)
No mask, no fur around them.
```

## 4. Eyebrows: `04_brows.png`
```
Sprite sheet of Riot's eyebrows only (thick black brush strokes), in a row:
1) neutral  2) angry / determined (angled down toward the nose)  3) raised (surprised)
4) worried (angled up toward the middle)
```

## 5. Talking mouths: `05_mouths_talk.png`
```
Sprite sheet of Riot's mouths only, for lip sync: 8 separate mouths in a 4x2 grid, all the same width:
A) lips pressed closed (M, B, P)  B) teeth together, lips slightly apart (S, T, K)
C) open (E)  D) wide open (A)  E) rounded open (O)  F) small puckered circle (OO, W)
G) top teeth resting on the lower lip (F, V)  H) open with the tongue up behind the teeth (L)
Dark red inside, pink tongue, white teeth.
```

## 6. Expression mouths: `06_mouths_expr.png`
```
Sprite sheet of Riot's mouths only, 9 separate mouths in a 3x3 grid:
1) big cocky open grin with teeth (higher on his right)  2) closed smirk  3) closed friendly smile
4) shocked "O"  5) yelling (wide, teeth showing)  6) big laugh (open, tongue)
7) gritted teeth  8) flat line  9) nervous wobbly line
```

## 7. Body: `07_torso.png`
```
Draw only Riot's torso: the black hoodie (orange zip, orange piping, orange hem), the hood behind the neck,
and his cream belly fluff showing below the hem.
NO head, NO arms, NO legs, NO tail.
```

## 8. Arm: `08_arm.png`
```
Draw only Riot's RIGHT arm as two separate pieces, side by side, hanging straight down:
1) the upper arm (black hoodie sleeve, shoulder to elbow, rounded at the elbow)
2) the forearm (black sleeve, elbow to wrist, with the orange cuff)
No hand.
```

## 9. Hands: `09_hands.png`
```
Sprite sheet of Riot's RIGHT hand only (orange fur paw), 5 separate hands in a row, wrist at the top:
1) relaxed paw  2) open hand, fingers spread  3) fist
4) pointing with the index finger (finger on the thumb side of the paw)  5) thumbs up
```

## 10. Legs: `10_legs.png`
```
Draw only Riot's RIGHT leg and foot, standing (orange fur leg, orange paw-foot with little toe lines).
Nothing else.
```

## 11. Tail: `11_tail.png`
```
Draw only Riot's tail: big and fluffy, curving up, orange with a jagged cream tip. Nothing else.
```

## 12–15. Costumes (overlays; same rules)
```
12_mafia.png: (attach riot-game-mafia) only these separate pieces: a black fedora hat; round black sunglasses;
   a pinstripe suit torso with white shirt and red tie (no head or arms); one suit upper arm and forearm with
   white cuff.
13_dare.png: only a pair of small red cartoon devil horns, as separate pieces.
14_coach.png: only these separate pieces: a navy sports visor (front view); a silver whistle on an orange
   lanyard; a brown clipboard with white paper.
15_host.png: only these separate pieces: a purple sparkly game-show blazer torso with red bow tie and gold
   buttons (no head or arms); one blazer upper arm and forearm with white cuff; a handheld microphone.
```

---

## Checking each image before you save it
- Matches the app's Riot: the same face, not just "a fox".
- Plain white background, nothing touching, no shadows.
- Only the requested part; regenerate anything with extra body parts.
- Same style as the earlier images. If it drifts, re-attach the reference and say
  "match the style of the earlier images exactly".

When Riot is done, the friends (Bash 🐻, Pip 🐰, Rocco 🦝) follow the same list: swap the character
description and colours (see CHARACTERS.md), and attach `refs/<name>_sheet.png` as the reference.
