# Location reference plates: each set empty and with the cast seated, 9:16.
#   Blender --background --python locref.py           -> refs/loc_<name>_{empty,cast}.png + .blend
#   SCALE=50 Blender ... (percent, for quick previews)
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from toon import *
import cast, locations

OUT = os.path.join(HERE, "refs")
pct = int(os.environ.get("SCALE", "100"))
ONLY = os.environ.get("ONLY")
SETS = [("living_room_day", lambda: locations.living_room("day")),
        ("living_room_night", lambda: locations.living_room("night")),
        ("car", locations.car), ("campfire", locations.campfire),
        ("game_show", locations.game_show), ("village_night", locations.village_night), ("party_room", locations.party_room)]

# TikTok / Reels UI covers these parts of a 1080x1920 frame (px): keep text and faces out of them.
SAFE_TOP, SAFE_BOTTOM, SAFE_RIGHT, RIGHT_TOP = 220, 440, 140, 1100


def dashed(name, x0, y0, x1, y1, color, parent, z, dash=0.5):
    edges = [((x0, y0), (x1, y0)), ((x1, y0), (x1, y1)), ((x1, y1), (x0, y1)), ((x0, y1), (x0, y0))]
    for i, (a, b) in enumerate(edges):
        n = max(1, int(Vector((b[0] - a[0], b[1] - a[1])).length / dash))
        for k in range(0, n, 2):
            p0 = Vector(a).lerp(Vector(b), k / n)
            p1 = Vector(a).lerp(Vector(b), min(k + 1, n) / n)
            stroke(f"{name}{i}_{k}", [tuple(p0), tuple(p1)], 0.09, color, parent, z)


def guide(loc):
    """Numbered seats + platform safe zones, framed for loc.cam."""
    cx, cy, ortho = loc.cam
    u = ortho / 1920  # world units per pixel
    top, bot = cy + ortho / 2, cy - ortho / 2
    left, right = cx - ortho * 1080 / 1920 / 2, cx + ortho * 1080 / 1920 / 2
    g = empty("guide", None, (0, 0), 40)
    for i, (x, hip, s, z) in enumerate(loc.seats):
        b = empty(f"seat{i}", g, (x, hip - 0.9), 0)
        shape(f"seat{i}_c", ell(0, 0, 0.55, 0.55), ORANGE, b, 0.0, ol=0.07)
        text(f"seat{i}_n", str(i), 0.75, "#FFFFFF", b, (0, -0.03), 0.01)
    zones = (("TOP UI", left, top - SAFE_TOP * u, right, top),
             ("CAPTION + AUDIO", left, bot, right, bot + SAFE_BOTTOM * u),
             ("BUTTONS", right - SAFE_RIGHT * u, bot + SAFE_BOTTOM * u, right, bot + RIGHT_TOP * u))
    for name, x0, y0, x1, y1 in zones:
        m = 0.12
        dashed(f"zone_{name}", x0 + m, y0 + m, x1 - m, y1 - m, CORAL, g, 0.0)
        t = text(f"zone_{name}_t", name, 0.5, CORAL, g, ((x0 + x1) / 2, (y0 + y1) / 2), 0.01)
        if name == "BUTTONS":
            t.rotation_euler.z = rad(90)
    text("guide_note", "keep faces + text inside the dashed-free area", 0.42, CORAL, g, (cx, bot + SAFE_BOTTOM * u - 0.5), 0.01)


for key, fn in SETS:
    if ONLY and ONLY != key:
        continue
    sc = reset()
    setup_render(sc, 1080, 1920)
    sc.render.resolution_percentage = pct
    loc = fn()
    camera(sc, *loc.cam)
    still(sc, os.path.join(OUT, f"loc_{key}_empty.png"))
    seated = [cast.bear(), cast.bunny(), cast.riot(), cast.raccoon()]
    if key == "car":  # Bash drives, Riot rides shotgun
        order = [3, 0, 2, 1]
    else:
        order = [0, 1, 2, 3]
    for c, i in zip(seated, order):
        loc.seat(c, i)
    still(sc, os.path.join(OUT, f"loc_{key}_cast.png"))
    guide(loc)
    still(sc, os.path.join(OUT, f"loc_{key}_guide.png"))
    bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, f"loc_{key}.blend"))
