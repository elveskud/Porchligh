# Friendzy motion library: reusable, polished moves built on the classic principles
# (anticipation, squash & stretch, overshoot, follow-through, secondary motion, eased timing, holds).
#
#   a = motion.Anim(riot)                 # one per character; idle (breathing, blinks, tail sway) is automatic
#   motion.take(a, 30, "shocked")         # moves add layers / events starting at a frame
#   motion.talk(a, 60, "vo/line.wav")
#   a.bake(0, 120)                        # keys every frame (do this last)
#
#   motion.pop_in(card, 20); motion.slam_in(stamp, 40)      # prop moves
#   cam = motion.CamAnim(sc.camera); cam.push(30, 50, (x, y, ortho)); cam.shake(40, 12, 0.4); cam.bake(0, 120)
# Every move is shown in refs/motion/ (clips + contact sheet), made by motionref.py.
import math, random, os, json, subprocess
import wave as wavfile  # (motion.wave is the hand-wave move)
import numpy as np
from toon import *
import cast

FPS = 30


# ---------- easing ----------

def clamp01(t):
    return min(max(t, 0.0), 1.0)

def _back(t, s=1.9):
    t -= 1
    return 1 + (s + 1) * t ** 3 + s * t ** 2

def _elastic(t, freq=2.2, decay=5.5):
    return 1 - math.exp(-decay * t) * math.cos(2 * math.pi * freq * t) if t < 1 else 1.0

EASE = {
    "linear": lambda t: t,
    "smooth": lambda t: t * t * (3 - 2 * t),
    "out": lambda t: 1 - (1 - t) ** 3,       # fast start, soft landing
    "in": lambda t: t ** 3,                  # slow start, hard stop (falls, slams)
    "back": _back,                           # overshoot then settle
    "elastic": _elastic,                     # wobble into place
    "look": lambda t: _back(t, 1.2),         # head turns: ~7% overshoot, then settle
}


def curve(f, keys):
    """keys = [(frame, value, ease used to arrive at this key), ...]; holds before the first and after the last."""
    if f <= keys[0][0]:
        return keys[0][1]
    for (f0, v0, _), (f1, v1, e) in zip(keys, keys[1:]):
        if f <= f1:
            t = (f - f0) / (f1 - f0) if f1 > f0 else 1.0
            return v0 + (v1 - v0) * EASE[e](clamp01(t))
    return keys[-1][1]


def envelope(f, f0, f1, ramp=5):
    """0 -> 1 -> 0 over [f0, f1] with eased ramps; for moves that loop while held."""
    if f < f0 or f > f1:
        return 0.0
    return EASE["smooth"](clamp01((f - f0) / ramp)) * EASE["smooth"](clamp01((f1 - f) / ramp))


# ---------- character animation ----------

ADD = {"x", "y", "rot", "head_rot", "head_y", "head_x", "turn", "ears", "tail", "brow", "brow_rot", "face_y", "lean", "jaw",
       "tw1", "tw-1", "stride"}
GESTURE_Z = 2.4  # neighbours on a couch sit 1.5 apart in depth; gestures must clear the next one
MUL = {"sq", "mouth", "head_sq"}  # squash: >1 tall & thin, <1 short & wide (volume preserved); mouth: >1 stretched open
ACT = 1.0   # acting strength: one knob for the size of every performance (talk, listen, laugh, takes, points...)
HIP = 3.2   # body-space height the torso bends around ("lean", degrees, + = toward the viewer's right)
# talk-gesture habits per character: (how often, how big). Riot and Bash talk with their hands; Pip keeps
# them close; Rocco is deadpan and barely moves them
GESTURE_STYLE = {"riot": (1.0, 1.0), "bash": (1.0, 1.15), "pip": (0.55, 0.7), "rocco": (0.25, 0.6)}
GESTURES = [(30, 72, "open"), (22, 118, "point"), (26, 92, "fist"), (40, 50, "open")]  # (shoulder, elbow, hand)
# ears and tail act with the face. Ears: degrees, + = droop outward / pinned back, - = perked up
EAR_MOOD = {"nervous": 16, "sleepy": 18, "pouting": 14, "yelling": 9, "suspicious": 6, "disgusted": 8,
            "shocked": -10, "hype": -6, "laughing": -4, "smug": -3, "soft": 7, "sad": 14, "scared": 18,
            "embarrassed": 8, "determined": -4, "asleep": 20}
# tail: (sway degrees, sway period in frames, offset degrees: + = up and proud, - = drooping / tucked)
TAIL_MOOD = {"hype": (14, 22, 8), "laughing": (12, 18, 6), "cocky": (9, 40, 6), "smug": (8, 48, 6),
             "nervous": (3, 7, -14), "shocked": (2, 10, 12), "sleepy": (2, 120, -10), "pouting": (3, 90, -12),
             "suspicious": (4, 90, -4), "soft": (5, 64, 4),
             "sad": (2, 100, -14), "scared": (3, 8, -16), "embarrassed": (4, 60, -6), "determined": (6, 40, 6),
             "asleep": (1, 140, -12)}
TAIL_IDLE = (7, 64, 0)
# face colour: (red flush opacity, dread) per expression; the blue dread lines show above 0.7
# sly faces raise one brow (the other dips a little)
BROW_ASYM = {"suspicious": 0.13, "smug": 0.15, "cocky": 0.11, "side_eye_l": 0.1, "side_eye_r": 0.1, "disgusted": 0.09}
# pupils shrink in shock and anger, widen when excited or begging
PUPIL_SIZE = {"scared": 0.62, "shocked": 0.68, "yelling": 0.82, "suspicious": 0.85, "nervous": 0.9, "hype": 1.15, "happy": 1.06, "pouting": 1.32}
SLOW_BLINK = {"sleepy", "smug", "cocky", "sad", "soft"}  # lazy, slow blinks
IMPACTS = []  # frames where a take hits in this scene: CamAnim punches in and shakes on each


def _fidget_riot(t, n):   # can't sit still: two quick bounces, head bob, tail goes
    b = abs(math.sin(math.pi * t / (n / 2)))
    return {"y": 0.12 * ACT * b, "sq": 1 - 0.03 * b, "head_rot": 3 * math.sin(math.pi * t / n * 2), "tail": 10 * math.sin(t * 0.9)}

def _fidget_bash(t, n):   # a big huff: puff up, then deflate with a frown
    u = math.sin(math.pi * clamp01(t / (n * 0.45)))
    dn = math.sin(math.pi * clamp01((t - n * 0.45) / (n * 0.55)))
    return {"sq": 1 + 0.05 * ACT * u - 0.03 * dn, "y": 0.06 * u, "head_y": 0.05 * u - 0.06 * dn, "brow": -0.05 * dn}

def _fidget_pip(t, n):    # nervous glance left and right, ears flick
    return {"turn": 0.45 * math.sin(2 * math.pi * t / n), "sq": 1 - 0.025 * math.sin(math.pi * t / n), "tw1": 12 * math.sin(math.pi * t / 8) * (t < 8)}

def _fidget_rocco(t, n):  # a chip to the mouth, two chews
    w = envelope(t, 0, n, 6)
    chew = abs(math.sin(math.pi * max(0, t - 8) / 5)) if 8 <= t <= n - 6 else 0.0
    return {"face-1": w, "face_y": -1.25 * w, "jaw": 0.12 * chew, "head_y": -0.03 * chew}

FIDGETS = {"riot": (_fidget_riot, 20), "bash": (_fidget_bash, 28), "pip": (_fidget_pip, 26), "rocco": (_fidget_rocco, 30)}
FACE_TINT = {"yelling": (0.38, 0), "laughing": (0.14, 0), "pouting": (0.2, 0), "shocked": (0, 0.9), "nervous": (0, 0.2),
             "disgusted": (0, 0.3), "embarrassed": (0.32, 0), "scared": (0, 0.6), "sad": (0, 0.12)}


class Anim:
    """Layered animation for one character. Moves add layers (fn(frame) -> channels) and events;
    bake() mixes them with idle motion and springs and inserts keyframes."""

    def __init__(self, c, idle=True, seed=None):
        self.c = c
        self.loc0 = Vector(c.root.location)
        self.s0 = c.root.scale.x
        self.layers, self.events = [], []
        self.exprs = [(-999, c.current)]
        self.turns = [(-999, 0.0, "smooth")]
        self.ups = [(-999, 0.0, "smooth")]  # vertical gaze: + = looking up (the porch light), - = down (the phone)
        self.idle = idle
        self.seed = seed if seed is not None else sum(map(ord, c.name))

    def add(self, fn):
        self.layers.append(fn)

    def at(self, frame, fn, prio=1):
        self.events.append((frame, prio, fn))

    def expr(self, frame, name):
        self.exprs.append((frame, name))

    def expr_at(self, f):
        return max((e for e in self.exprs if e[0] <= f), key=lambda e: e[0])[1]

    def look(self, frame, t, dur=6, ease="look"):
        """Head turn that overshoots a little and settles; the body follows a few frames later. It starts with a small
        dip the other way (anticipation), and a big turn gets a blink, like a real head turn."""
        prev = self.turns[-1][1]
        dip = prev - 0.1 * math.copysign(1, t - prev) if abs(t - prev) > 0.15 and dur >= 4 else prev
        self.turns += [(frame, prev, "smooth"), (frame + 2, dip, "out"), (frame + dur + 1, t, ease)] if dip != prev else \
                      [(frame, prev, "smooth"), (frame + dur, t, ease)]
        if abs(t - prev) > 0.45:
            self.turn_blinks = getattr(self, "turn_blinks", []) + [frame]

    def look_up(self, frame, v, dur=6):
        """Eyes up (+) or down (-), -1..1, easing over `dur` frames; combine with look() for diagonals."""
        prev = self.ups[-1][1]
        self.ups += [(frame, prev, "smooth"), (frame + dur, v, "look")]

    def bake(self, f0, f1):
        c = self.c
        head = c.extras["head"]
        hy0, hx0 = head.location.y, head.location.x
        ears = [(s, c.extras[f"ear{s}"]) for s in (-1, 1) if f"ear{s}" in c.extras]
        for s, e in ears:
            if "r0" not in e:
                e["r0"] = e.rotation_euler.z
        tail = c.extras.get("tail")
        if tail is not None and "r0" not in tail:
            tail["r0"] = tail.rotation_euler.z
        # expressions snap over 2 frames; each change gets a blink (hides the swap) and a small accent
        ex = sorted(e for e in self.exprs if f0 - 999 <= e[0] <= f1)
        changes = [fb for (fa, na), (fb, nb) in zip(ex, ex[1:]) if fb > f0 and na != nb]
        rnd = random.Random(self.seed)
        blinks, twitches = [], []
        for fb in changes:
            arc = self.expr_at(fb - 3) in cast.ARC_EYES or self.expr_at(fb) in cast.ARC_EYES
            if not arc and all(abs(fb - 2 - b) >= 12 for b in blinks):
                blinks.append(fb - 2)
        f = f0 + rnd.randint(18, 50)
        while f < f1 - 4:
            if self.expr_at(f) not in cast.ARC_EYES and all(abs(f - b) >= 10 for b in blinks):
                blinks.append(f)
            f += rnd.randint(55, 105)
        f = f0 + rnd.randint(40, 90)
        while f < f1 - 8:
            twitches.append((f, rnd.choice((-1, 1))))
            f += rnd.randint(80, 150)
        darts = []  # little eye movements during holds, so a held face never looks frozen
        if self.idle:
            for fb in getattr(self, "turn_blinks", []):
                if f0 <= fb < f1 - 4 and self.expr_at(fb) not in cast.ARC_EYES and all(abs(fb - b) >= 8 for b in blinks):
                    blinks.append(fb)
            r2 = random.Random(self.seed * 7 + 1)
            f = f0 + r2.randint(15, 40)
            while f < f1 - 6:
                darts.append((f, r2.randint(6, 16), r2.uniform(-0.07, 0.07), r2.uniform(-0.035, 0.035)))
                f += r2.randint(22, 55)
            for b in sorted(blinks):  # one blink in four is a quick double blink
                if r2.random() < 0.25 and b + 5 < f1 - 3 and all(abs(b + 5 - o) >= 4 for o in blinks if o != b):
                    blinks.append(b + 5)
            # personality fidgets fill the quiet stretches (no move, line or reaction running)
            fn, n_ = FIDGETS.get(c.name, (None, 0))
            if fn:
                busy = {fr for fr in range(f0, f1 + 1) if any(L(fr) for L in self.layers)}
                f = f0 + r2.randint(50, 110)
                while f < f1 - n_ - 6:
                    if not any(fr in busy for fr in range(f - 8, f + n_ + 8)) and self.expr_at(f) not in ("laughing", "sleepy"):
                        self.add(lambda fr, g=f: fn(fr - g, n_) if g <= fr < g + n_ else None)
                        f += r2.randint(100, 170)
                    else:
                        f += 12

        def dart_at(fr):
            for d0, n_, dx, dy in darts:
                if d0 <= fr < d0 + n_:
                    return dx, dy
            return 0.0, 0.0

        def pupil_at(fr):
            """Expression pupil offset at fr, switched over the same 2-frame snap as the rest of the face."""
            v = cast.EXPRESSIONS[self.expr_at(fr)][3]
            nxt = next(((fb, nb) for fb, nb in ex if 0 < fb - fr <= 2), None)
            if nxt is None:
                return v
            n_, w = cast.EXPRESSIONS[nxt[1]][3], 1 - (nxt[0] - fr) / 2
            return v[0] + (n_[0] - v[0]) * w, v[1] + (n_[1] - v[1]) * w

        fx = cast.face_fx(c)
        mouth = next(iter(c.mouths.values())).parent if c.mouths else None
        strings = [o for o in (c.extras.get("body") or next((o for o in c.root.children if o.name.endswith("_body")), c.root)).children
                   if o.type == "MESH" and ("_string" in o.name or o.name in ("riot_tie",))]
        for o in strings:
            cast.repivot(o)
            o["r0"] = o.rotation_euler.z
        e0 = self.expr_at(f0)
        ear_mood = EAR_MOOD.get(e0, 0.0)                       # followers start settled (sticker loops stay exact)
        t_amp, t_per, t_off = TAIL_MOOD.get(e0, TAIL_IDLE)
        t_ph = 2 * math.pi * (f0 + self.seed) / t_per
        flush, dread = FACE_TINT.get(e0, (0, 0))
        spark_on = [fb for fb in changes if self.expr_at(fb) in ("hype", "laughing")]
        str_th = str_w = land = 0.0
        fx_vis = {}
        fx_gy, fx_zy = fx["gloom"].location.y, fx["zzz"].location.y
        p_size = PUPIL_SIZE.get(e0, 1.0)
        b_asym = BROW_ASYM.get(e0, 0.0)
        a_side = 1 if self.seed % 2 else -1  # which brow this character raises
        el_off, el_w, prev_sh, h_str = {1: 0.0, -1: 0.0}, {1: 0.0, -1: 0.0}, {1: cast.REST[0], -1: cast.REST[0]}, {1: 1.0, -1: 1.0}
        my0 = mouth.location.y if mouth is not None else 0.0
        accs = [o for o in (c.extras.get("hat"), c.extras.get("visor")) if o is not None]  # hats lag the head
        for o in accs:
            o["r0"], o["y0"] = o.get("r0", o.rotation_euler.z), o.get("y0", o.location.y)
        acc_th = acc_w = acc_y = acc_yw = 0.0
        laugh_run = 0
        turn_keys = sorted(self.turns, key=lambda k: k[0]) + [(f1 + 1, self.turns[-1][1], "linear")]
        up_keys = sorted(self.ups, key=lambda k: k[0]) + [(f1 + 1, self.ups[-1][1], "linear")]

        def face_at(fr):
            """(brow angle, brow lift, eye squash) at fr, blended over the 2-frame expression snap."""
            v = cast.EXPRESSIONS[self.expr_at(fr)]
            nxt = next(((fb, nb) for fb, nb in ex if 0 < fb - fr <= 2), None)
            if nxt is None:
                return v[1], v[2], v[4]
            n, w = cast.EXPRESSIONS[nxt[1]], 1 - (nxt[0] - fr) / 2
            return tuple(p + (q - p) * w for p, q in ((v[1], n[1]), (v[2], n[2]), (v[4], n[4])))

        # torso bend: the body pivots at the hips while the legs stay planted
        body = c.extras.get("body") or next((o for o in c.root.children if o.name.endswith("_body")), None)
        legs = [(o, o.location.x, o.location.y, o.rotation_euler.z) for o in (body.children if body else ()) if "_leg" in o.name]
        held = {1: "mic" in c.extras, -1: "clipboard" in c.extras or "chips" in c.extras}  # paws busy with a prop

        BLINK = {0: 0.55, 1: 1.0, 2: 0.55}  # how closed, by frame from the blink start
        BLINK_SLOW = {0: 0.3, 1: 0.6, 2: 0.85, 3: 1.0, 4: 1.0, 5: 0.8, 6: 0.5, 7: 0.2}
        ear_th = ear_w = tail_th = tail_w = lag_th = lag_w = lean_lag = 0.0
        prev_y = prev_x = prev_h = prev_t = None
        prev_vy = 0.0
        hand_vis = {1: None, -1: None}
        for f in range(f0, f1 + 1):
            ch = {k: 0.0 for k in ADD}
            ch["sq"] = ch["mouth"] = ch["head_sq"] = 1.0
            ch["turn"] = curve(f, turn_keys)
            lead = max(-0.09, min(0.09, (curve(f + 3, turn_keys) - ch["turn"]) * 0.3))  # the eyes get there first
            tb = curve(f - 3, turn_keys)  # the body follows the head 3 frames late
            ch["x"] += 0.05 * tb
            ch["lean"] += 3.0 * tb  # the spine bends toward the look
            arms, elbows, hands, face, fing, reach = {}, {}, {}, {}, {}, {}
            gest = None
            for L in self.layers:
                d = L(f) or {}
                for k, v in d.items():
                    if k == "gesture":
                        gest = v
                    elif k in ADD:
                        ch[k] += v
                    elif k in MUL:
                        ch[k] *= v
                    elif k.startswith("arm"):
                        arms[int(k[3:])] = v
                    elif k.startswith("elbow"):
                        elbows[int(k[5:])] = v
                    elif k.startswith("hand"):
                        hands[int(k[4:])] = v
                    elif k.startswith("face"):
                        face[int(k[4:])] = v
                    elif k.startswith("finger"):
                        fing[int(k[6:])] = v
                    elif k.startswith("reach"):  # (x, y, weight, hand): IK the paw to a point in body space
                        reach[int(k[5:])] = v
            for s in reach:
                arms.setdefault(s, cast.REST[0])
            if gest:  # talk gestures only use a free paw: any move or prop driving an arm wins
                pref, sh, el, hd, w, both = gest
                free = [s for s in (pref, -pref) if s not in arms and s not in face and not held[s]]
                for s in (free if both else free[:1]):
                    arms[s] = cast.REST[0] + (sh - cast.REST[0]) * w
                    elbows[s] = cast.REST[1] + (el - cast.REST[1]) * w
                    hands[s] = hd if w > 0.4 else cast.REST[2]
            for side in (1, -1):  # a raised arm never freezes: slow drift through holds
                w = clamp01((arms.get(side, cast.REST[0]) - 20) / 30)
                if w:
                    ph = 2 * math.pi * (f + self.seed * side)
                    arms[side] += w * 1.8 * math.sin(ph / 43)
                    elbows[side] = elbows.get(side, cast.REST[1]) + w * 2.2 * math.sin(ph / 57 + 1.1)
            for side in (1, -1):  # follow-through: the forearm drags behind a fast shoulder swing, then whips past
                sh = arms.get(side, cast.REST[0])
                dsh, prev_sh[side] = sh - prev_sh[side], sh
                el_w[side] += 0.3 * (max(-25.0, min(25.0, -0.6 * dsh)) - el_off[side]) - 0.3 * el_w[side]
                el_off[side] += el_w[side]
                if abs(el_off[side]) > 0.05:
                    elbows[side] = elbows.get(side, cast.REST[1]) + el_off[side]
                h_str[side] = 1 + min(0.35, max(0.0, abs(dsh) - 6) * 0.025)  # smear: the paw stretches on a fast swing
            for fb in changes:  # expression change accent: a small pop of the body and brows
                if 0 <= f - fb < 8:
                    b = math.sin(math.pi * (f - fb) / 8)
                    ch["sq"] *= 1 + 0.025 * b
                    ch["brow"] += 0.06 * b
            breathe = 1.0
            if self.idle:
                ph = 2 * math.pi * (f + self.seed) / 78
                breathe = 1 + 0.012 * math.sin(ph)
                ch["head_y"] += 0.035 * math.sin(ph - 0.9)
                ta, tp, to = TAIL_MOOD.get(self.expr_at(f), TAIL_IDLE)  # the tail wags with the mood
                t_amp += 0.12 * (ta - t_amp)
                t_off += 0.12 * (to - t_off)
                t_per += 0.2 * (tp - t_per)
                ch["tail"] += t_amp * math.sin(t_ph) + t_off
                t_ph += 2 * math.pi / t_per
                for t0, side in twitches:
                    if 0 <= f - t0 < 9:
                        ch[f"tw{side}"] = 14 * math.sin(math.pi * (f - t0) / 9)

            # springs: ears and tail lag behind vertical / sideways motion, then settle
            y, x = ch["y"], ch["x"]
            vy = 0.0 if prev_y is None else y - prev_y
            vx = 0.0 if prev_x is None else x - prev_x
            ay = vy - prev_vy
            if prev_vy < -0.025 and ay > 0.02:  # landing: a quick squash whenever a fall stops, then it springs back
                land = max(land, min(0.09, -prev_vy * 0.5))
            prev_y, prev_x, prev_vy = y, x, vy
            ear_t = max(-22.0, min(22.0, vy * 22 + ay * 30))
            ear_w += 0.3 * (ear_t - ear_th) - 0.3 * ear_w
            ear_th = max(-28.0, min(28.0, ear_th + ear_w))
            # ...and ears also drag behind head tilts and turns (both ears swing the same way)
            dh = 0.0 if prev_h is None else ch["head_rot"] - prev_h
            dt = 0.0 if prev_t is None else ch["turn"] - prev_t
            prev_h, prev_t = ch["head_rot"], ch["turn"]
            lag_t = max(-16.0, min(16.0, -dh * 2.2 + dt * 40))
            lag_w += 0.3 * (lag_t - lag_th) - 0.3 * lag_w
            lag_th = max(-20.0, min(20.0, lag_th + lag_w))
            tail_t = max(-25.0, min(25.0, -vx * 60 - vy * 18 - dt * 30))
            tail_w += 0.22 * (tail_t - tail_th) - 0.24 * tail_w
            tail_th = max(-30.0, min(30.0, tail_th + tail_w))

            # smear: fast vertical moves stretch the body, and the head drags a beat behind them
            sq = ch["sq"] * (1 + min(0.1, max(0.0, abs(vy) - 0.04) * 0.45)) * (1 - land)
            land *= 0.6
            ch["head_y"] -= max(-0.1, min(0.1, 0.35 * vy))
            ear_mood += 0.25 * (EAR_MOOD.get(self.expr_at(f), 0.0) - ear_mood)
            ch["ears"] += ear_mood
            # overlap: when the torso bends, the head stays upright for a few frames, then mostly follows
            lean = ch["lean"]
            lean_lag += 0.3 * (lean - lean_lag)
            ch["head_rot"] += (lean - lean_lag) + 0.3 * lean_lag
            if body is not None:
                th = -rad(lean)
                cs, sn = math.cos(th), math.sin(th)
                body.location.x, body.location.y = sn * HIP, HIP * (1 - cs)  # rotate about (0, HIP)
                body.rotation_euler.z = th
                body.keyframe_insert("location", frame=f)
                body.keyframe_insert("rotation_euler", frame=f)
                for leg, lx, ly, lr in legs:  # undo the bend so the legs stay where they were
                    dx, dy = lx - body.location.x, ly - body.location.y
                    leg.location.x, leg.location.y = cs * dx + sn * dy, -sn * dx + cs * dy
                    leg.rotation_euler.z = lr - th + rad(ch["stride"]) * (-1 if leg.name.endswith("-1") else 1)  # walking
                    leg.keyframe_insert("location", frame=f)
                    leg.keyframe_insert("rotation_euler", frame=f)
            # hoodie strings / tie hang from the chest: they swing against sideways moves and bends, then settle
            str_t = max(-35.0, min(35.0, lean * 0.8 - vx * 160 - (lean - lean_lag) * 2.0 + ch["head_rot"] * 0.1))
            str_w += 0.25 * (str_t - str_th) - 0.22 * str_w
            str_th += str_w
            for o in strings:
                o.rotation_euler.z = o["r0"] + rad(str_th)
                o.keyframe_insert("rotation_euler", frame=f)
            if mouth is not None:  # loud syllables stretch the mouth open, and the jaw drops with them
                mouth.scale = (1 + 0.3 * (ch["mouth"] - 1), ch["mouth"], 1)
                mouth.location.y = my0 - ch["jaw"]
                mouth.keyframe_insert("scale", frame=f)
                mouth.keyframe_insert("location", index=1, frame=f)
            if accs:  # hats and visors lag a beat behind the head, then catch up
                acc_w += 0.3 * (max(-12.0, min(12.0, -dh * 1.6)) - acc_th) - 0.28 * acc_w
                acc_th += acc_w
                acc_yw += 0.3 * (max(-0.2, min(0.2, -vy * 1.2)) - acc_y) - 0.25 * acc_yw
                acc_y += acc_yw
                for o in accs:
                    o.rotation_euler.z = o["r0"] + rad(acc_th)
                    o.location.y = o["y0"] + acc_y
                    o.keyframe_insert("rotation_euler", frame=f)
                    o.keyframe_insert("location", index=1, frame=f)
            r = c.root
            r.location = self.loc0 + Vector((x * self.s0, y * self.s0, 0))
            r.scale = (self.s0 / math.sqrt(sq), self.s0 * sq * breathe, 1)
            r.rotation_euler.z = rad(ch["rot"])
            r.keyframe_insert("location", frame=f)
            r.keyframe_insert("scale", frame=f)
            r.keyframe_insert("rotation_euler", frame=f)

            head.rotation_euler.z = rad(ch["head_rot"])
            head.location.x, head.location.y = hx0 + ch["head_x"], hy0 + ch["head_y"]
            head.scale = (1 / math.sqrt(ch["head_sq"]), ch["head_sq"], 1)
            head.keyframe_insert("rotation_euler", frame=f)
            head.keyframe_insert("location", frame=f)
            head.keyframe_insert("scale", frame=f)

            for side, a in c.arms.items():
                sh = arms.get(side, cast.REST[0])
                el = elbows.get(side, cast.REST[1])
                hd = hands.get(side, "point" if fing.get(side) else cast.REST[2])
                r1, r2, z = rad(sh) * side, rad(el) * side, a["z0"]
                w = face.get(side, 0.0)
                if side in reach:  # blend toward a two-bone IK reach to any point (claps, hands together)
                    rx_, ry_, rw, rh = reach[side]
                    t1, t2 = c.ik(side, (rx_, ry_))
                    r1, r2 = r1 + (t1 - r1) * rw, r2 + (t2 - r2) * rw
                    if rw > 0.5:
                        z, hd = 0.7, rh
                elif w > 0:  # blend toward a two-bone IK reach to the face
                    t1, t2 = c.ik(side, (head.location.x + 0.35 * side, head.location.y + 1.95 + ch["face_y"]))  # face_y < 0: the mouth
                    r1, r2 = r1 + (t1 - r1) * w, r2 + (t2 - r2) * w
                    if w > 0.5:
                        z, hd = 0.7, hands.get(side, "open")  # facepalm: open; a "shh" passes point
                elif sh < 0 or el < -30:
                    z = a["z0"] + 0.25  # forearms folded in front of the body
                if w <= 0.5 and hd != "paw" and (sh > 30 or abs(el) > 40):
                    z = GESTURE_Z  # a gesturing arm comes in front of whoever sits next to us
                a.rotation_euler.z, a.location.z = r1, z
                c.elbows[side].rotation_euler.z = r2
                a.keyframe_insert("rotation_euler", frame=f)
                a.keyframe_insert("location", frame=f)
                c.elbows[side].keyframe_insert("rotation_euler", frame=f)
                hr = c.extras[f"hand{side}"]
                hr.scale.y = h_str[side]
                hr.keyframe_insert("scale", index=1, frame=f)
                if hd != hand_vis[side]:
                    c.hand(side, hd, f)
                    hand_vis[side] = hd

            for side, e in ears:
                e.rotation_euler.z = e["r0"] + rad(-side * (ear_th + ch["ears"]) + side * ch.get(f"tw{side}", 0.0) + lag_th)
                e.keyframe_insert("rotation_euler", frame=f)
            if tail is not None:
                tail.rotation_euler.z = tail["r0"] + rad(ch["tail"] + tail_th)
                tail.keyframe_insert("rotation_euler", frame=f)

            # brows and eye squash are keyed here every frame (turn() keys their x / scale, so set them first)
            ang, lift, sq_eye = face_at(f)
            name = self.expr_at(f)
            b_asym += 0.3 * (BROW_ASYM.get(name, 0.0) - b_asym)
            for side, b in c.brows:
                b.rotation_euler.z = rad(ang + ch["brow_rot"]) * side
                b.location.y = b["y0"] + lift + ch["brow"] + b_asym * (1.0 if side == a_side else -0.35)
                b.keyframe_insert("rotation_euler", frame=f)
            close = max(((BLINK_SLOW if self.expr_at(b) in SLOW_BLINK else BLINK).get(f - b, 0.0) for b in blinks), default=0.0)
            for e in c.eyes:
                e.scale.y = sq_eye + (0.1 - sq_eye) * close
            c.turn(ch["turn"], frame=f)
            for side, b in c.brows:
                b.keyframe_insert("location", frame=f)
            for e in c.eyes:
                e.keyframe_insert("scale", frame=f)
            (px, py), (dx, dy) = pupil_at(f), dart_at(f)
            p_size += 0.3 * (PUPIL_SIZE.get(name, 1.0) - p_size)
            for side, p in c.pupils:
                p.location.x, p.location.y = p["x0"] + px + dx + lead, p["y0"] + py + dy + 0.13 * curve(f, up_keys)
                p.scale = (p_size, p_size, 1)
                p.keyframe_insert("location", frame=f)
                p.keyframe_insert("scale", frame=f)

            # face colour and emotion marks follow the expression
            laugh_run = laugh_run + 1 if name == "laughing" else 0
            tf, td = FACE_TINT.get(name, (0, 0))
            flush += 0.2 * (tf - flush)
            dread += 0.2 * (td - dread)
            m = fx["flush"].material_slots[0].material
            m.diffuse_color[3] = max(0.0001, flush)
            m.keyframe_insert("diffuse_color", index=3, frame=f)
            on = {"pale": dread > 0.7, "vein": name == "yelling",  # dread lines only for real shock
                  "sparkle": any(0 <= f - fb < 20 for fb in spark_on), "gloom": bool(getattr(self, "glooms", None)) and
                  any(g0 <= f <= g1 for g0, g1 in self.glooms), "tears": laugh_run > 30, "zzz": name == "sleepy"}
            if not self.idle:  # stickers run their own loop clock: no marks with timers of their own
                on = dict.fromkeys(on, False)
            for k, v in on.items():
                if v != fx_vis.get(k):
                    set_visible(fx[k], v, f)
                    fx_vis[k] = v
            pump = 1 + 0.15 * abs(math.sin(f * 0.5))  # the vein throbs, sparkles twinkle, the cloud bobs
            fx["vein"].scale = (0.75 * pump, 0.75 * pump, 1)
            fx["sparkle"].scale = (0.9 * (0.8 + 0.3 * abs(math.sin(f * 0.35))),) * 2 + (1,)
            fx["gloom"].location.y = fx_gy + 0.08 * math.sin(f * 0.15)
            fx["zzz"].location.y = fx_zy + 0.5 * ((f % 40) / 40)  # the z's drift up and start again
            fx["tears"].scale = (1, 1 + 0.25 * abs(math.sin(f * 0.6)), 1)  # tears of laughter wobble
            for k in ("vein", "sparkle", "tears"):
                fx[k].keyframe_insert("scale", frame=f)
            fx["gloom"].keyframe_insert("location", frame=f)
            fx["zzz"].keyframe_insert("location", frame=f)

        # expressions: mouth and eye shape snap over 2 frames (hold the previous face until then)
        c.expr(ex[0][1], frame=f0, face=False, pupils=False)
        for (fa, na), (fb, nb) in zip(ex, ex[1:]):
            if fb > f0:
                c.expr(na, frame=max(f0, fb - 2), face=False, pupils=False)
                c.expr(nb, frame=fb, face=False, pupils=False)
        for fr, _, fn in sorted(self.events, key=lambda e: (e[0], e[1])):
            fn(fr)


def mouth_at(c, k, f):
    for name, m in c.mouths.items():
        set_visible(m, name == k, f)


# ---------- moves ----------

def impact(c, f, dur=3):
    """Comic impact frame: a yellow burst and black action lines flash behind the head for `dur` frames."""
    head = c.extras["head"]
    hw, top = cast.face_box(c)
    g = empty(f"{c.name}_impact{f}", head, (0, top * 0.45), -1.0)
    r0, r1 = hw * 1.15, hw * 1.6
    pts = [(math.cos(math.pi * i / 9) * (r1 if i % 2 == 0 else r0), math.sin(math.pi * i / 9) * (r1 if i % 2 == 0 else r0), "s") for i in range(18)]
    shape(f"{c.name}_impact{f}_burst", pts, YELLOW, g, 0.0, ol=0.08, smooth=0)
    for i in range(12):
        ang = 2 * math.pi * (i + 0.5) / 12
        l0, l1 = r1 * 1.05, r1 * (1.55 if i % 2 else 1.35)
        stroke(f"{c.name}_impact{f}_l{i}", [(math.cos(ang) * l0, math.sin(ang) * l0), (math.cos(ang) * l1, math.sin(ang) * l1)],
               0.12, OUTLINE, g, 0.01, w1=0.02)
    set_visible(g, False, 0)
    set_visible(g, True, f)
    set_visible(g, False, f + dur)
    for fr, s in ((f, 0.7), (f + 1, 1.1), (f + 2, 1.0)):
        g.scale = (s, s, 1)
        g.keyframe_insert("scale", frame=fr)


def take(a, f, expr="shocked", big=1.0, impact_frame=True):
    """Shocked take: squash down (anticipation) -> stretch + pop up -> fall -> land squash -> wobble settle."""
    a.expr(f + 3, expr)
    big *= 1.25 * ACT
    seen = curve(f, sorted(getattr(a, "turns", [(0, 0.0, "linear")]), key=lambda k: k[0]))  # recoil away from what we see
    away = -math.copysign(1, seen) if abs(seen) > 0.2 else 0.0
    if impact_frame:
        a.at(f + 6, lambda fr: impact(a.c, fr))
        IMPACTS.append(f + 6)
    g = f + 1  # the left arm trails the right by a frame, so the arms don't move as one
    a.add(lambda fr: None if not (f <= fr <= f + 31) else {
        "lean": curve(fr, [(f, 0, "linear"), (f + 3, -2 * away, "out"), (f + 8, 9 * away * big, "back"), (f + 20, 7 * away * big, "linear"), (f + 31, 0, "smooth")]),
        "sq": curve(fr, [(f, 1, "linear"), (f + 3, 1 - 0.13 * big, "out"), (f + 7, 1 + 0.16 * big, "out"),
                         (f + 12, 1, "in"), (f + 14, 1 - 0.07 * big, "out"), (f + 30, 1, "elastic")]),
        "y": curve(fr, [(f, 0, "linear"), (f + 3, -0.06, "out"), (f + 8, 0.9 * big, "out"), (f + 13, 0, "in")]),
        "arm1": curve(fr, [(f, 10, "linear"), (f + 3, 0, "out"), (f + 7, 62, "back"), (f + 20, 62, "linear"), (f + 30, 10, "smooth")]),
        "arm-1": curve(fr, [(g, 10, "linear"), (g + 3, 0, "out"), (g + 7, 62, "back"), (g + 20, 62, "linear"), (g + 30, 10, "smooth")]),
        "elbow1": curve(fr, [(f, 8, "linear"), (f + 7, 55, "back"), (f + 20, 55, "linear"), (f + 30, 8, "smooth")]),
        "elbow-1": curve(fr, [(g, 8, "linear"), (g + 7, 55, "back"), (g + 20, 55, "linear"), (g + 30, 8, "smooth")]),
        "hand1": "open" if f + 5 <= fr <= f + 24 else "paw", "hand-1": "open" if g + 5 <= fr <= g + 24 else "paw",
        "head_rot": curve(fr, [(f, 0, "linear"), (f + 7, -4, "out"), (f + 18, 0, "elastic")]),
        "brow": curve(fr, [(f, 0, "linear"), (f + 7, 0.12 * big, "back"), (f + 24, 0, "smooth")]),  # brows pop past the face
    })


def double_take(a, f, toward=1.0):
    """Glance at something, look away, freeze... then snap back with a take."""
    a.look(f, 0.6 * toward, 4)
    a.look(f + 10, 0.0, 5)
    a.look(f + 26, toward, 3)
    take(a, f + 26, "shocked", 0.9)


def laugh(a, f0, f1, beat=None):
    """Belly laugh: bouncing body, head tipping back and forth, paws on the belly, ^ ^ eyes.
    Each character laughs at their own speed (`beat`, frames per bounce: 4 = giggly, 7 = slow guffaw)."""
    a.expr(f0, "laughing")
    style = a.c.name if a.c.name in ("bash", "pip", "rocco") else "riot"
    beat = beat or {"pip": 3.5, "rocco": 7.0}.get(style, 4 + (a.seed % 7) * 0.5)
    amp = (0.85 + (a.seed % 5) * 0.08) * ACT * {"pip": 0.6, "rocco": 0.5}.get(style, 1.0)
    rock, lean = 12 + a.seed % 9, -1 if a.seed % 3 == 0 else 1
    def L(fr):
        k = envelope(fr, f0, f1, 5)
        if not k:
            return None
        t = fr - f0
        b = abs(math.sin(math.pi * t / beat))
        pop = math.sin(math.pi * t / 10) if t < 10 else 0.0  # the laugh bursts out: head thrown up and back
        d = {"sq": 1 + amp * k * (0.08 * b + 0.06 * pop), "y": amp * k * (0.24 * b + 0.22 * pop),
             "head_rot": lean * k * amp * (9 + 6 * math.sin(2 * math.pi * t / rock)), "head_y": 0.1 * k * amp,
             "lean": -lean * k * amp * (3 + 3.5 * math.sin(2 * math.pi * t / (rock * 1.4))),  # rocking in the seat
             "x": 0.025 * k * amp * math.sin(t * 2.1)}                                      # shoulders shaking
        if style == "bash":    # doubles over and pounds a fist on the beat
            pound = abs(math.sin(math.pi * t / (beat * 2)))
            d.update({"lean": 7 * k * ACT, "head_y": -0.05 * k, "arm1": 26 + 18 * pound * k, "elbow1": 95 * k + 8 * (1 - k),
                      "hand1": "fist" if k > 0.4 else "paw", "arm-1": 10 - 22 * k, "elbow-1": 8 - 70 * k})
        elif style == "pip":   # giggles behind a paw, shoulders up
            d.update({"face1": k, "face_y": -1.15 * k, "hand1": "open" if k > 0.5 else "paw", "sq": d["sq"] - 0.03 * k,
                      "arm-1": 10 - 22 * k, "elbow-1": 8 - 70 * k})
        else:                  # Riot's belly laugh / Rocco's slow chuckle: paws on the belly
            d.update({"arm1": 10 - 22 * k, "arm-1": 10 - 22 * k, "elbow1": 8 - 78 * k, "elbow-1": 8 - 70 * k})
        return d
    a.add(L)


def nervous(a, f0, f1, sweat=True):
    """Shrinks a little, shivers, eyes dart left and right."""
    a.expr(f0, "nervous")
    def L(fr):
        k = envelope(fr, f0, f1, 6)
        if not k:
            return None
        t = fr - f0
        return {"x": 0.07 * k * ACT * math.sin(t * 2.7), "sq": 1 - 0.06 * k * ACT, "head_rot": 3 * k * ACT * math.sin(t * 1.9),
                "lean": 1.5 * k * ACT * math.sin(t * 2.3), "head_y": -0.08 * k * ACT,             # shrinking into the hoodie
                "arm1": 10 - 22 * k, "arm-1": 10 - 22 * k, "elbow1": 8 - 95 * k, "elbow-1": 8 - 88 * k,  # wringing paws
                "hand1": "fist" if k > 0.5 else "paw", "hand-1": "fist" if k > 0.5 else "paw"}
    a.add(L)
    for i, fr in enumerate(range(f0 + 8, f1 - 6, 16)):
        a.look(fr, (-0.35, 0.35)[i % 2], 3)
    a.look(f1 - 6, 0.0, 5)
    if sweat and "sweat" in a.c.extras:
        a.at(f0, lambda fr: set_visible(a.c.extras["sweat"], False, 0) or set_visible(a.c.extras["sweat"], True, fr))


def yell(a, f0, f1, side=1):
    """Puff up, lean in, shake the head and jab a finger (at whoever is on `side`)."""
    a.expr(f0 + 3, "yelling")
    def L(fr):
        k = envelope(fr, f0, f1, 4)
        if not k:
            return None
        t = fr - f0
        return {"sq": 1 + 0.09 * k * ACT, "y": 0.14 * k * ACT, "head_rot": k * 7 * ACT * math.sin(t * 1.4),
                "head_x": 0.14 * side * k * ACT, "lean": 7 * side * k * ACT,                     # leaning into it
                f"arm{side}": 10 + 78 * EASE["back"](clamp01(t / 5)) * (k > 0.5) + 4 * math.sin(t * 1.9) * k,
                f"elbow{side}": 8 - 4 * (k > 0.5), f"hand{side}": "point" if k > 0.5 else "paw",
                f"hand{-side}": "fist" if k > 0.5 else "paw"}
    a.add(L)


def wave(a, f0, f1, side=1):
    """Friendly wave: arm swings up with overshoot, the forearm waves from the elbow at ~2.5Hz, head tilts."""
    a.expr(f0, "happy")
    def L(fr):
        k = envelope(fr, f0, f1, 6)
        if not k:
            return None
        t = fr - f0
        return {f"arm{side}": 10 + 62 * k, f"elbow{side}": 8 + k * (72 + 26 * math.sin(2 * math.pi * t / 12)),
                f"hand{side}": "open" if k > 0.3 else "paw", "head_rot": -5 * side * k}
    a.add(L)


def cheer(a, f, hold=24):
    """Crouch (anticipation) -> jump with arms up (stretch) -> hang -> land (squash) -> settle; arms stay up."""
    a.expr(f + 4, "hype")
    a.add(lambda fr: None if not (f <= fr <= f + 40 + hold) else {
        "sq": curve(fr, [(f, 1, "linear"), (f + 5, 0.86, "out"), (f + 9, 1.16, "out"), (f + 15, 1.0, "smooth"),
                         (f + 21, 1.0, "linear"), (f + 23, 0.88, "out"), (f + 36, 1.0, "elastic")]),
        "y": curve(fr, [(f, 0, "linear"), (f + 5, -0.12, "out"), (f + 13, 1.7, "out"), (f + 16, 1.7, "linear"), (f + 22, 0, "in")]),
        "arm1": curve(fr, [(f, 10, "linear"), (f + 5, 25, "out"), (f + 10, 132, "back"), (f + 36 + hold, 132, "linear"), (f + 44 + hold, 10, "smooth")]),
        "arm-1": curve(fr, [(f, 10, "linear"), (f + 5, 25, "out"), (f + 11, 132, "back"), (f + 36 + hold, 132, "linear"), (f + 44 + hold, 10, "smooth")]),
        "elbow1": curve(fr, [(f, 8, "linear"), (f + 5, 40, "out"), (f + 10, 22, "back"), (f + 44 + hold, 8, "smooth")]),
        "elbow-1": curve(fr, [(f, 8, "linear"), (f + 5, 40, "out"), (f + 11, 22, "back"), (f + 44 + hold, 8, "smooth")]),
        "hand1": "fist" if f + 8 <= fr <= f + 40 + hold else "paw", "hand-1": "fist" if f + 8 <= fr <= f + 40 + hold else "paw",
    })


def point_at(a, f, side=1, hold=30, expr="yelling"):
    """Wind up (arm dips, body leans away) -> snap point with overshoot -> hold -> relax."""
    a.expr(f + 4, expr)
    a.add(lambda fr: None if not (f <= fr <= f + hold + 12) else {
        f"arm{side}": curve(fr, [(f, 10, "linear"), (f + 4, -6, "out"), (f + 8, 88, "back"), (f + hold, 88, "linear"), (f + hold + 10, 10, "smooth")]),
        f"elbow{side}": curve(fr, [(f, 8, "linear"), (f + 4, 45, "out"), (f + 8, 4, "back"), (f + hold, 4, "linear"), (f + hold + 10, 8, "smooth")]),
        "x": curve(fr, [(f, 0, "linear"), (f + 4, -0.1 * side, "out"), (f + 8, 0.08 * side, "back"), (f + hold + 10, 0, "smooth")]),
        "lean": ACT * curve(fr, [(f, 0, "linear"), (f + 4, -4 * side, "out"), (f + 8, 8 * side, "back"), (f + hold, 6 * side, "linear"), (f + hold + 10, 0, "smooth")]),
        "head_rot": curve(fr, [(f, 0, "linear"), (f + 8, -5 * side, "back"), (f + hold + 10, 0, "smooth")]),
        f"hand{side}": "point" if f + 6 <= fr <= f + hold + 4 else "paw",
    })


def whistle(a, f, side=1, dur=14, point=True):
    """Referee call (coach Riot): puff up, head back, puckered 'vF' mouth on the whistle, and either point at
    the offender on `side` or (point=False) throw up the right paw, palm out: 'stop!' (keeps faces next to him clear)."""
    if point:
        point_at(a, f, side, hold=dur + 6, expr="suspicious")
    else:
        a.expr(f + 4, "suspicious")
        a.add(lambda fr: None if not (f <= fr <= f + dur + 16) else {
            "arm1": curve(fr, [(f, 10, "linear"), (f + 3, 4, "out"), (f + 8, 34, "back"), (f + dur + 6, 34, "linear"), (f + dur + 15, 10, "smooth")]),
            "elbow1": curve(fr, [(f, 8, "linear"), (f + 8, 128, "back"), (f + dur + 6, 128, "linear"), (f + dur + 15, 8, "smooth")]),
            "hand1": "open" if f + 5 <= fr <= f + dur + 10 else "paw",
        })
    a.add(lambda fr: None if not (f <= fr <= f + dur + 8) else {
        "sq": curve(fr, [(f, 1, "linear"), (f + 3, 0.95, "out"), (f + 7, 1.05, "back"), (f + dur, 1.05, "linear"), (f + dur + 8, 1, "smooth")]),
        "head_rot": curve(fr, [(f, 0, "linear"), (f + 6, 5 * side, "back"), (f + dur, 5 * side, "linear"), (f + dur + 8, 0, "smooth")]),
        "brow": curve(fr, [(f, 0, "linear"), (f + 5, -0.06, "out"), (f + dur + 6, 0, "smooth")]),
    })
    def blow(fr):
        for i in range(dur):
            mouth_at(a.c, "vF", fr + 3 + i)
        mouth_at(a.c, cast.EXPRESSIONS[a.expr_at(fr + 3 + dur)][0], fr + 3 + dur)
    a.at(f, blow, prio=3)


def facepalm(a, f, hold=30):
    """Paw comes up to the face, head sinks, a beat of shame, then recover."""
    a.expr(f + 5, "suspicious")
    a.add(lambda fr: None if not (f <= fr <= f + hold + 12) else {
        "face1": curve(fr, [(f, 0, "linear"), (f + 6, 1, "out"), (f + hold, 1, "linear"), (f + hold + 8, 0, "smooth")]),
        "head_rot": curve(fr, [(f, 0, "linear"), (f + 8, -7, "out"), (f + hold, -7, "linear"), (f + hold + 8, 0, "smooth")]),
        "head_y": curve(fr, [(f, 0, "linear"), (f + 8, -0.25, "out"), (f + hold, -0.25, "linear"), (f + hold + 8, 0, "smooth")]),
        "sq": curve(fr, [(f, 1, "linear"), (f + 8, 0.95, "out"), (f + hold + 8, 1, "smooth")]),
        "lean": ACT * curve(fr, [(f, 0, "linear"), (f + 9, 6, "out"), (f + hold, 7, "linear"), (f + hold + 8, 0, "smooth")]),  # slumps into the paw
    })


def shrug(a, f, hold=22):
    """Arms flick out with overshoot, shoulders up, head tilt, smirk."""
    a.expr(f + 2, "side_eye_r")
    a.add(lambda fr: None if not (f <= fr <= f + hold + 12) else {
        "arm1": curve(fr, [(f, 10, "linear"), (f + 6, 24, "back"), (f + hold, 24, "linear"), (f + hold + 9, 10, "smooth")]),
        "arm-1": curve(fr, [(f, 10, "linear"), (f + 8, 24, "back"), (f + hold + 2, 24, "linear"), (f + hold + 11, 10, "smooth")]),
        "elbow1": curve(fr, [(f, 8, "linear"), (f + 6, 84, "back"), (f + hold, 84, "linear"), (f + hold + 9, 8, "smooth")]),
        "elbow-1": curve(fr, [(f, 8, "linear"), (f + 8, 84, "back"), (f + hold + 2, 84, "linear"), (f + hold + 11, 8, "smooth")]),
        "hand1": "open" if f + 3 <= fr <= f + hold + 5 else "paw", "hand-1": "open" if f + 3 <= fr <= f + hold + 5 else "paw",
        "y": curve(fr, [(f, 0, "linear"), (f + 6, 0.1, "out"), (f + hold, 0.1, "linear"), (f + hold + 9, 0, "smooth")]),
        "head_rot": curve(fr, [(f, 0, "linear"), (f + 7, 9, "back"), (f + hold, 9, "linear"), (f + hold + 9, 0, "smooth")]),
        "lean": ACT * curve(fr, [(f, 0, "linear"), (f + 7, -4, "back"), (f + hold, -4, "linear"), (f + hold + 9, 0, "smooth")]),
    })


def thumbs_up(a, f, hold=26, side=1):
    """Forearm swings up, thumb pops out with overshoot, little nod + wink-ish cocky face."""
    a.expr(f + 4, "cocky")
    te = a.c.extras.get("thumbs_elbow", 150)
    a.add(lambda fr: None if not (f <= fr <= f + hold + 12) else {
        f"arm{side}": curve(fr, [(f, 10, "linear"), (f + 6, 18, "back"), (f + hold, 18, "linear"), (f + hold + 9, 10, "smooth")]),
        f"elbow{side}": curve(fr, [(f, 8, "linear"), (f + 7, te, "back"), (f + hold, te, "linear"), (f + hold + 9, 8, "smooth")]),
        f"hand{side}": "thumbs" if f + 5 <= fr <= f + hold + 4 else "paw",
        "head_rot": curve(fr, [(f, 0, "linear"), (f + 8, -6 * side, "back"), (f + 14, -3 * side, "smooth"), (f + hold + 9, 0, "smooth")]),
        "y": curve(fr, [(f, 0, "linear"), (f + 8, 0.08, "out"), (f + 13, 0, "smooth")]),
    })


WALK = 45        # frames to walk on or off a set (episode "enter" / "exit")
STEP = 11        # frames per step
# walk styles live in roster.PROFILES ("walk": stride deg, bob, step frames, arm swing deg, sway deg)


def walk(a, f, f_end, x_from, x_to, hold_until=None):
    """Walk across the set: from x_from to x_to (character units, offsets from the character's spot) between
    f and f_end. The legs swing in a stride, the body bobs once per step, the head leads toward where he's going."""
    d = 1 if x_to > x_from else -1
    n = max(1, f_end - f)
    import roster
    stride_, bob_, step_, arm_, sway_ = roster.profile(a.c.name)["walk"]

    def layer(fr):
        if hold_until and f_end + 6 < fr <= hold_until:  # stays where the walk ended
            return {"x": x_to}
        if not (f - 8 <= fr <= f_end + 6):
            return None
        if fr < f:  # anticipation: a little dip and a lean back before setting off
            k_ = math.sin(math.pi * (fr - f + 8) / 8)
            return {"x": x_from - 0.06 * d * k_, "sq": 1 - 0.05 * k_, "lean": -4 * d * k_, "turn": 0.3 * d * k_}
        u = max(0.0, min(1.0, (fr - f) / n))
        e = u * u * (3 - 2 * u) * 0.35 + u * 0.65  # mostly steady pace, soft start and stop
        k = math.sin(math.pi * min(1.0, (fr - f) / 4.0)) if fr - f < 4 else (1.0 if fr <= f_end - 4 else max(0.0, (f_end + 2 - fr) / 6.0))
        ph = (fr - f) / step_ * math.pi
        sw = arm_ * math.sin(ph) * k  # arms swing against the legs
        return {"x": x_from + (x_to - x_from) * e, "stride": stride_ * math.sin(ph) * k,
                "y": bob_ * abs(math.sin(ph)) * k, "turn": 0.45 * d * k, "lean": 3 * d * k + sway_ * math.sin(ph) * k,
                "arm1": 10 + sw, "arm-1": 10 - sw, "elbow1": 8 + 0.4 * abs(sw), "elbow-1": 8 + 0.4 * abs(sw)}
    a.add(layer)


def fan(a, f, f_end, side=1):
    """Fanning the face in the heat: open paw up beside the face, flapping quickly, head tipped back a touch."""
    a.add(lambda fr: None if not (f <= fr <= f_end + 10) else {
        f"arm{side}": curve(fr, [(f, 10, "linear"), (f + 6, 34, "back"), (f_end, 34, "linear"), (f_end + 9, 10, "smooth")]),
        f"elbow{side}": curve(fr, [(f, 8, "linear"), (f + 6, 120, "back"), (f_end, 120, "linear"), (f_end + 9, 8, "smooth")])
                        + (14 * math.sin((fr - f) * 1.3) if f + 6 <= fr <= f_end else 0),
        f"hand{side}": "open" if f + 3 <= fr <= f_end + 4 else "paw",
        "head_rot": curve(fr, [(f, 0, "linear"), (f + 8, 4 * side, "smooth"), (f_end, 4 * side, "linear"), (f_end + 9, 0, "smooth")]),
    })


def sleep(a, f, f_end):
    """Fast asleep: head tipped to one side and dropped, big slow breaths, the body sags a little."""
    a.add(lambda fr: None if not (f <= fr <= f_end) else {
        "head_rot": 14 * min(1.0, (fr - f) / 8.0), "head_y": -0.12 * min(1.0, (fr - f) / 8.0),
        "sq": 1 + 0.025 * math.sin((fr - f) * 2 * math.pi / 70), "y": -0.06 * min(1.0, (fr - f) / 8.0)})


def shiver(a, f, f_end):
    """A cold / spooked shiver: small fast side-to-side shake, arms hugged in, shoulders up."""
    a.add(lambda fr: None if not (f <= fr <= f_end + 6) else {
        "x": 0.035 * math.sin((fr - f) * 2.6) * (1 if fr <= f_end else (f_end + 6 - fr) / 6),
        "head_y": -0.06 * min(1.0, (fr - f) / 4.0) * (1 if fr <= f_end else (f_end + 6 - fr) / 6),
        "arm1": curve(fr, [(f, 10, "linear"), (f + 5, -12, "out"), (f_end, -12, "linear"), (f_end + 6, 10, "smooth")]),
        "arm-1": curve(fr, [(f, 10, "linear"), (f + 5, -12, "out"), (f_end, -12, "linear"), (f_end + 6, 10, "smooth")]),
        "elbow1": curve(fr, [(f, 8, "linear"), (f + 5, -95, "out"), (f_end, -95, "linear"), (f_end + 6, 8, "smooth")]),
        "elbow-1": curve(fr, [(f, 8, "linear"), (f + 5, -95, "out"), (f_end, -95, "linear"), (f_end + 6, 8, "smooth")]),
    })


def present(a, f, hold=30, side=1):
    """'Ta-da': open palm sweeps out toward a card or prompt, body leans with it."""
    a.expr(f + 3, "hype")
    a.add(lambda fr: None if not (f <= fr <= f + hold + 12) else {
        f"arm{side}": curve(fr, [(f, 10, "linear"), (f + 3, 0, "out"), (f + 9, 44, "back"), (f + hold, 44, "linear"), (f + hold + 9, 10, "smooth")]),
        f"elbow{side}": curve(fr, [(f, 8, "linear"), (f + 9, 36, "back"), (f + hold + 9, 8, "smooth")]),
        f"hand{side}": "open" if f + 4 <= fr <= f + hold + 5 else "paw",
        "x": curve(fr, [(f, 0, "linear"), (f + 9, 0.08 * side, "back"), (f + hold + 9, 0, "smooth")]),
        "lean": ACT * curve(fr, [(f, 0, "linear"), (f + 9, 5 * side, "back"), (f + hold + 9, 0, "smooth")]),
        "head_rot": curve(fr, [(f, 0, "linear"), (f + 9, -5 * side, "back"), (f + hold + 9, 0, "smooth")]),
    })


def hop(a, f, height=0.6):
    """Small happy hop with squash on take-off and landing."""
    a.add(lambda fr: None if not (f <= fr <= f + 22) else {
        "sq": curve(fr, [(f, 1, "linear"), (f + 3, 0.9, "out"), (f + 6, 1.1, "out"), (f + 11, 1, "smooth"), (f + 13, 0.92, "out"), (f + 22, 1, "elastic")]),
        "y": curve(fr, [(f, 0, "linear"), (f + 3, -0.05, "out"), (f + 8, height, "out"), (f + 13, 0, "in")]),
    })


def clap(a, f0, f1, rate=7):
    """Excited clapping: both paws come together in front of the chest every `rate` frames, with a bounce."""
    a.expr(f0, "hype")
    def L(fr):
        k = envelope(fr, f0, f1, 5)
        if not k:
            return None
        t = fr - f0
        open_ = abs(math.sin(math.pi * t / rate))
        d = {"y": 0.08 * k * ACT * open_, "sq": 1 + 0.03 * k * (1 - open_), "head_rot": 3 * k * math.sin(t * 0.4)}
        for s in (1, -1):
            d[f"reach{s}"] = (s * (0.12 + 0.6 * open_), 4.9, k, "open")
        return d
    a.add(L)


def count(a, f, n=3, step=12, side=1):
    """Counting on fingers: the forearm comes up and holds 1, 2, 3 (point, peace, three), with a little nod each."""
    signs = ("point", "peace", "three")[:max(1, min(3, n))]
    end = f + 6 + step * len(signs)
    a.add(lambda fr: None if not (f <= fr <= end + 10) else {
        f"arm{side}": curve(fr, [(f, 10, "linear"), (f + 6, 24, "back"), (end, 24, "linear"), (end + 9, 10, "smooth")]),
        f"elbow{side}": curve(fr, [(f, 8, "linear"), (f + 6, 132, "back"), (end, 132, "linear"), (end + 9, 8, "smooth")]),
        f"hand{side}": signs[min(len(signs) - 1, max(0, (fr - f - 6) // step))] if f + 4 <= fr <= end + 4 else "paw",
        "head_y": -0.06 * ACT * math.sin(math.pi * clamp01(((fr - f - 6) % step) / 6)) if fr >= f + 6 else 0.0,
    })


def sign(a, f, hand="peace", hold=30, side=1, expr="cocky"):
    """Hold up a finger sign ("peace", "horns", "thumbs", "three") beside the head with a head tilt."""
    a.expr(f + 4, expr)
    a.add(lambda fr: None if not (f <= fr <= f + hold + 12) else {
        f"arm{side}": curve(fr, [(f, 10, "linear"), (f + 3, 4, "out"), (f + 8, 28, "back"), (f + hold, 28, "linear"), (f + hold + 10, 10, "smooth")]),
        f"elbow{side}": curve(fr, [(f, 8, "linear"), (f + 8, 140, "back"), (f + hold, 140, "linear"), (f + hold + 10, 8, "smooth")]),
        f"hand{side}": hand if f + 5 <= fr <= f + hold + 5 else "paw",
        "head_rot": curve(fr, [(f, 0, "linear"), (f + 8, -7 * side, "back"), (f + hold, -7 * side, "linear"), (f + hold + 10, 0, "smooth")]),
        "lean": ACT * curve(fr, [(f, 0, "linear"), (f + 8, 3 * side, "back"), (f + hold + 10, 0, "smooth")]),
    })


def rock_on(a, f, hold=36, side=1):
    """Rock horns raised high and a head-bang on the beat."""
    a.expr(f + 3, "hype")
    a.add(lambda fr: None if not (f <= fr <= f + hold + 12) else {
        f"arm{side}": curve(fr, [(f, 10, "linear"), (f + 4, 0, "out"), (f + 9, 140, "back"), (f + hold, 140, "linear"), (f + hold + 10, 10, "smooth")]),
        f"elbow{side}": curve(fr, [(f, 8, "linear"), (f + 9, 20, "back"), (f + hold + 10, 8, "smooth")]),
        f"hand{side}": "horns" if f + 6 <= fr <= f + hold + 4 else "paw",
        "head_y": -0.12 * ACT * abs(math.sin(math.pi * (fr - f) / 8)) * (f + 9 <= fr <= f + hold),
        "head_rot": 4 * ACT * math.sin(math.pi * (fr - f) / 8) * (f + 9 <= fr <= f + hold),
    })


def gloom(a, f0, f1):
    """Defeat: a little rain cloud over the head, a slump, ears and tail droop (with the pouting face)."""
    a.expr(f0, "pouting")
    a.glooms = getattr(a, "glooms", []) + [(f0, f1)]
    a.add(lambda fr: None if not (f0 <= fr <= f1 + 8) else {
        "sq": 1 - 0.06 * ACT * envelope(fr, f0, f1 + 8, 8), "head_y": -0.22 * ACT * envelope(fr, f0, f1 + 8, 8),
        "lean": -3 * ACT * envelope(fr, f0, f1 + 8, 8), "head_rot": 4 * envelope(fr, f0, f1 + 8, 8),
    })


def read_wav_rms(path):
    with wavfile.open(path) as w:
        sr = w.getframerate()
        x = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(float).reshape(-1, w.getnchannels()).mean(axis=1)
    hop_ = sr // FPS
    rms = np.array([np.sqrt(np.mean(x[i:i + hop_] ** 2)) for i in range(0, len(x) - hop_, hop_)])
    return rms / (rms.max() + 1e-9)


MOUTHS = {  # (open, half-open, closed) for lip sync; Riot's closed mouth is his smirk
    "riot": ("laugh", "grin", "smirk"), "bash": ("yell", "shock", "grit"),
    "pip": ("yell", "shock", "wobble"), "rocco": ("yell", "shock", "smile"),
}


RHUBARB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../tools/Rhubarb-Lip-Sync-1.14.0-macOS/rhubarb")


def rhubarb_cues(wav_path, text=None):
    """Mouth-shape cues [(start_s, 'A'..'H'/'X')] from Rhubarb Lip Sync, cached next to the wav. None if unavailable."""
    cache = wav_path + ".rhubarb.json"
    if not os.path.exists(cache) or os.path.getmtime(cache) < os.path.getmtime(wav_path):
        if not os.path.exists(RHUBARB):
            return None
        cmd = [RHUBARB, "-q", "-f", "json", "--extendedShapes", "GHX", "-o", cache]
        if text:
            tf = wav_path + ".txt"
            open(tf, "w").write(text)
            cmd += ["-d", tf]
        try:
            subprocess.run(cmd + [wav_path], check=True, capture_output=True)
        except (OSError, subprocess.CalledProcessError):
            return None
    return [(c["start"], c["value"]) for c in json.load(open(cache))["mouthCues"]]


def _syllables(word):
    w = "".join(ch for ch in word.lower() if ch.isalpha())
    groups, prev = 0, False
    for ch in w:
        v = ch in "aeiouy"
        groups += v and not prev
        prev = v
    return max(1, groups - (w.endswith("e") and groups > 1))


def word_times(text, wav_path):
    """Estimate (word, t0, t1) in seconds for captions: spread the words over the voiced span Rhubarb found,
    weighted by syllables, with a pause after punctuation."""
    cues = rhubarb_cues(wav_path, text)
    rms = read_wav_rms(wav_path)
    dur = len(rms) / FPS
    if cues:
        t_start = next((t for t, v in cues if v != "X"), 0.0)
        t_end = next((t for t, v in reversed(cues) if v == "X" and t > t_start), dur)
    else:
        on = [i for i, v in enumerate(rms) if v > 0.12]
        t_start, t_end = (on[0] / FPS, (on[-1] + 1) / FPS) if on else (0.0, dur)
    words = text.split()
    wts = [_syllables(w) + (0.9 if w[-1] in ",.!?" else 0.0) for w in words]
    unit = (t_end - t_start) / sum(wts)
    out, t = [], t_start
    for w, wt in zip(words, wts):
        speak = _syllables(w) * unit
        out.append((w, t, t + speak))
        t += wt * unit
    return out


def accents(rms, gap=5, window=24):
    """Syllable onsets [(frame, strength 0..1)]: where the smoothed loudness rises fastest. Strength is
    relative to the loudest onset within +-`window` frames, so a line that trails off still gets stresses."""
    sm = np.convolve(rms, np.ones(4) / 4, mode="same")
    d = np.diff(sm, prepend=sm[0])
    out, last = [], -99
    for i in range(1, len(d) - 1):
        if d[i] > 0.04 and d[i] >= d[i - 1] and d[i] >= d[i + 1] and i - last >= gap:
            out.append((i, float(sm[i:i + 4].max())))
            last = i
    return [(i, k / max(k2 for i2, k2 in out if abs(i2 - i) <= window)) for i, k in out]


def phrase_ends(wav_path, gap=4, thr=0.12):
    """Frames (from the wav start) where a phrase ends: voiced, then quiet for at least `gap` frames."""
    on = read_wav_rms(wav_path) > thr
    return [i for i in range(1, len(on)) if on[i - 1] and not on[i:i + gap].any()]


def _pulse(t, peak=3):
    """0 -> 1 at `peak` frames -> eases back to 0 (a nod, a brow flash)."""
    return (t / peak) * math.exp(1 - t / peak) if t >= 0 else 0.0


def talk(a, start, wav_path, mouths=None, energy=1.0, text=None, gestures=True):
    """Lip sync with Rhubarb mouth shapes (falls back to loudness), held at least 2 frames each, plus a nod
    and a brow flash on each stressed syllable. Angry / suspicious faces push the brows down instead.
    Acting is pose-to-pose: the head snaps to a new tilt on each stressed syllable and holds it (the torso tilts
    the other way), and a free paw gestures on the strongest beats, in the character's own GESTURE_STYLE.
    Pass the spoken `text` for more accurate shapes. Restores the expression's mouth afterwards."""
    rms = read_wav_rms(wav_path)
    cues = rhubarb_cues(wav_path, text)
    o, m, cl = mouths or MOUTHS.get(a.c.name, ("yell", "shock", "smile"))
    def events(fr0):
        rest = cast.EXPRESSIONS[a.expr_at(fr0)][0]
        prev, held = None, 0
        for i, v in enumerate(rms):
            if cues:
                t = i / FPS
                shape_ = max((cv for cv in cues if cv[0] <= t + 1e-6), key=lambda cv: cv[0])[1]
                key = rest if shape_ == "X" else "v" + shape_
            else:
                key = o if v > 0.5 else m if v > 0.18 else cl
            if prev is not None and key != prev and held < 2:  # mouths on 2s: no 1-frame flicker
                key = prev
            held = held + 1 if key == prev else 1
            prev = key
            mouth_at(a.c, key, fr0 + i)
        mouth_at(a.c, cast.EXPRESSIONS[a.expr_at(fr0 + len(rms))][0], fr0 + len(rms))
    a.at(start, events, prio=2)
    sm = np.convolve(rms, np.ones(4) / 4, mode="same")
    acc = accents(rms)
    n = len(sm)
    rnd = random.Random(a.seed + start)
    # key poses: a new head tilt on every accent, snapped in 3 frames with overshoot, then held still
    tilt, prev = [(0, 0.0, "linear")], 0.0
    for j, (p, k) in enumerate(acc):
        t = (1 if (j + a.seed) % 2 else -1) * energy * ACT * (2.5 + 4.5 * k) * rnd.uniform(0.75, 1.15)
        tilt += [(max(p - 1, tilt[-1][0] + 1), prev, "linear"), (max(p + 3, tilt[-1][0] + 2), t, "back")]
        prev = t
    tilt += [(max(n, tilt[-1][0] + 1), prev, "linear"), (max(n, tilt[-1][0] + 1) + 10, 0.0, "smooth")]
    # gestures: the strongest beats, spaced out by the character's habit; a question ends on open palms
    rate, size = GESTURE_STYLE.get(a.c.name) or __import__("roster").profile(a.c.name)["gesture"]
    gs, last = [], -999
    if gestures and energy > 0.5:
        for p, k in acc:
            if k > 0.55 and p - last >= 22 / rate and p > 3 and p < n - 6:
                gs.append(p)
                last = p
    side0 = 1 if a.seed % 2 else -1
    ask = bool(text) and text.rstrip().endswith("?")
    def gesture_at(i):
        for j, p in enumerate(gs):
            end = min(gs[j + 1] - 10 if j + 1 < len(gs) else n + 4, p + 26)  # back down before the next one
            if p - 3 <= i <= end + 7:
                w = curve(i, [(p - 3, 0, "linear"), (p + 2, 1, "back"), (end, 1, "linear"), (end + 7, 0, "smooth")])
                last_one = j == len(gs) - 1
                sh, el, hd = (24, 82, "open") if ask and last_one else GESTURES[(j + a.seed) % len(GESTURES)]
                sh = cast.REST[0] + (sh - cast.REST[0]) * size * ACT
                return (side0 if j % 2 == 0 else -side0, sh, el * min(1.0, 0.6 + 0.4 * size), hd, w, ask and last_one)
        return None
    def L(fr):
        i = fr - start
        if -8 <= i < 0:  # a breath in before the line: chest and head rise, brows lift
            u = math.sin(math.pi * (i + 8) / 8) * ACT
            return {"sq": 1 + 0.025 * u, "head_y": 0.05 * u, "brow": 0.04 * u}
        if not (0 <= i < n + 12):
            return None
        v = sm[i] if i < n else 0.0
        frown = cast.EXPRESSIONS[a.expr_at(fr)][1] < -15
        ht = curve(i, tilt)
        d = {"head_rot": ht, "lean": -0.35 * ht, "head_y": energy * 0.05 * v,
             "sq": 1 + 0.015 * energy * v, "brow": 0.0, "brow_rot": 0.0,
             "mouth": 1 + 0.28 * min(1.5, energy) * ACT * max(0.0, v - 0.35),  # only the loud syllables stretch
             "jaw": 0.09 * min(1.5, energy) * v, "head_sq": 1.0}
        g = gesture_at(i)
        if g:
            d["gesture"] = g
        for p, k in acc:
            if 0 <= i - p < 14:
                u = energy * k * _pulse(i - p) * ACT
                d["head_y"] -= 0.1 * u                        # nod down into the beat
                d["head_sq"] *= 1 + 0.07 * u * (1 if i - p < 4 else -0.5)  # the head stretches on the hit, squashes after
                if k > 0.55:                                  # stressed: brows flash
                    d["brow"] += (-0.07 if frown else 0.13) * u
                    d["brow_rot"] += (-4 if frown else 3) * u
        return d
    a.add(L)
    return len(rms)


def listen(a, f0, f1, toward=0.0, beats=(), nod=1.0):
    """Active listening: lean a touch toward the speaker (`toward` -1..1) and nod with a brow lift just after
    each of the speaker's phrase ends (`beats`, absolute frames; see phrase_ends). Without beats it nods
    about once a second. Nods are staggered per character so a group never nods in unison."""
    rnd = random.Random(a.seed + f0)
    beats = [b for b in beats if f0 <= b <= f1 - 4]
    if not beats:
        beats = list(range(f0 + rnd.randint(10, 22), f1 - 8, 30 + rnd.randint(0, 10)))
    lag = 2 + a.seed % 4
    def L(fr):
        k = envelope(fr, f0, f1, 8)
        if not k:
            return None
        d = {"x": 0.04 * toward * k * ACT, "lean": 4.0 * toward * k * ACT, "head_x": 0.06 * toward * k * ACT,
             "head_y": 0.0, "head_rot": 0.0, "brow": 0.0}
        for b in beats:
            t = fr - b - lag
            if 0 <= t < 12:
                n = nod * math.sin(math.pi * t / 12) * ACT
                d["head_y"] -= 0.12 * n
                d["head_rot"] -= 4.0 * toward * n
                d["brow"] += 0.09 * n
        return d
    a.add(L)


# ---------- props & camera ----------

def _key_scale(o, f, s):
    o.scale = (max(s, 0.0001), max(s, 0.0001), 1)
    o.keyframe_insert("scale", frame=f)


def show(o, a, b=None):
    """Visible on frames [a, b)."""
    if a > 0:
        set_visible(o, False, 0)
    set_visible(o, True, a)
    if b is not None:
        set_visible(o, False, b)


def pop_in(o, f, dur=7, over=1.18, wiggle=6):
    """Scale 0 -> overshoot -> 1 with a little rotational wiggle (cards, bubbles, emotes)."""
    r0 = o.rotation_euler.z
    for fr in range(f, f + dur + 6):
        t = (fr - f) / dur
        _key_scale(o, fr, curve(t, [(0, 0, "linear"), (0.6, over, "out"), (1, 1, "smooth")]))
        o.rotation_euler.z = r0 + rad(wiggle) * math.exp(-4 * t) * math.sin(t * 9)
        o.keyframe_insert("rotation_euler", frame=fr)
    show(o, f)


def pop_out(o, f, dur=5):
    for fr in range(f, f + dur + 1):
        t = (fr - f) / dur
        _key_scale(o, fr, curve(t, [(0, 1, "linear"), (0.35, 1.1, "out"), (1, 0, "in")]))
    set_visible(o, False, f + dur + 1)


def slam_in(o, f, start=2.6, dur=5):
    """Falls in from big (accelerating), hits, squashes and bounces (stamps, titles). Pair with a camera shake."""
    for fr in range(f, f + dur + 10):
        t = fr - f
        if t <= dur:
            s = start + (1 - start) * EASE["in"](t / dur)
        else:
            s = 1 - 0.09 * math.exp(-(t - dur) / 2.5) * math.cos((t - dur) * 1.2)
        _key_scale(o, fr, s)
    show(o, f)


def card_flip_in(o, f, dur=9):
    """Card spins in on its vertical axis (x-scale flip) with a tilt that settles: the prompt reveal."""
    r0 = o.rotation_euler.z
    for fr in range(f, f + dur + 8):
        t = (fr - f) / dur
        sx = abs(math.cos(math.pi * (1 - clamp01(t)) * 1.0)) if t < 1 else 1 - 0.05 * math.exp(-4 * (t - 1)) * math.cos((t - 1) * 12)
        sy = curve(t, [(0, 0.85, "linear"), (0.5, 1.08, "out"), (1, 1, "smooth")])
        o.scale = (max(sx, 0.0001), sy, 1)
        o.rotation_euler.z = r0 + rad(-10) * (1 - EASE["back"](clamp01(t)))
        o.keyframe_insert("scale", frame=fr)
        o.keyframe_insert("rotation_euler", frame=fr)
    show(o, f)


def float_up(o, f0, f1, dy=1.2, bob=0.08):
    """Drift upward with a gentle bob, then shrink away (emotes, sparkles)."""
    p0 = Vector(o.location)
    for fr in range(f0, f1 + 1):
        t = (fr - f0) / (f1 - f0)
        o.location = p0 + Vector((bob * math.sin(t * 9), dy * EASE["out"](t), 0))
        o.keyframe_insert("location", frame=fr)
    pop_out(o, f1 - 4, 4)


def burst(group, f, dur=26, power=1.0, gravity=0.018):
    """Confetti burst: every child flies out from the centre, spins, falls."""
    for i, ch in enumerate(group.children):
        p = Vector(ch.location)
        d = p.normalized() if p.length > 1e-6 else Vector((0, 1, 0))
        v = d * (0.32 + 0.12 * (i % 3)) * power + Vector((0, 0.18 * power, 0))
        spin = (i % 5 - 2) * 0.35
        for fr in range(f, f + dur + 1):
            t = fr - f
            ch.location = Vector((v.x * t, v.y * t - gravity * t * t, ch.location.z))
            ch.rotation_euler.z = spin * t
            ch.keyframe_insert("location", frame=fr)
            ch.keyframe_insert("rotation_euler", frame=fr)
    pop_in(group, f, 3, 1.0, 0)
    pop_out(group, f + dur - 4, 4)


def puff_out(o, f):
    """Smoke puff: pops big, then shrinks away while drifting up."""
    p0 = Vector(o.location)
    for fr in range(f, f + 16):
        t = fr - f
        _key_scale(o, fr, curve(t, [(0, 0, "linear"), (4, 1.25, "out"), (8, 1.0, "smooth"), (15, 0, "in")]))
        o.location = p0 + Vector((0, 0.04 * t, 0))
        o.keyframe_insert("location", frame=fr)
    show(o, f, f + 16)


def flicker(o, f0, f1, amt=0.08, seed=3):
    """Fire / glow: smooth random scale wobble."""
    rnd = random.Random(seed)
    ph = [rnd.uniform(0, 6.28) for _ in range(3)]
    for fr in range(f0, f1 + 1):
        n = sum(math.sin(fr * w + p) for w, p in zip((0.9, 1.7, 2.9), ph)) / 3
        o.scale = (1 + amt * 0.4 * n, 1 + amt * n, 1)
        o.keyframe_insert("scale", frame=fr)


class CamAnim:
    """Camera moves: eased push-ins / pull-outs / pans between framings + decaying shakes."""

    def __init__(self, cam, start, parallax=()):
        """parallax: [(layer empty, factor)] from a Location; far layers trail the camera for depth."""
        self.cam, self.keys, self.shakes = cam, [(-999, start, "linear")], []
        self.parallax = [(o, f, Vector(o.location)) for o, f in parallax]
        self.x0, self.y0 = start[0], start[1]

    def _at(self, f):
        ks = sorted(self.keys, key=lambda k: k[0])
        return tuple(curve(f, [(k, v[i], e) for k, v, e in ks]) for i in range(3))

    def push(self, f0, f1, to, ease="smooth"):
        """Eased move to `to` over [f0, f1]; moves can be added in any order."""
        self.keys = sorted(self.keys + [(f0, self._at(f0), "linear"), (f1, to, ease)], key=lambda k: k[0])

    def intro(self, dur=12, zoom=1.1):
        """Open a touch wide and settle onto the start framing, so the hook's first frames already move.
        Call it before any other move."""
        x, y, o = self.keys[0][1]
        self.keys = [(-999, (x, y, o * zoom), "linear")] + self.keys[1:]
        self.push(0, dur, (x, y, o), "out")

    def cut(self, f, to):
        self.keys = sorted(self.keys + [(f - 0.001, self._at(f - 0.001), "linear"), (f, to, "linear")], key=lambda k: k[0])

    def hud(self, obj, ref_ortho=22.0):
        """Keep a camera-parented overlay (captions, stickers) the same on-screen size while the camera zooms."""
        self.huds = getattr(self, "huds", []) + [(obj, ref_ortho)]

    def shake(self, f, dur, amp):
        self.shakes.append((f, dur, amp))

    DRIFT = 0.05  # a slow handheld drift (frame-height units at ortho 22), so no shot is ever dead still

    def bake(self, f0, f1):
        import locations
        # every set's own light comes alive (fire flicker, lamp buzz, sweeping beams), plus foreground depth layers
        self.parallax += [(o, fac, Vector(o.location)) for o, fac in locations.ambient(f0, f1)]
        ks = sorted(self.keys, key=lambda k: k[0])
        ks = ks + [(f1 + 1, ks[-1][1], "linear")]
        for fr in range(f0, f1 + 1):
            x, y, o = (curve(fr, [(k, v[i], e) for k, v, e in ks]) for i in range(3))
            for fi in IMPACTS:  # every take hits the camera: a quick punch-in and a shake
                if 0 <= fr - fi < 12:
                    o *= 1 - 0.04 * curve(fr - fi, [(0, 0, "linear"), (2, 1, "out"), (12, 0, "smooth")])
                    k = 0.3 * (1 - (fr - fi) / 9) ** 2 if fr - fi < 9 else 0.0
                    x += k * math.sin(fr * 2.9 + 0.7) * (o / 22)
                    y += k * math.sin(fr * 3.7 + 0.2) * (o / 22)
            x += self.DRIFT * (o / 22) * (math.sin(fr * 0.037 + 0.4) + 0.6 * math.sin(fr * 0.083))
            y += self.DRIFT * (o / 22) * 0.7 * (math.sin(fr * 0.029 + 1.7) + 0.5 * math.sin(fr * 0.071))
            for s0, d, amp in self.shakes:
                if s0 <= fr < s0 + d:
                    k = amp * (1 - (fr - s0) / d) ** 2
                    x += k * math.sin(fr * 2.9 + 1.3) * (o / 22)
                    y += k * math.sin(fr * 3.7) * (o / 22)
            self.cam.location = (x, y, 60)
            self.cam.data.ortho_scale = o
            self.cam.keyframe_insert("location", frame=fr)
            self.cam.data.keyframe_insert("ortho_scale", frame=fr)
            for obj, ref in getattr(self, "huds", []):
                obj.scale = (o / ref, o / ref, 1)
                obj.keyframe_insert("scale", frame=fr)
            for lay, fac, base in self.parallax:  # far layers follow the camera part of the way
                lay.location = base + Vector(((x - self.x0) * (1 - fac), (y - self.y0) * (1 - fac), 0))
                lay.keyframe_insert("location", frame=fr)
