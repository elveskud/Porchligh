# Frame-relative layout for vertical (9:16) and horizontal (16:9) videos.
# The camera's ortho scale is always the frame HEIGHT, and the camera-attached HUD layer is built at ortho 22,
# so a HUD item at (x, y) keeps its place and size through zooms. Place things by fraction of the frame
# (fx, fy from the top-left, 0..1) instead of hard-coded 1080x1920 pixels.
#
#   F = layout.from_cfg(cfg)            # cfg["format"]: "vertical" (default) or "horizontal"
#   sc = reset(); F.setup(sc, OFFBLACK)
#   cam = F.camera(sc, *F.default_cam(loc))
#   hook.location = (*F.hud_xy(0.5, 0.18), 0)
# Pure Python at import time (no bpy), so make.py can use the safe zones too.

FORMATS = {"vertical": (1080, 1920), "horizontal": (1920, 1080)}
REF = 22.0  # ortho of the HUD layer = frame height in HUD units

# platform UI to keep faces, captions and punchlines out of: (x, y, w, h) as fractions of the frame, from the top-left
SAFE_ZONES = {
    # TikTok / Reels / Shorts: top 220px, bottom 440px (caption + audio bar), right button column 140px wide up to 1100px
    "vertical": [(0, 0, 1, 220 / 1920), (0, 1 - 440 / 1920, 1, 440 / 1920), (1 - 140 / 1080, 1 - 1100 / 1920, 140 / 1080, 660 / 1920)],
    # YouTube: the progress bar along the bottom, and the bottom-right corner (watermark, end-screen elements)
    "horizontal": [(0, 0.94, 1, 0.06), (0.83, 0.8, 0.17, 0.14)],
}


class Frame:
    def __init__(self, fmt="vertical"):
        if fmt not in FORMATS:
            raise ValueError(f"format must be one of {list(FORMATS)}")
        self.fmt = fmt
        self.w, self.h = FORMATS[fmt]
        self.aspect = self.w / self.h
        self.vertical = fmt == "vertical"
        # Text scale on the HUD. Same fraction of frame height would read ~1.8x smaller on a phone turned sideways
        # (the height is then the short side); 1.5 sits between phone parity and a TV across the room.
        self.text_scale = 1.0 if self.vertical else 1.5

    def half(self, ortho=REF):
        """Half width and half height of the frame in world units at this ortho."""
        return ortho * self.aspect / 2, ortho / 2

    def hud_xy(self, fx, fy):
        """HUD-layer position for a point fx across, fy down the frame (0..1)."""
        return (fx - 0.5) * REF * self.aspect, (0.5 - fy) * REF

    def hud_y(self, fy):
        return (0.5 - fy) * REF

    def px_y(self, px, ref_h=1920):
        """Convert a y pixel written for a 1080x1920 frame into a fraction (for porting old layouts)."""
        return px / ref_h

    def eye_framing(self, x, eye_y, ortho, fy=0.52):
        """Camera (x, y, ortho) that puts the world line `eye_y` (e.g. the seated eye line) fy down the frame."""
        return x, eye_y - (0.5 - fy) * ortho, ortho

    def clean_close(self, loc, seat, ortho, eye_y=8.6, fy=0.45, reach=2.0, zoom=(0.85, 1.25)):
        """Close-up on one seated character whose frame edges never slice a neighbour's body: tries the camera
        up to `reach` units off the target and the ortho within `zoom` x the asked one, and keeps the clean
        framing nearest the target. Needs gaps between characters (16:9 sets after locations.widen())."""
        half = getattr(loc, "seat_half", 1.6)
        spans = [(s[0] - half, s[0] + half) for s in loc.seats]
        tx = loc.seats[seat][0]
        clean = lambda e: all(not (a < e < b) for a, b in spans)
        best = None
        for oi in range(int(zoom[0] * 40), int(zoom[1] * 40) + 1):
            o = ortho * oi / 40
            hw, _ = self.half(o)
            for k in range(int(reach * 50) + 1):
                for x in (tx + k / 50, tx - k / 50):
                    if clean(x - hw) and clean(x + hw):
                        cost = abs(x - tx) + 0.5 * abs(o - ortho)
                        if best is None or cost < best[0]:
                            best = (cost, x, o)
                        break
                else:
                    continue
                break
        if best is None:
            return self.eye_framing(tx, eye_y, ortho, fy)
        return self.eye_framing(best[1], eye_y, best[2], fy)

    def clean_span(self, loc, seats, eye_y=8.6, fy=0.45, min_ortho=7.2):
        """Smallest framing that shows these seats' characters whole, with neither edge cutting another body."""
        half = getattr(loc, "seat_half", 1.6)
        xs = [loc.seats[i][0] for i in seats]
        x0, x1 = min(xs) - half, max(xs) + half
        spans = [(s[0] - half, s[0] + half) for s in loc.seats]
        clean = lambda e: all(not (a < e < b) for a, b in spans)
        o = max(min_ortho, (x1 - x0 + 0.6) / self.aspect)
        for _ in range(400):
            hw, _h = self.half(o)
            c = (x0 + x1) / 2
            for k in range(0, 200):
                for x in (c + k / 100, c - k / 100):
                    if x - hw <= x0 - 0.2 and x + hw >= x1 + 0.2 and clean(x - hw) and clean(x + hw):
                        return self.eye_framing(x, eye_y, o, fy)
            o += 0.1
        return self.eye_framing((x0 + x1) / 2, eye_y, o, fy)

    def default_cam(self, loc):
        """The set's default framing for this format (horizontal needs locations.widen(loc) first)."""
        if self.vertical:
            return loc.cam
        if not getattr(loc, "cam_h", None):
            raise RuntimeError(f"{loc.name}: call locations.widen(loc) for a horizontal frame")
        return loc.cam_h

    def safe_zones(self):
        return SAFE_ZONES[self.fmt]

    def ffmpeg_zones(self, color="red@0.35"):
        """drawbox filters shading the platform UI zones (for the QA contact sheet)."""
        return ",".join(f"drawbox=x=iw*{x:.4f}:y=ih*{y:.4f}:w=iw*{w:.4f}:h=ih*{h:.4f}:color={color}:t=fill"
                        for x, y, w, h in self.safe_zones())

    def sheet_tile(self):
        """(tile width, tile height) for the one-frame-a-second QA sheet."""
        return (270, 480) if self.vertical else (480, 270)

    # ---- Blender side (imports toon lazily) ----
    def setup(self, sc, bg):
        from toon import setup_render
        setup_render(sc, self.w, self.h, bg=bg)

    def camera(self, sc, x, y, ortho):
        from toon import camera
        return camera(sc, x, y, ortho)


def from_cfg(cfg):
    return Frame(cfg.get("format") or "vertical")
