# Health check for the Friendzy video pipeline. Run before making videos in a new session:
#   python3 Blender/doctor.py
# Checks every tool, model and file the templates need, and prints how to fix anything missing.
import os, shutil, subprocess, sys

ROOT = os.path.dirname(os.path.abspath(__file__))
BLENDER = "/Applications/Blender.app/Contents/MacOS/Blender"
VENV_PY = os.path.join(ROOT, "voices/.venv/bin/python")
RHUBARB = os.path.join(ROOT, "tools/Rhubarb-Lip-Sync-1.14.0-macOS/rhubarb")
ok_all = True


def check(name, ok, fix=""):
    global ok_all
    ok_all &= bool(ok)
    print(f"  [{'OK ' if ok else 'BAD'}] {name}" + ("" if ok else f"\n        fix: {fix}"))


def runs(cmd):
    try:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=120).returncode == 0
    except Exception:
        return False


print("Friendzy video pipeline check")
check("Blender 5.x", os.path.exists(BLENDER), "install Blender to /Applications")
check("ffmpeg / ffprobe", shutil.which("ffmpeg") and shutil.which("ffprobe"), "brew install ffmpeg")
check("voices venv", os.path.exists(VENV_PY),
      "cd Blender/voices && python3 -m venv .venv && .venv/bin/pip install chatterbox-tts kokoro-onnx 'setuptools<81' pyloudnorm")
check("Chatterbox + watermark import", runs([VENV_PY, "-c", "import chatterbox, perth.perth_net"]),
      "Blender/voices/.venv/bin/pip install 'setuptools<81'")
check("audio libs (scipy, pyloudnorm)", runs([VENV_PY, "-c", "import scipy, pyloudnorm, numpy"]),
      "Blender/voices/.venv/bin/pip install scipy pyloudnorm")
check("Kokoro model files", all(os.path.exists(os.path.join(ROOT, "voices/kokoro", f)) for f in ("kokoro-v1.0.onnx", "voices-v1.0.bin")),
      "download kokoro-v1.0.onnx + voices-v1.0.bin from github.com/thewh1teagle/kokoro-onnx releases (model-files-v1.0) into Blender/voices/kokoro")
check("character base voices", all(os.path.exists(os.path.join(ROOT, "voices/refs", f"{c}.wav")) for c in ("riot", "bash", "pip", "rocco", "narrator")),
      "Blender/voices/.venv/bin/python Blender/voices/make_refs.py")
check("Rhubarb lip sync (needs Rosetta)", runs([RHUBARB, "--version"]),
      "softwareupdate --install-rosetta --agree-to-license  (and re-download Rhubarb 1.14 macOS into Blender/tools)")
check("app prompt libraries", os.path.isdir(os.path.join(ROOT, "../Friendzy/Models")), "run from the Friendzy repo")
check("Boogaloo font", os.path.exists(os.path.join(ROOT, "../Friendzy/Resources/Fonts/Boogaloo-Regular.ttf")), "restore Friendzy/Resources/Fonts")
for t in ("nhie", "mlt", "convo", "tod", "episode", "alias", "teaser", "mafia", "trivia", "whosaid", "hottakes", "challenges",
          "spy", "closecall", "wordassoc", "comeback", "feature"):
    check(f"template '{t}'", all(os.path.exists(os.path.join(ROOT, "templates", f"{t}_{p}.py")) for p in ("script", "scene")), "restore Blender/templates")
gi = os.path.join(ROOT, "../.gitignore")
check(".gitignore keeps renders out of git", os.path.exists(gi) and "Blender/videos/*" in open(gi).read(),
      "add the Blender block back to .gitignore (Blender/videos/*, !Blender/videos/tracker.csv, __pycache__/, ...)")
check("layout module (vertical + horizontal)", runs([sys.executable, "-c", f"import sys; sys.path.insert(0, '{ROOT}/characters'); import layout; layout.Frame('horizontal')"]),
      "characters/layout.py is missing or broken")
check("carousel + sticker tools", all(os.path.exists(os.path.join(ROOT, "templates", f)) for f in ("carousel.py", "sticker.py", "joke.py", "jokecues.py"))
      and runs([sys.executable, "-c", "import PIL, numpy"]),  # carousel.py / sticker.py run with this python3
      "restore Blender/templates/{carousel,sticker,joke,jokecues}.py; pip install pillow numpy")
check("thumbnail / render_week / feature tools", all(os.path.exists(os.path.join(ROOT, "templates", f)) for f in
      ("thumbnail.py", "render_week.py", "features.py")) and runs([sys.executable, "-c", f"import sys; sys.path.insert(0, '{ROOT}/templates'); "
      "import features, os; assert all(os.path.exists(features.shot(k)) for k, v in features.FEATURES.items() if v[0])"]),
      "restore Blender/templates/{thumbnail,render_week,features}.py and the screenshots in characters/refs/app/")
check("Blender can load the cast", runs([BLENDER, "--background", "--python-expr",
      f"import sys; sys.path.insert(0, '{ROOT}/characters'); import cast; cast.riot(); cast.bear(); cast.bunny(); cast.raccoon()"]),
      "a characters/*.py file is broken: run it in Blender to see the traceback")
print("\nALL GOOD - ready to make videos" if ok_all else "\nFix the BAD items above first.")
sys.exit(0 if ok_all else 1)
