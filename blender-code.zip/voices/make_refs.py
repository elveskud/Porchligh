# Generates each character's reference voice with Kokoro (local, Apache-2.0); speak.py clones from refs/<who>.wav.
#   .venv/bin/python make_refs.py
import os, soundfile as sf
from kokoro_onnx import Kokoro

HERE = os.path.dirname(os.path.abspath(__file__))
CAST = {  # character: (Kokoro voice, speed, a reference passage in their personality)
    "riot": ("am_puck", 1.05, "Okay okay, listen up! Tonight we're doing something wild. Grab your friends, pick a game, "
                               "and no backing out. Ooh, this is gonna be good. Let's gooo!"),
    "bash": ("am_onyx", 1.0, "I'm telling you, it was him! I saw the whole thing. Trust me on this one, I am never wrong. "
                             "Okay, maybe once. But not tonight!"),
    "pip": ("af_sky", 1.08, "W-wait, why is everyone looking at me? I didn't do anything, I swear! "
                            "Can we please just play something else? Please?"),
    "rocco": ("am_michael", 0.95, "Mm. Yeah, I heard you. I'm just eating. These chips are honestly amazing. "
                                  "Wait, what did I miss? Who's out?"),
    "narrator": ("bm_george", 0.92, "Night falls on the village. Everyone, close your eyes. Someone in this room "
                                    "is not who they say they are. And by morning, one of you will be gone."),
}
k = Kokoro(os.path.join(HERE, "kokoro/kokoro-v1.0.onnx"), os.path.join(HERE, "kokoro/voices-v1.0.bin"))
os.makedirs(os.path.join(HERE, "refs"), exist_ok=True)
for who, (voice, speed, line) in CAST.items():
    samples, sr = k.create(line, voice=voice, speed=speed, lang="en-us" if voice[0] == "a" else "en-gb")
    sf.write(os.path.join(HERE, "refs", f"{who}.wav"), samples, sr)
    print(who, voice, round(len(samples) / sr, 1), "s")
