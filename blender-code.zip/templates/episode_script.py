# Series episodes from a JSON script: several beats (location, cast, lines, game moments, props, camera,
# mood, SFX) chained into one 30-60 s vertical Short or a 2-4 min horizontal YouTube episode.
#   python3 make.py episode --script examples/campfire-confessions/ep01.json --format vertical|horizontal
# The JSON shape is documented in Blender/README.md. Pure Python: shared by make.py, mix.py and the scene.
import json, os

FPS = 30
STANDALONE = True
FORMATS = ("vertical", "horizontal")
PARALLEL = True             # make.py may split the render over several Blender processes
TITLE = "Episode"
BANDS = {"vertical": (30, 60), "horizontal": (120, 240)}
SEATS = {  # who sits where, per location (seat indices from locations.py)
    "default": {"bash": 0, "pip": 1, "riot": 2, "rocco": 3},
    "car": {"pip": 0, "rocco": 1, "riot": 2, "bash": 3},
}
MOOD_BED = {"normal": "chill", "tense": "suspense", "party": "hype"}
AMBIENCE = {"campfire": ("fire", 0.16), "lake": ("lake", 0.12), "lake_night": ("night", 0.14), "stoop_sunset": ("street", 0.1),
            "stoop_night": ("night", 0.12), "apartment": ("room", 0.08), "hall": ("hall", 0.16)}  # room tone per place
ROOM = {"hall": "hall", "apartment": "room"}  # voices get this room's echo (mix.ROOM_VERB)
MOVES = ("take", "laugh", "cheer", "nervous", "yell", "shrug", "facepalm", "wave", "thumbs", "present", "hop",
         "double_take", "point", "munch", "fan", "shiver", "stare")
GAP, BEAT_PAD = 8, 10      # frames between lines, frames before a beat's first line
WALK, STEP = 45, 11        # walk on/off timing (motion.WALK, motion.STEP)
CHAT_IN, CHAT_EVERY = 14, 22  # group chat: first bubble, then one every N frames
STORM_EVERY = 150             # frames between lightning flashes in a storm
SURFACE = {"lake": "sand", "lake_night": "sand", "stoop_sunset": "stone", "stoop_night": "stone", "apartment": "wood",
           "hall": "wood", "campfire": "sand"}
PORCH = {"click": 24, "black": 32, "logo": 40, "end": 105}  # "ending": "porch_light" timing, frames after the last beat


def load(cfg):
    path = cfg.get("script") or ""
    if not os.path.exists(path):
        raise SystemExit(f"episode: --script {path!r} not found")
    ep = json.load(open(path))
    fmt = cfg.get("format") or "vertical"
    ep["beats"] = [b for b in ep["beats"] if fmt in b.get("formats", FORMATS)]
    for bi, b in enumerate(ep["beats"]):
        b.setdefault("id", f"beat{bi}")  # line ids use the beat id, so both cuts of an episode share voices
        b.setdefault("location", "campfire")
        b.setdefault("cast", {"bash": None, "pip": None, "riot": None, "rocco": None})
        b.setdefault("camera", "wide")
        b.setdefault("mood", "normal")
        if "riot" not in b["cast"] and not (ep.get("riot_optional") and not b.get("game")):
            raise SystemExit(f"episode: beat {b.get('id')} has no Riot (he's in every beat; \"riot_optional\": true allows "
                             "beats without him, except game moments)")
    return ep


def hook(cfg):
    ep = load(cfg)
    return cfg.get("hook", "").replace("\\n", "\n") or ep["beats"][0].get("text", "")


def length(cfg):
    lo, hi = BANDS[cfg.get("format") or "vertical"]
    return lo, hi


def notes(cfg):
    ep = load(cfg)
    return f"series={ep['series']} ep={ep['episode']}"


def _game_lines(bid, g):
    """The spoken lines a game moment expands into: (id, who, text, role)."""
    p = f"{bid}_"
    t = g["type"]
    if t == "nhie":
        out = [(p + "read", "riot", g["prompt"], "read"), (p + "confess", g["target"], g["confess"], "confess")]
    elif t == "mlt":
        out = [(p + "read", "riot", g["prompt"], "read")]
    elif t == "td":
        pl = g.get("player", "riot")
        out = [(p + "choose", pl, g.get("choice", "dare").capitalize() + ".", "choose"),
               (p + "read", "riot", g["prompt"], "read"), (p + "perform", pl, g["perform"], "perform")]
    elif t == "alias":
        out = [(p + "clue", g["describer"], g["clue"], "clue"), (p + "guess", g["guesser"], g["guess"], "guess")]
    elif t == "feature":  # an app feature: the presenter's line while a REAL screenshot fills the frame
        import features
        features.shot(g["feature"])  # refuses features without a real screenshot
        out = [(p + "say", g.get("who", "riot"), g["say"], "say")]
    else:
        raise SystemExit(f"episode: unknown game type {t!r} (nhie, mlt, td, alias, feature)")
    return out + [(f"{p}after{k:02d}", l["who"], l["say"], "after") for k, l in enumerate(g.get("after", []))]


def lines(cfg):
    ep = load(cfg)
    out = []
    if ep.get("previously"):
        out.append(("prev", "riot", "Previously... " + ep["previously"]))
    for b in ep["beats"]:
        for li, l in enumerate(b.get("lines", [])):
            out.append((f"{b['id']}_{li:02d}", l["who"], l["say"]))
        if b.get("game"):
            out += [(i, w, t) for i, w, t, _ in _game_lines(b["id"], b["game"])]
        for li, l in enumerate(b.get("after", [])):
            out.append((f"{b['id']}_z{li:02d}", l["who"], l["say"]))
    if ep.get("ending") != "porch_light":  # the porch-light ending is silent
        out.append(("end", "riot", f"Next time on {ep['series']}: {ep['next']}!" if ep.get("next") else f"{ep['series']}. Free on Friendzy."))
    return out


def timeline(cfg, dur):
    """dur: {line id: seconds}. Returns the beat plan (frames) for the scene, the mix and the chapters."""
    ep = load(cfg)
    f = lambda s: int(round(s * FPS))
    s = lambda fr: round(fr / FPS, 3)
    wide = (cfg.get("format") or "vertical") == "horizontal"
    GAP, BEAT_PAD, LAUGH = (12, 16, 52) if wide else (8, 10, 40)  # the long cut breathes a little more
    t = 0
    beats, voices, sfx, music = [], [], [], []

    def say(lid, who, text, at, extra=None):
        ev = dict(id=lid, who=who, text=text, start=at, end=at + f(dur[lid]))
        ev.update(extra or {})
        voices.append([lid, s(at)] + ([ROOM[cur_loc[0]]] if cur_loc[0] in ROOM else []))
        return ev

    def spoken(b, bi, t):
        evs = []
        for li, l in enumerate(b.get("lines", [])):
            t += l.get("pause", GAP if li else 0)
            ev = say(f"{b['id']}_{li:02d}", l["who"], l["say"], t, {k: l[k] for k in ("do", "face", "camera", "target", "look", "emote", "quiet", "punch", "react") if k in l})
            evs.append(ev)
            t = ev["end"]
        return evs, t

    cur_loc = [None]
    for bi, b in enumerate(ep["beats"]):
        cur_loc[0] = b["location"]
        start = t
        B = dict(id=b.get("id", f"beat{bi}"), index=bi, start=start, location=b["location"], cast=b["cast"],
                 camera=b["camera"], mood=b["mood"], text=b.get("text", ""), prop=b.get("prop"),
                 chapter=b.get("chapter"), seats=b.get("seats"), fx=b.get("fx", []), enter=b.get("enter", {}),
                 exit=b.get("exit", {}), move=b.get("move"), carry=b.get("carry", {}), asleep=b.get("asleep", []), chat=b.get("chat", []),
                 weather=b.get("weather"), walk_to=b.get("walk_to", {}), transition=b.get("transition"),
                 letterbox=b.get("letterbox", False), events=[], game=None)
        t += BEAT_PAD if bi else 4
        if bi == 0 and ep.get("previously"):   # cold open first (the hook), then the recap
            evs, t = spoken(b, bi, t)
            B["events"] += evs
            t += GAP
            ev = say("prev", "riot", "Previously... " + ep["previously"], t, {"previously": ep["previously"]})
            B["events"].append(ev)
            t = ev["end"]
        else:
            evs, t = spoken(b, bi, t)
            B["events"] += evs
        g = b.get("game")
        if g:
            G = dict(g)
            gl = _game_lines(b["id"], g)
            ids = {role: lid for lid, _, _, role in gl if role != "after"}
            t += GAP
            if g["type"] in ("nhie", "mlt"):
                G["card_in"] = t
                t += 8
                ev = say(ids["read"], "riot", g["prompt"], t, {"role": "read", "caption": False})
                B["events"].append(ev)
                G["read"], G["read_end"] = ev["start"], ev["end"]
                G["stare"] = ev["end"] + (26 if g["type"] == "nhie" else 10)
                G["card_out"] = G["stare"] - 4
                sfx += [["card_flip", s(G["card_in"]), 0.6], ["whoosh", s(G["stare"] - 2), 0.45]]
                t = G["stare"] + (20 if g["type"] == "nhie" else 14)
                if g["type"] == "nhie":
                    sfx.append(["sting_suspense", s(G["stare"]), 0.35])
                    ev = say(ids["confess"], g["target"], g["confess"], t, {"role": "confess"})
                    B["events"].append(ev)
                    G["confess"], t = ev["start"], ev["end"]
                    sfx.append(["boing", s(G["confess"] - 3), 0.3])
                else:
                    sfx.append(["slam", s(G["stare"] + 4), 0.25])
                G["drop"] = [G["stare"] - 2, t]
            elif g["type"] == "td":
                pl = g.get("player", "riot")
                G["choice_in"] = t
                t += 10
                ev = say(ids["choose"], pl, g.get("choice", "dare").capitalize() + ".", t, {"role": "choose"})
                B["events"].append(ev)
                G["tap"] = ev["end"] + 1
                G["mystery"] = G["tap"] + 7
                G["flip"] = G["mystery"] + 16
                ev = say(ids["read"], "riot", g["prompt"], G["flip"] + 6, {"role": "read", "caption": False})
                B["events"].append(ev)
                G["read_end"] = ev["end"]
                G["card_out"] = ev["end"] + 2
                ev = say(ids["perform"], pl, g["perform"], ev["end"] + 8, {"role": "perform"})
                B["events"].append(ev)
                G["perform"], G["perform_end"] = ev["start"], ev["end"]
                t = ev["end"] + 4
                sfx += [["pop", s(G["choice_in"]), 0.4], ["slam", s(G["tap"]), 0.3], ["drumroll_short", s(G["mystery"] + 1), 0.4],
                        ["card_flip", s(G["flip"]), 0.6], ["boom", s(G["perform"] - 2), 0.4], ["scratch", s(t), 0.4]]
                G["drop"] = [G["perform"] - 4, t + 6]
            elif g["type"] == "feature":
                G["screen_in"] = t
                t += 8
                ev = say(ids["say"], g.get("who", "riot"), g["say"], t, {"role": "say"})
                B["events"].append(ev)
                G["screen_out"] = ev["end"] + 24
                t = G["screen_out"] + 4
                sfx += [["whoosh", s(G["screen_in"]), 0.4], ["ting", s(G["screen_in"] + 6), 0.4]]
            elif g["type"] == "alias":
                G["timer_in"] = t
                G["card_in"] = t + 6
                t += 14
                ev = say(ids["clue"], g["describer"], g["clue"], t, {"role": "clue"})
                B["events"].append(ev)
                t = ev["end"] + GAP
                ev = say(ids["guess"], g["guesser"], g["guess"], t, {"role": "guess"})
                B["events"].append(ev)
                G["tick"] = ev["end"] + 2
                G["card_out"] = G["tick"] + 22
                t = G["tick"] + 10
                sfx += [["whistle", s(G["timer_in"]), 0.35], ["card_flip", s(G["card_in"]), 0.5], ["ting", s(G["tick"]), 0.5]]
            for k, l in enumerate(g.get("after", [])):
                t += l.get("pause", GAP)
                ev = say(f"{b['id']}_after{k:02d}", l["who"], l["say"], t, {kk: l[kk] for kk in ("do", "face", "camera", "target", "look", "emote", "quiet", "punch", "react") if kk in l})
                B["events"].append(ev)
                t = ev["end"]
            laughs = g.get("laugh", g["type"] != "feature")  # JSON "laugh": false skips the group laugh
            G["laughs"] = laughs
            G["laugh"] = t + 3
            t = G["laugh"] + (LAUGH if laughs else 6)
            G["laugh_end"] = t
            if laughs:
                sfx.append(["popper", s(G["laugh"] + 2), 0.4])
            B["game"] = G
        for li, l in enumerate(b.get("after", [])):
            t += l.get("pause", GAP)
            ev = say(f"{b['id']}_z{li:02d}", l["who"], l["say"], t, {k: l[k] for k in ("do", "face", "camera", "target", "look", "emote", "quiet", "punch", "react") if k in l})
            B["events"].append(ev)
            t = ev["end"]
        t += b.get("hold", 20 if b["mood"] == "party" else 10) + (10 if wide else 0)
        if b.get("exit"):  # time for the walk off
            t += WALK + 6
        for k in range(len(b.get("chat", []))):  # group-chat bubbles pop in one by one
            sfx.append(["pop", s(start + CHAT_IN + k * CHAT_EVERY), 0.35])
        if b.get("exit_sfx"):  # e.g. "door": plays as the walk off ends
            sfx.append([b["exit_sfx"], s(t - 10), 0.4])
        if b.get("weather") == "storm":  # thunder a beat after each lightning flash (episode_scene.LIGHTNING)
            for k in range(0, (t - start) // STORM_EVERY + 1):
                sfx.append(["boom", s(start + 40 + k * STORM_EVERY + 18), 0.45])
        steps = SURFACE.get(b["location"])
        for k, (who, (spot, sec)) in enumerate(b.get("walk_to", {}).items()):  # footsteps for walks between spots
            for i in range(1, WALK // STEP + 1):
                sfx.append([f"step_{steps or 'stone'}{(i + k) % 4}", s(start + f(sec) + i * STEP), 0.25])
        for side_, walks in (("in", b.get("enter", {})), ("out", b.get("exit", {}))):  # footsteps on the set's surface
            for k, who in enumerate(walks):
                w0 = start + 2 if side_ == "in" else t - WALK - 4
                for i in range(1, WALK // STEP + 1):
                    sfx.append([f"step_{steps or 'stone'}{(i + k) % 4}", s(w0 + i * STEP + k * 3), 0.25])
        for ev in B["events"]:  # a soft musical hit on punchlines; a breath before quiet lines
            if ev.get("punch"):
                sfx.append(["ting", s(ev["end"] + 2), 0.2])
            if ev.get("quiet"):
                sfx.append(["breath", s(max(0, ev["start"] - 14)), 0.25])
        for ev in B["events"]:  # foley tied to moves: Rocco's chips crunch
            if ev.get("do") == "munch":
                sfx += [["crunch", s(ev["start"] + 10), 0.3], ["crunch", s(ev["start"] + 22), 0.25]]
        for name in b.get("sfx", []):  # names from mix.SOUNDS; "name@0.5" = 0.5 s into the beat
            n, _, off = name.partition("@")
            sfx.append([n, s(start + f(float(off or 0.1))), 0.4])
        B["end"] = t
        beats.append(B)
    end = t
    if ep.get("ending") == "porch_light":  # Porchlight: hold on the porch light, click, black, small Friendzy logo
        end_vo = end
        END = end + PORCH["end"]
        sfx.append(["click", s(end + PORCH["click"]), 0.5])
        sfx.append(["theme", s(end + PORCH["logo"] - 4), 0.35])  # the motif under the logo
    else:
        end_vo = end + 4
        END = end_vo + f(dur["end"]) + 14
        voices.append(["end", s(end_vo)])
        sfx += [["sting_fanfare", s(end), 0.45], ["slam", s(end), 0.25]]
    # music: one segment per run of beats with the same mood; tense game beats drop it out
    for B in beats:
        bed = {**MOOD_BED, **ep.get("beds", {})}[B["mood"]]  # an episode may pick its own beds, e.g. {"normal": "lofi"}
        drops = [B["game"]["drop"]] if B["game"] and "drop" in B["game"] else []
        drops += [[e["start"] - 20, e["end"] + 30] for e in B["events"] if e.get("quiet")]  # quiet lines: the music steps back
        if music and music[-1][0] == bed and music[-1][2] == B["start"]:
            music[-1][2] = B["end"]
            music[-1][4] += drops
        else:
            music.append([bed, B["start"], B["end"], 0.16 if bed != "suspense" else 0.2, drops])
    music[-1][2] = END
    music_s = [[m, s(a), s(b), g, [[s(x), s(y)] for x, y in d]] for m, a, b, g, d in music]
    # YouTube chapters: first at 0:00, each at least 10 s (short ones merge into the one before)
    chapters = []
    for B in beats:
        if B["chapter"]:
            at = 0 if not chapters else B["start"]
            if chapters and at - chapters[-1][0] < 10 * FPS:
                continue
            chapters.append([at, B["chapter"]])
    if chapters and END - chapters[-1][0] < 10 * FPS and len(chapters) > 1:
        chapters.pop()
    return {"beats": beats, "end": end, "end_vo": end_vo, "END": END, "voices": voices, "sfx": sfx,
            "music_segments": music_s,
            "ambience": [[AMBIENCE[B["location"]][0], s(B["start"]), AMBIENCE[B["location"]][1], s(B["end"] - B["start"])]
                         for B in beats if B["location"] in AMBIENCE]
                        + [["rain", s(B["start"]), 0.3, s(B["end"] - B["start"])] for B in beats if B.get("weather") == "storm"],
            "chapters": [[s(a), name] for a, name in chapters], "series": ep["series"], "episode": ep["episode"],
            "title": ep.get("title", ""), "next": ep.get("next", ""), "ending": ep.get("ending", "card"),
            "riot_phone": ep.get("riot_phone", False)}
