# Blender scene for the mystery teaser (teaser_script.py): night living room, lights off, Riot in a
# spotlight behind the coffee table lays out four glowing phones.
#   Blender --background --python teaser_scene.py -- <video dir>
import os, sys, json, random
HERE_T = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE_T, "../characters"))
sys.path.insert(0, HERE_T)
from toon import *
import cast, props, locations, motion
import teaser_script as S

OUT = sys.argv[sys.argv.index("--") + 1]
cfg = json.load(open(os.path.join(OUT, "config.json")))
C = json.load(open(os.path.join(OUT, "cues.json")))
END = C["END"]
vo = lambda i: os.path.join(OUT, "vo", f"{i}.wav")
text_of = {i: t for i, _, t in S.lines(cfg)}

sc = reset()
setup_render(sc, 1080, 1920, bg=OFFBLACK)
sc.frame_start, sc.frame_end = 0, END

# ---------- set: lights off, one spotlight on Riot and the table ----------
loc = locations.living_room("night")
set_visible(loc.extras["phone"], False)  # the table's own phone: our four replace it
light("dark", rect(-30, -30, 30, 40), "#05050A", 0.55, None, 14, smooth=0)
light("spot", [(-2.2, 24, "s"), (2.2, 24, "s"), (6.5, -2.0, "s"), (-6.5, -2.0, "s")], "#FFF3C4", 0.08, None, 14.5, smooth=0)
glow("spot_pool", (0, 1.6), 6.0, 1.6, "#FFF3C4", 0.05, 6, None, 12.05)

# ---------- Riot, standing behind the coffee table ----------
riot = cast.riot()
riot.root.location = (0.4, -2.6, 11)
r = motion.Anim(riot)
r.expr(0, "cocky")
# shh: paw up to the muzzle, finger raised (the hook), eyes darting
shh0, shh1 = C["click"] + 1, C["l1_riot"] + 22  # through the "Psst..."
r.add(lambda fr: None if not (shh0 <= fr <= shh1 + 8) else {
    "face1": motion.curve(fr, [(shh0, 0, "linear"), (shh0 + 5, 1, "back"), (shh1, 1, "linear"), (shh1 + 8, 0, "smooth")]),
    "hand1": "point", "face_y": -2.2,  # finger to the lips, not the eyes
    "head_y": 0.12 * motion.envelope(fr, shh0, shh1 + 8),  # leaning in
})
r.expr(shh0, "side_eye_l")
r.look(shh0 + 2, -0.5, 4)
r.look(shh0 + 9, 0.5, 4)
r.expr(shh0 + 9, "side_eye_r")
r.look(C["l1_riot"], 0.0, 5)
r.expr(C["l1_riot"] + 2, "cocky")
motion.talk(r, C["l1_riot"], vo("l1_riot"), text=text_of["l1_riot"], energy=0.7)

# four phones slid onto the table, one each side in turn
PX = [-3.3, -1.1, 1.1, 3.3]
phones = []
for k, fr in enumerate(C["phones"]):
    side = 1 if PX[k] > 0.4 else -1
    r.add(lambda f, fr=fr, side=side: None if not (fr - 8 <= f <= fr + 10) else {
        f"arm{side}": motion.curve(f, [(fr - 8, 10, "linear"), (fr - 2, 40, "out"), (fr + 2, 34, "back"), (fr + 10, 10, "smooth")]),
        f"elbow{side}": motion.curve(f, [(fr - 8, 8, "linear"), (fr - 2, 30, "out"), (fr + 10, 8, "smooth")]),
        f"hand{side}": "open" if fr - 4 <= f <= fr + 6 else "paw",
    })
    r.look(fr - 6, 0.35 * side, 4)
    g = empty(f"ph{k}", None, (PX[k], 2.55), 13)
    g.rotation_euler.z = rad((-1, 4, -3, 2)[k])
    p = props.phone(f"ph{k}_p", g, (0, 0), 0.0, 0.95)
    bpy.data.objects.remove(bpy.data.objects[f"ph{k}_p_logo"], do_unlink=True)  # blank glowing screen until the code
    gl = glow(f"ph{k}_glow", (PX[k], 2.6), 2.4 + 0.3 * k, 2.6 + 0.3 * k, ORANGE, 0.035 + 0.008 * k, 6, None, 12.9)
    set_visible(g, False, 0)
    set_visible(gl, False, 0)
    motion.pop_in(g, fr, 6, 1.12, 8)
    motion.pop_in(gl, fr + 1, 8, 1.3, 0)
    phones.append(g)
r.look(C["phones"][-1] + 10, 0.0, 5)
r.expr(C["phones"][0], "hype")

# the code: four letters spin on the screens, slow down and land on ????
ticks = S.code_frames(C)
rnd = random.Random(7)
for k, g in enumerate(phones):
    seq = [rnd.choice(S.CODE_LETTERS) for _ in ticks] + ["?"]
    starts = ticks + [C["code_end"]]
    objs = {}
    for i, (ch_, fr) in enumerate(zip(seq, starts)):
        key = ch_ if ch_ == "?" else f"{ch_}{i}"
        t = text(f"ph{k}_c{key}", ch_, 1.3, CHALK, g, (0, -0.32), 0.03)
        set_visible(t, False, 0)
        set_visible(t, True, fr)
        if i + 1 < len(starts):
            set_visible(t, False, starts[i + 1])
    q = bpy.data.objects[f"ph{k}_c?"]
    motion.pop_in(q, C["code_end"] + k, 5, 1.35, 10)
r.expr(C["code"], "drumroll")
r.add(lambda fr: None if not (C["code"] <= fr <= C["code_end"]) else {"head_y": -0.15, "brow": -0.04})  # leaning over the screens
motion.take(r, C["code_end"], "shocked", 0.7)

# "Everyone's gonna play": hugs himself, wiggling with excitement
r.expr(C["l2_riot"] - 2, "hype")
motion.talk(r, C["l2_riot"], vo("l2_riot"), text=text_of["l2_riot"])
h0, h1 = C["l2_riot"] + 2, C["l2_riot_end"] + 2
r.add(lambda fr: None if not (h0 <= fr <= h1 + 8) else {
    "arm1": motion.curve(fr, [(h0, 10, "linear"), (h0 + 6, -18, "back"), (h1, -18, "linear"), (h1 + 8, 10, "smooth")]),
    "elbow1": motion.curve(fr, [(h0, 8, "linear"), (h0 + 6, -112, "back"), (h1, -112, "linear"), (h1 + 8, 8, "smooth")]),
    "arm-1": motion.curve(fr, [(h0 + 1, 10, "linear"), (h0 + 7, -24, "back"), (h1, -24, "linear"), (h1 + 8, 10, "smooth")]),
    "elbow-1": motion.curve(fr, [(h0 + 1, 8, "linear"), (h0 + 7, -100, "back"), (h1, -100, "linear"), (h1 + 8, 8, "smooth")]),
    "rot": 4 * motion.envelope(fr, h0, h1 + 8) * math.sin((fr - h0) / 2.2),
    "sq": 1 + 0.03 * motion.envelope(fr, h0, h1 + 8) * math.sin((fr - h0) / 1.6),
})

# caught: looks straight at us, take, and the paw covers the lens
r.look(C["caught"] - 2, 0.0, 3)
motion.take(r, C["caught"], "shocked", 1.0)
r.bake(0, C["end"])

# ---------- the friends: three silhouettes peek over the couch behind him ----------
SIL = "#0A0B16"
# hallway light spills in behind them, as if someone just opened the door
door = empty("door", None, (-3.6, 11.5), -5.5)
light("door_light", rect(-3.4, -7.0, 3.4, 7.0), "#FFE3A3", 0.32, door, 0.0, smooth=0)
glow("door_glow", (0, 0), 5.5, 8.5, "#FFE3A3", 0.04, 6, door, 0.01)
set_visible(door, False, 0)
set_visible(door, True, C["friends"] - 3)
for k, (make, x) in enumerate(((cast.bear, -5.0), (cast.bunny, -3.3), (cast.raccoon, -1.7))):
    c = make()
    c.root.location = (x, 6.2, -4.5 + k * 0.01)  # heads just over the couch back
    c.root.scale = (0.66, 0.66, 1)
    for o in [c.root] + list(c.root.children_recursive):
        if getattr(o, "data", None) is not None and hasattr(o.data, "materials"):
            o.data.materials.clear()
            o.data.materials.append(mat(SIL))
    a = motion.Anim(c, seed=11 + k)
    fr0 = C["friends"] + 5 * k
    a.add(lambda fr, fr0=fr0: {"y": motion.curve(fr, [(fr0, -3.2, "linear"), (fr0 + 9, 0, "back")])})
    a.bake(0, C["end"])
    set_visible(c.root, False, 0)
    set_visible(c.root, True, fr0)

# ---------- camera: tight on the whisper, wide for the phones, push in on the code ----------
cam = camera(sc, 0.6, 9.5, 25)
start = (0.5, 6.4, 12.5)  # ortho = frame height
CA = motion.CamAnim(cam, start, loc.parallax)
CA.intro(10, 1.06)
CA.push(C["l1_riot_end"] - 6, C["phones"][0] - 2, (0.5, 6.2, 19.5), "smooth")
CA.push(C["code"] - 6, C["code"] + 4, (0.4, 3.9, 13.0), "out")
CA.push(C["code_end"] + 2, C["l2_riot"] + 4, (0.5, 7.0, 21.0), "out")
CA.push(C["caught"], C["caught"] + 5, (0.4, 5.9, 11.0), "out")
CA.shake(C["caught"] + 2, 8, 0.25)
EX = 100.0
CA.cut(C["end"], (EX, 3.6, 22.0))  # centres the logo and lines

# lights off until the click
blk = empty("blackout", cam, (0, 0), -1)
shape("blackout_bg", rect(-40, -40, 40, 40), "#000000", blk, 0.0, ol=0, smooth=0)
set_visible(blk, True, 0)
set_visible(blk, False, C["click"])

# hook (top, clear of the platform UI) and word captions (bottom)
hook = empty("hook_hud", cam, (0, 0), -6)
hook_box = props.caption_box("hook", S.hook(cfg), (0, (0.5 - 330 / 1920) * 22), 0, w=11.0, size=1.2)  # 330px from the top, clear of the app UI
hook_box.parent = hook
set_visible(hook_box, False, 0)
motion.pop_in(hook_box, C["click"] + 1, 6, 1.15, 4)  # the box pops; the holder only follows the zoom
motion.pop_out(hook_box, C["l1_riot_end"], 5)
CA.hud(hook)
for i, *_ in S.SCRIPT:
    CA.hud(props.word_captions(i, cam, motion.word_times(text_of[i], vo(i)), C[i], y_px=1460))  # below the mouth, above the bottom UI

# the paw: comes at the lens from below and fills the frame
paw = empty("paw", cam, (0, 0), -2)
shape("paw_main", ell(0, 0, 8.5, 9.5), ORANGE, paw, 0.0, ol=0.25)
shape("paw_pad", ell(0, -1.2, 4.2, 3.6), "#F7E6C8", paw, 0.01, ol=0.15)
for j, (x, y) in enumerate(((-5.2, 4.2), (-1.8, 6.6), (1.8, 6.6), (5.2, 4.2))):
    shape(f"paw_toe{j}", ell(x, y, 1.5, 1.8), "#F7E6C8", paw, 0.01, ol=0.15)
set_visible(paw, False, 0)
set_visible(paw, True, C["paw"])
set_visible(paw, False, C["end"])
for fr in range(C["paw"], C["end"] + 1):
    t = motion.clamp01((fr - C["paw"]) / 7)
    k = 0.25 + 1.85 * motion.EASE["in"](t)
    paw.scale = (k, k, 1)
    paw.location = (0, -16 * (1 - t), -2)
    paw.keyframe_insert("scale", frame=fr)
    paw.keyframe_insert("location", frame=fr)
CA.bake(0, END)

# ---------- end card: black, FRIENDZY sprays in, then the line ----------
props.end_card("end", S.CARD, (EX, 0.0), -5)
bg = bpy.data.objects["end_bg"]
bg.data.materials.clear()
bg.data.materials.append(mat(OFFBLACK))
for i in range(46):
    set_visible(bpy.data.objects[f"end_dot{i}"], False)
sub2 = empty("end_sub2", bpy.data.objects["end"], (0, 0.9), 0.1)
props.outlined_text("end_sub2_t", S.CARD_SUB, 0.85, ORANGE, sub2, (0, 0), 0.0, 0.06)
for i in range(8):
    l = bpy.data.objects[f"end_l{i}"]
    set_visible(l, False, 0)
    motion.slam_in(l, C["end"] + 2 + i * 2, 1.8, 4)
for nm, fr in (("end_sub", C["end"] + 22), ("end_sub2", C["end"] + 30)):
    o = bpy.data.objects[nm]
    set_visible(o, False, 0)
    motion.pop_in(o, fr, 6)

bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, "scene.blend"))
frames = os.environ.get("FRAMES")
if frames:
    for fr in map(int, frames.split(",")):
        still(sc, os.path.join(OUT, "stills", f"s_{fr:04d}.png"), fr)
else:
    sc.render.filepath = os.path.join(OUT, "frames", "f_")
    bpy.ops.render.render(animation=True)
