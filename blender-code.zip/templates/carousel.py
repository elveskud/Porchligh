# Instagram carousel slides (1080x1350) and story images (1080x1920) starring Riot and the cast.
#   python3 carousel.py <slides.json> [--name NAME] [--preview N] [--out DIR]
# One headless Blender run draws the set + characters for every slide (code-drawn cast only), then Pillow lays the
# text and the app's sticker card on top, placed above the faces Blender reports back. Output:
#   Blender/videos/carousels/<name>/01.png, 02.png, ... + contact.png (+ layout.json with the face boxes)
# The JSON shape is documented in Blender/README.md ("Carousels and stories"). --preview N renders only slide N.
import json, math, os, random, subprocess, sys, tempfile, time

HERE = os.path.dirname(os.path.abspath(__file__))
CHARS = os.path.normpath(os.path.join(HERE, "../characters"))
FONTS = os.path.normpath(os.path.join(HERE, "../../Friendzy/Resources/Fonts"))
VIDEOS = os.path.normpath(os.path.join(HERE, "../videos/carousels"))
BLENDER = os.environ.get("BLENDER", "/Applications/Blender.app/Contents/MacOS/Blender")

ORANGE, RED, YELLOW, OFFBLACK, CHALK, CHARCOAL = "#FF6B00", "#E8192C", "#FFD600", "#121212", "#F5F0E8", "#1E1E1E"

# Frame geometry. Every set spans x -9..9, y -3..23, so both cameras end at the top of the set (y 23).
# ortho = frame height in world units; ppu = pixels per unit.
KINDS = {
    "carousel": dict(w=1080, h=1350, ortho=22.0, cam_y=12.0, text_top=60, cast_bottom=1350, card_w=780, kh_min=0.78, s_min=0.75),
    # story: top 220 px free of text (IG header), bottom 640 px left for a poll sticker: the characters stand
    # behind a desk whose top edge is the 1280 px line, so nothing but background sits in the lower third
    "story": dict(w=1080, h=1920, ortho=26.0, cam_y=10.0, text_top=250, cast_bottom=1280, card_w=900, kh_min=0.9, s_min=0.55),
}
MARGIN = 60
BACKGROUNDS = ("living_room_day", "living_room_night", "campfire", "car", "orange", "offblack")
FRIENDS = {"pip": "bunny", "bunny": "bunny", "bash": "bear", "bear": "bear", "rocco": "raccoon", "raccoon": "raccoon"}
EXPRS = ("hype", "cocky", "drumroll", "shocked", "laughing", "suspicious", "nervous", "yelling", "happy", "side_eye_l", "side_eye_r")
POSES = ("idle", "point", "wave", "cheer", "thumbs", "shrug", "crossed", "facepalm", "present", "explain", "mic")
COSTUMES = ("hoodie", "mafia", "dare", "coach", "host")
END_TEXT = "Friendzy — link in bio"

try:
    import bpy  # noqa: F401  (inside Blender)
    IN_BLENDER = True
except ImportError:
    IN_BLENDER = False


def geom(kind):
    g = dict(KINDS[kind])
    g["ppu"] = g["h"] / g["ortho"]
    g["hw"] = g["ortho"] * g["w"] / g["h"] / 2          # half frame width in units
    g["top"] = g["cam_y"] + g["ortho"] / 2               # world y of the top edge
    return g


def px_to_y(g, py):
    return g["top"] - py / g["ppu"]


# =====================================================================================================
# Blender side: draw every slide's set + cast, render, and report where the faces landed (pixels)
# =====================================================================================================

def blender_main(plan_path):
    sys.path.insert(0, CHARS)
    import bpy
    from mathutils import Vector
    import toon
    from toon import reset, setup_render, camera, still
    import cast, locations

    plan = json.load(open(plan_path))
    report = []

    def bbox(objs):
        xs, ys = [], []
        for o in objs:
            if o.type not in ("MESH", "CURVE", "FONT") or o.hide_render:
                continue
            for c in o.bound_box:
                v = o.matrix_world @ Vector(c)
                xs.append(v.x); ys.append(v.y)
        return (min(xs), min(ys), max(xs), max(ys)) if xs else None

    def flat_bg(name, g, color, accent, dots, spot=0.07):
        r = toon.empty(name)
        hw, top = g["hw"] + 1, g["top"] + 1
        bot = g["top"] - g["ortho"] - 1
        toon.shape(name + "_bg", toon.rect(-hw, bot, hw, top), color, r, -9, ol=0, smooth=0)
        # big soft spotlight behind Riot + spray-paint dots, like the end card
        toon.glow(name + "_spot", (0, bot + g["ortho"] * 0.42), hw * 1.05, g["ortho"] * 0.42, accent, spot, 7, r, -8)
        rnd = random.Random(7)
        for i in range(60):
            x, y = rnd.uniform(-hw, hw), rnd.uniform(bot, top)
            s = rnd.uniform(0.05, 0.12)
            toon.shape(f"{name}_dot{i}", toon.ell(x, y, s, s, n=8), dots[i % len(dots)], r, -7.9, ol=0)
        return r

    def desk(name, g, y_cut, color, trim):
        """Story only: the table the cast stands behind; its top edge is the poll-sticker line."""
        r = toon.empty(name, None, (0, 0), 16.5)
        hw = g["hw"] + 1.5
        toon.shape(name + "_top", toon.rect(-hw, g["top"] - g["ortho"] - 2, hw, y_cut), color, r, 0.0, smooth=0)
        toon.stroke(name + "_trim", [(-hw, y_cut - 0.55), (hw, y_cut - 0.55)], 0.16, trim, r, 0.01)
        return r

    for s in plan["slides"]:
        g = geom(plan["kind"])
        sc = reset()
        bgname = s["background"]
        bgcol = {"orange": ORANGE, "offblack": OFFBLACK}.get(bgname, OFFBLACK)
        setup_render(sc, g["w"], g["h"], bg=bgcol)

        # ---- set ----
        if bgname.startswith("living_room"):
            variant = bgname.split("_")[-1]
            loc = locations.living_room(variant)
            desk_col, desk_trim = locations.ROOM[variant]["table"], "#5E3A1F" if variant == "day" else "#33242A"
        elif bgname == "campfire":
            loc = locations.campfire()
            for o in [bpy.data.objects["cf_fire"]] + list(bpy.data.objects["cf_fire"].children_recursive):
                o.hide_render = True
            desk_col, desk_trim = "#7A4E2D", "#5E3A1F"
        elif bgname == "car":
            loc = locations.car()
            desk_col, desk_trim = "#2B2F38", "#454B57"
        else:
            loc = None
            if bgname == "orange":
                flat_bg("flat", g, ORANGE, "#FFE08A", (YELLOW, OFFBLACK, OFFBLACK))
                desk_col, desk_trim = OFFBLACK, ORANGE
            else:
                flat_bg("flat", g, OFFBLACK, ORANGE, (ORANGE, YELLOW, "#3A3A3A"), spot=0.03)
                desk_col, desk_trim = CHARCOAL, ORANGE
        if loc is not None:
            # light beams read as a smear across a still's faces: drop them (glows and tints stay)
            for o in list(bpy.data.objects):
                if o.name.startswith("lr_beam") or (o.name.startswith("car_sun") and o.parent is loc.root):
                    o.hide_render = True
            # the sets' vignettes are sized for the video camera: rebuild one for this frame
            for o in list(bpy.data.objects):
                if "_vig" in o.name:
                    bpy.data.objects.remove(o, do_unlink=True)
            toon.vignette("cv_vig", 0, g["cam_y"], g["hw"] + 1, g["ortho"] / 2 + 1, None, 30,
                          0.18 if bgname in ("living_room_night", "campfire") else 0.08)
            if bgname == "campfire":
                toon.glow("cv_fireglow", (0, g["top"] - g["ortho"] + 1), 9, 7, "#FF8A3D", 0.04, 6, None, 9.5)

        # ---- cast ----
        cs = s["cast"]
        chars = []
        for ch in cs:
            if ch["who"] == "riot":
                c = cast.riot(ch.get("costume", "hoodie"))
            else:
                c = getattr(cast, FRIENDS[ch["who"]])()
                if "sweat" in c.extras:
                    toon.set_visible(c.extras["sweat"], ch.get("expr") == "nervous")
            if ch.get("pose"):
                c.pose(ch["pose"])
                if ch.get("costume") == "host" and ch["pose"] == "mic" and "mic" in c.extras:
                    c.extras["mic"].rotation_euler.z = -(c.arms[1].rotation_euler.z + c.elbows[1].rotation_euler.z)
            if ch.get("expr"):
                c.expr(ch["expr"])
            if ch.get("turn"):
                c.turn(ch["turn"])
            chars.append((ch, c))
        bpy.context.view_layer.update()
        # top of each character at scale 1 with the root at the origin (arms up raise it)
        riot_top1 = bbox(chars[0][1].root.children_recursive)[3]
        chin1 = {id(c): bbox(c.extras["head"].children_recursive)[1] for _, c in chars}
        y_cast = px_to_y(g, s["cast_top"])
        root_y = y_cast - riot_top1 * cs[0]["scale"]
        riot_chin = root_y + chin1[id(chars[0][1])] * cs[0]["scale"]
        for ch, c in chars:
            # friends' chins line up with Riot's, so their (smaller) faces never sink below the frame / desk
            ry = root_y if ch["who"] == "riot" else riot_chin - chin1[id(c)] * ch["scale"]
            c.root.location = (ch["x"], ry, ch["z"])
            c.root.scale = (ch["scale"], ch["scale"], ch.get("zs", 1.0))
        if plan["kind"] == "story":
            desk("cv_desk", g, px_to_y(g, g["cast_bottom"]), desk_col, desk_trim)
        camera(sc, 0, g["cam_y"], g["ortho"])
        bpy.context.view_layer.update()

        def to_px(b):
            x0 = -g["hw"]
            return [round((b[0] - x0) * g["ppu"]), round((g["top"] - b[3]) * g["ppu"]),
                    round((b[2] - x0) * g["ppu"]), round((g["top"] - b[1]) * g["ppu"])]

        faces = []
        for ch, c in chars:
            faces.append(dict(who=ch["who"], head=to_px(bbox(c.extras["head"].children_recursive)),
                              body=to_px(bbox(c.root.children_recursive))))
        still(sc, s["raw"], 0)
        report.append(dict(index=s["index"], faces=faces))
        print(f"CAROUSEL rendered slide {s['index']} at {time.time():.1f}", flush=True)
    json.dump(report, open(plan["report"], "w"), indent=1)


# =====================================================================================================
# Python side: plan, run Blender, lay out text with Pillow
# =====================================================================================================

def font(name, size, weight=None):
    from PIL import ImageFont
    f = ImageFont.truetype(os.path.join(FONTS, name), size)
    if weight:
        try:
            f.set_variation_by_axes([weight])
        except Exception:
            pass
    return f


def boogaloo(size):
    return font("Boogaloo-Regular.ttf", int(size))


def nunito(size, weight=800):
    return font("Nunito-Variable.ttf", int(size), weight)


def hexrgb(h, a=255):
    return tuple(int(h[i:i + 2], 16) for i in (1, 3, 5)) + (a,)


# ---------- rich text: *word* = Electric Yellow ----------

def tokens(text, base, accent):
    out = []
    for line in text.split("\n"):
        words = []
        for w in line.split():
            hi = w.startswith("*") or w.endswith("*")
            words.append((w.strip("*"), accent if hi else base))
        out.append(words)
    return out


def wrap_tokens(paras, f, width):
    lines = []
    space = f.getlength(" ")
    for words in paras:
        cur, cw = [], 0.0
        for w, col in words:
            ww = f.getlength(w)
            if cur and cw + space + ww > width:
                lines.append(cur)
                cur, cw = [], 0.0
            cur.append((w, col, ww))
            cw += (space if len(cur) > 1 else 0) + ww
        lines.append(cur)
    return lines


def text_block(text, size, width, base=CHALK, accent=YELLOW, lead=0.98):
    """Measure a wrapped headline; returns dict with lines and height (draw with draw_block)."""
    f = boogaloo(size)
    paras = tokens(text, base, accent)
    lines = wrap_tokens(paras, f, width)
    if len(lines) > len(paras):  # balance the lines (no one-word orphan): narrowest width with the same count
        lo, hi = width * 0.4, width
        for _ in range(14):
            mid = (lo + hi) / 2
            if len(wrap_tokens(paras, f, mid)) == len(lines):
                hi = mid
            else:
                lo = mid
        lines = wrap_tokens(paras, f, hi)
    lh = size * lead
    widest = max((sum(w for _, _, w in ln) + f.getlength(" ") * (len(ln) - 1)) for ln in lines)
    return dict(f=f, size=size, lines=lines, lh=lh, h=lh * len(lines) + size * 0.12, w=widest)


def draw_block(img, blk, cx, y, stroke=True):
    from PIL import ImageDraw
    d = ImageDraw.Draw(img)
    f, size = blk["f"], blk["size"]
    sw = max(3, round(size * 0.085)) if stroke else 0
    sh = (round(size * 0.05), round(size * 0.07))
    space = f.getlength(" ")
    for i, ln in enumerate(blk["lines"]):
        lw = sum(w for _, _, w in ln) + space * (len(ln) - 1)
        ly = y + i * blk["lh"]
        for pass_ in ("shadow", "text"):
            x = cx - lw / 2
            for w, col, ww in ln:
                if pass_ == "shadow" and stroke:
                    d.text((x + sh[0], ly + sh[1]), w, font=f, fill=hexrgb(OFFBLACK), stroke_width=sw, stroke_fill=hexrgb(OFFBLACK))
                elif pass_ == "text":
                    d.text((x, ly), w, font=f, fill=hexrgb(col), stroke_width=sw, stroke_fill=hexrgb(OFFBLACK))
                x += ww + space


# ---------- the app's sticker card (props.prompt_card, drawn in Pillow) ----------

CATEGORY = {"wild": ("#FF8A3D", "#FFD2B3", "#9A3000"), "funny": ("#E8B23D", "#FBEFD2", "#8A6608"),
            "brain": ("#3F87C7", "#DCEAF7", "#185FA5"), "social": ("#3FAE8E", "#C9EEE1", "#0F6E56")}
GAMES = {"truth": ("TRUTH", "wild"), "dare": ("DARE", "wild"), "challenge": ("CHALLENGE", "wild"), "mafia": ("MAFIA", "wild"),
         "nhie": ("NEVER HAVE I EVER", "social"), "wyr": ("WOULD YOU RATHER", "social"), "mlt": ("MOST LIKELY TO", "funny"),
         "hottakes": ("HOT TAKE", "funny"), "alias": ("ALIAS", "brain"), "trivia": ("TRIVIA", "brain")}


def rrect4(x0, y0, x1, y1, r, n=8):
    """Rounded rect (image coords, y down) with radii r = (top-left, top-right, bottom-right, bottom-left)."""
    pts = []
    for (cx, cy, a0), rr in zip(((x0, y0, 180), (x1, y0, 270), (x1, y1, 0), (x0, y1, 90)), r):
        rr = max(rr, 0.5)
        ox = cx + rr if cx == x0 else cx - rr
        oy = cy + rr if cy == y0 else cy - rr
        pts += [(ox + rr * math.cos(math.radians(a0 + 90 * i / n)), oy + rr * math.sin(math.radians(a0 + 90 * i / n))) for i in range(n + 1)]
    return pts


def card_layout(game, text, width, size):
    """Measure the card's body: list of (kind, block) rows. WYR shows option / OR / option like the app."""
    pad = width * 0.09
    inner = width - 2 * pad
    rows = []
    parts = text.split("\nOR\n") if game == "wyr" else [text]
    for i, p in enumerate(parts):
        if i:
            rows.append(("or", text_block("OR", size * 0.75, inner, base=CATEGORY[GAMES[game][1]][0])))
        rows.append(("txt", text_block(p.replace("\n", " "), size, inner, base=OFFBLACK, lead=1.02)))
    u = width / 8.6
    body_h = sum(b["h"] for _, b in rows) + (len(rows) - 1) * size * 0.12
    h = 1.1 * u + body_h + 1.15 * u
    return rows, h, u


def card_image(game, text, width, size, tilt=-2.5):
    """Sticker card on a transparent RGBA image (supersampled 2x): white card, off-black outline, flat offset
    shadow, coloured category band with the game pill, FRIENDZY footer, slight tilt."""
    from PIL import Image, ImageDraw
    header, cat = GAMES[game]
    icon, badge, badge_text = CATEGORY[cat]
    rows, h, u = card_layout(game, text, width, size)
    S = 2
    W, H = width * S, int(h * S)
    ol, shx, shy = 0.1 * u * S, 0.22 * u * S, 0.28 * u * S
    pad = int(ol + max(shx, shy) + 4)
    im = Image.new("RGBA", (W + 2 * pad, H + 2 * pad), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    big, small = 0.9 * u * S, 0.35 * u * S
    radii = (small, big, small, big)  # app sticker: asymmetric corners
    x0, y0, x1, y1 = pad, pad, pad + W, pad + H
    grow = lambda r: tuple(v + ol for v in r)
    d.polygon(rrect4(x0 - ol + shx, y0 - ol + shy, x1 + ol + shx, y1 + ol + shy, grow(radii)), fill=hexrgb(OFFBLACK))
    d.polygon(rrect4(x0 - ol, y0 - ol, x1 + ol, y1 + ol, grow(radii)), fill=hexrgb(OFFBLACK))
    d.polygon(rrect4(x0, y0, x1, y1, radii), fill=hexrgb("#FFFFFF"))
    band = 1.1 * u * S
    d.polygon(rrect4(x0, y0, x1, y0 + band, (small, big, 0, 0)), fill=hexrgb(icon))
    hf = nunito(0.36 * u * S, 900)
    pw = hf.getlength(header) + 0.9 * u * S
    ph = 0.62 * u * S
    cy = y0 + band / 2
    d.rounded_rectangle((W / 2 + pad - pw / 2, cy - ph / 2, W / 2 + pad + pw / 2, cy + ph / 2), radius=ph / 2, fill=hexrgb(badge))
    d.text((W / 2 + pad, cy), header, font=hf, fill=hexrgb(badge_text), anchor="mm")
    # body rows (drawn at 2x)
    y = y0 + band + 0.32 * u * S
    for kind, b in rows:
        f = boogaloo(b["size"] * S)
        for i, ln in enumerate(b["lines"]):
            line = " ".join(w for w, _, _ in ln)
            col = ln[0][1] if ln else OFFBLACK
            d.text((W / 2 + pad, y + (i + 0.5) * b["lh"] * S), line, font=f, fill=hexrgb(col), anchor="mm")
        y += b["h"] * S + b["size"] * 0.12 * S
    ff = boogaloo(0.42 * u * S * 1.25)
    d.text((W / 2 + pad, y1 - 0.48 * u * S), "FRIENDZY", font=ff, fill=hexrgb(icon), anchor="mm")
    im = im.resize((im.width // S, im.height // S), Image.LANCZOS)
    return im.rotate(tilt, resample=Image.BICUBIC, expand=True)


# ---------- planning ----------

def norm_slide(s, i, kind):
    s = dict(s)
    s.setdefault("text", "")
    bg = s.get("background", "orange")
    if bg not in BACKGROUNDS:
        raise SystemExit(f"slide {i + 1}: background must be one of {BACKGROUNDS}")
    s["background"] = bg
    r = dict(s.get("riot") or {})
    r.setdefault("costume", "hoodie")
    r.setdefault("pose", "present" if s.get("card") else "idle")
    r.setdefault("expr", "cocky" if r["costume"] in ("mafia", "dare") else "hype")
    for k, allowed in (("costume", COSTUMES), ("pose", POSES), ("expr", EXPRS)):
        if r[k] not in allowed:
            raise SystemExit(f"slide {i + 1}: riot {k} must be one of {allowed}")
    s["riot"] = r
    fr = []
    for f in s.get("friends") or []:
        f = dict(f)
        if f.get("who") not in FRIENDS:
            raise SystemExit(f"slide {i + 1}: friend 'who' must be one of {sorted(FRIENDS)}")
        f.setdefault("expr", "nervous" if FRIENDS[f["who"]] == "bunny" else "happy")
        if f["expr"] not in EXPRS or f.get("pose", "idle") not in POSES:
            raise SystemExit(f"slide {i + 1}: bad friend expr/pose")
        fr.append(f)
    if len(fr) > 2:
        raise SystemExit(f"slide {i + 1}: at most 2 friends per slide (Riot stays the star)")
    s["friends"] = fr
    if s.get("card"):
        c = s["card"]
        if c.get("game") not in GAMES or not c.get("text"):
            raise SystemExit(f"slide {i + 1}: card needs game (one of {sorted(GAMES)}) and text")
    return s


def is_end(s):
    return bool(s.get("end")) or "link in bio" in s.get("text", "").lower()


def end_slide():
    return {"end": True, "text": END_TEXT, "background": "orange",
            "riot": {"pose": "wave", "expr": "hype", "costume": "hoodie"}}


def plan_text(s, g, kind):
    """Pick text sizes so headline + sub + card fit above the cast; returns (elements, cast_top)."""
    width = g["w"] - 2 * MARGIN
    max_s, min_vis = 1.45, (420 if kind == "carousel" else 340)
    lo = g["cast_bottom"] - 8.3 * max_s * g["ppu"]      # Riot never bigger than this
    hi = g["cast_bottom"] - min_vis                      # ...or smaller than this
    gap = 34
    for i in range(14):  # shrink the card first, the headline only a little
        k, kh = 1.0 - 0.04 * i, max(g["kh_min"], 1.0 - 0.025 * i)
        els = []
        if s.get("end"):
            words = s["text"].split("—", 1)
            els.append(("wordmark", dict(size=int(200 * k), h=int(200 * k * 1.05))))
            rest = words[1].strip() if len(words) > 1 else ""
            if rest:
                els.append(("text", text_block(rest, int(96 * k), width)))
            if s.get("sub"):
                els.append(("text", text_block(s["sub"], int(60 * k), width, base=YELLOW)))
        else:
            if s.get("text"):
                big = 112 if not s.get("card") else 92
                els.append(("text", text_block(s["text"], int(big * kh), width)))
            if s.get("sub"):
                els.append(("text", text_block(s["sub"], int(72 * kh), width, base=YELLOW, accent=CHALK)))
            if s.get("card"):
                cw = int(min(g["card_w"], width - 60) * (0.9 + 0.1 * k))
                size = int(cw / 8.6 * 0.72 * k)
                rows, h, u = card_layout(s["card"]["game"], s["card"]["text"], cw, size)
                els.append(("card", dict(w=cw, size=size, h=h * 1.06 + 0.3 * u)))
        total = sum(e[1]["h"] for e in els) + gap * (len(els) - 1)
        need = g["text_top"] + total + 40
        if need <= hi:
            return els, max(lo, need), total
    return els, hi, total


# how far Riot's left arm (viewer's left) reaches past his head in each pose, in units at scale 1
ARM_OUT = {"cheer": 1.3, "shrug": 1.8}
# z: Riot's body sits at 14.2 (his tail at 13.6); the friend next to him is squeezed in at 13.65..14.05 so he
# covers Riot's tail but never Riot himself; the outer friend sits behind both
Z_RIOT, Z_NEAR, Z_FAR, Z_SQUASH = 14.2, 13.85, 13.0, 0.4


def place_cast(s, g, cast_top, kind):
    """Riot on the right (his raised arm and tail have room there), friends to his left facing him; nobody's
    face overlaps anyone else's. Scales: Riot from the space under the text, friends at most 0.74x Riot."""
    avail = g["cast_bottom"] - cast_top
    sc = max(g["s_min"], min(1.45, avail / (8.3 * g["ppu"])))
    r = s["riot"]
    fr = s["friends"]
    hw = g["hw"]
    riot_half = 2.7 * sc
    arm = ARM_OUT.get(r["pose"], 0.0) * sc
    head_half = 2.55   # friend head half-width at scale 1 (Pip's floppy ear a bit more)
    gap = 0.3
    n = len(fr)
    fs = 0.74 * sc
    if n:
        room = 2 * hw - 0.4 - 2 * riot_half - arm - gap * (n + 1)
        fs = max(0.45, min(fs, room / (2 * head_half * n)))
    total = 2 * riot_half + arm + n * (2 * head_half * fs + gap)
    x = -total / 2 if n else -0.5 * sc - riot_half
    out = []
    for i, f in enumerate(fr):
        x += head_half * fs
        out.append(dict(who=f["who"], expr=f["expr"], pose=f.get("pose", "idle"), scale=fs, x=x, turn=0.55,
                        z=Z_NEAR if i == n - 1 else Z_FAR, zs=Z_SQUASH))
        x += head_half * fs + gap
    x += arm + riot_half
    riot = dict(who="riot", costume=r["costume"], pose=r["pose"], expr=r["expr"], scale=sc, x=x,
                turn=-0.2 if n else 0.0, z=Z_RIOT, zs=1.0)
    return [riot] + out


def compose(s, g, kind, raw, faces, els, total, out_path):
    from PIL import Image, ImageDraw
    img = Image.open(raw).convert("RGBA")
    face_top = min(f["head"][1] for f in faces)
    body_top = min(f["body"][1] for f in faces)
    zone_bot = min(face_top, body_top) - 26
    zone_top = g["text_top"]
    gap = 34
    y = zone_top + max(0, (zone_bot - zone_top - total) / 2)
    cx = g["w"] / 2
    boxes = []
    for kind_, e in els:
        if kind_ == "text":
            draw_block(img, e, cx, y)
            boxes.append((cx - e["w"] / 2, y, cx + e["w"] / 2, y + e["h"]))
        elif kind_ == "wordmark":
            wm = wordmark("FRIENDZY", e["size"])
            img.alpha_composite(wm, (int(cx - wm.width / 2), int(y + (e["h"] - wm.height) / 2)))
            boxes.append((cx - wm.width / 2, y, cx + wm.width / 2, y + e["h"]))
        else:
            c = card_image(s["card"]["game"], s["card"]["text"], e["w"], e["size"])
            img.alpha_composite(c, (int(cx - c.width / 2), int(y + (e["h"] - c.height) / 2)))
            boxes.append((cx - c.width / 2, y + (e["h"] - c.height) / 2, cx + c.width / 2, y + (e["h"] + c.height) / 2))
        y += e["h"] + gap
    problems = []
    for b in boxes:
        if b[0] < MARGIN - 8 or b[2] > g["w"] - MARGIN + 8 or b[1] < g["text_top"] - 2:
            problems.append(f"text outside the safe margin: {tuple(int(v) for v in b)}")
        for f in faces:
            h = f["head"]
            if b[0] < h[2] and b[2] > h[0] and b[1] < h[1] + (h[3] - h[1]) * 0.85 and b[3] > h[1] + 6:
                problems.append(f"text overlaps {f['who']}'s face")
        if kind == "story" and b[3] > g["cast_bottom"]:
            problems.append("text in the poll-sticker zone")
    for i, f in enumerate(faces):
        for o in faces[i + 1:]:
            a, b = f["head"], o["head"]
            ox = min(a[2], b[2]) - max(a[0], b[0])
            if ox > 0.12 * min(a[2] - a[0], b[2] - b[0]) and min(a[3], b[3]) > max(a[1], b[1]):
                problems.append(f"{f['who']}'s and {o['who']}'s faces overlap")
    if kind == "story":
        for f in faces:
            if f["head"][3] > g["cast_bottom"]:
                problems.append(f"{f['who']}'s head dips into the poll-sticker zone")
    img.convert("RGB").save(out_path)
    return problems


def wordmark(word, size):
    """Graffiti-ish FRIENDZY: jittered, tilted Electric Yellow Boogaloo letters with a thick outline."""
    from PIL import Image, ImageDraw
    f = boogaloo(size)
    rnd = random.Random(4)
    letters = []
    for ch in word:
        w = int(f.getlength(ch) + size * 0.4)
        im = Image.new("RGBA", (w, int(size * 1.5)), (0, 0, 0, 0))
        d = ImageDraw.Draw(im)
        sw = max(4, int(size * 0.07))
        d.text((w / 2 + size * 0.05, size * 0.78), ch, font=f, fill=hexrgb(OFFBLACK), anchor="mm", stroke_width=sw, stroke_fill=hexrgb(OFFBLACK))
        d.text((w / 2, size * 0.72), ch, font=f, fill=hexrgb(YELLOW), anchor="mm", stroke_width=sw, stroke_fill=hexrgb(OFFBLACK))
        letters.append((im.rotate(rnd.uniform(-9, 9), resample=Image.BICUBIC), f.getlength(ch), rnd.choice((-1, 1)) * size * 0.04))
    total = sum(adv for _, adv, _ in letters) * 0.94
    out = Image.new("RGBA", (int(total + size * 0.6), int(size * 1.6)), (0, 0, 0, 0))
    x = size * 0.3
    for im, adv, dy in letters:
        out.alpha_composite(im, (int(x + adv / 2 - im.width / 2), int((out.height - im.height) / 2 + dy)))
        x += adv * 0.94
    return out.crop(out.getbbox())


def contact_sheet(paths, kind, out):
    from PIL import Image, ImageDraw
    tw = 360
    th = int(tw * (1350 if kind == "carousel" else 1920) / 1080)
    cols = min(3, len(paths))
    rows = math.ceil(len(paths) / cols)
    g = 24
    sheet = Image.new("RGB", (cols * tw + (cols + 1) * g, rows * (th + 40) + g), hexrgb(OFFBLACK)[:3])
    d = ImageDraw.Draw(sheet)
    lf = nunito(24, 800)
    for i, p in enumerate(paths):
        im = Image.open(p).convert("RGB").resize((tw, th), Image.LANCZOS)
        x, y = g + (i % cols) * (tw + g), g + (i // cols) * (th + 40)
        sheet.paste(im, (x, y))
        if kind == "story":  # shade the poll-sticker zone + the IG header so it's easy to check
            ov = Image.new("RGBA", (tw, th), (0, 0, 0, 0))
            od = ImageDraw.Draw(ov)
            k = tw / 1080
            od.rectangle((0, int(1280 * k), tw, th), fill=(232, 25, 44, 70))
            od.rectangle((0, 0, tw, int(220 * k)), fill=(232, 25, 44, 70))
            sheet.paste(Image.alpha_composite(im.convert("RGBA"), ov).convert("RGB"), (x, y))
        d.text((x, y + th + 6), os.path.basename(p), font=lf, fill=hexrgb(CHALK)[:3])
    sheet.save(out)


def run_blender(plan_path):
    cmd = [BLENDER, "--background", "--python", os.path.abspath(__file__), "--", "--blender", plan_path]
    p = subprocess.run(cmd, capture_output=True, text=True)
    log = p.stdout + p.stderr
    if "Traceback (most recent call last)" in log or p.returncode != 0:
        print(log[-4000:])
        raise SystemExit("Blender failed (see the traceback above)")
    return log


def main(argv):
    import argparse
    ap = argparse.ArgumentParser(description="Instagram carousel / story stills starring Riot")
    ap.add_argument("slides")
    ap.add_argument("--name")
    ap.add_argument("--preview", type=int, help="render only slide N (1-based)")
    ap.add_argument("--out", help="output folder (default Blender/videos/carousels/<name>)")
    a = ap.parse_args(argv)
    spec = json.load(open(a.slides))
    kind = spec.get("kind", "carousel")
    if kind not in KINDS:
        raise SystemExit(f"kind must be one of {list(KINDS)}")
    name = a.name or spec.get("name") or os.path.splitext(os.path.basename(a.slides))[0]
    out = os.path.abspath(a.out or os.path.join(VIDEOS, name))
    os.makedirs(out, exist_ok=True)
    slides = list(spec["slides"])
    if kind == "carousel" and (not slides or not is_end(slides[-1])):
        slides.append(end_slide())
    if kind == "story" and len(slides) != 1:
        print("note: a story is one image per slide; rendering each as its own story")
    for s in slides:
        if is_end(s):
            s.setdefault("end", True)
            s.setdefault("background", "orange")
            s.setdefault("riot", {"pose": "wave", "expr": "hype", "costume": "hoodie"})
    slides = [norm_slide(s, i, kind) for i, s in enumerate(slides)]
    g = geom(kind)
    todo = [a.preview] if a.preview else list(range(1, len(slides) + 1))
    t0 = time.time()
    tmp = tempfile.mkdtemp(prefix="carousel_")
    plan = dict(kind=kind, report=os.path.join(tmp, "report.json"), slides=[])
    texts = {}
    for i in todo:
        s = slides[i - 1]
        els, cast_top, total = plan_text(s, g, kind)
        texts[i] = (els, total)
        plan["slides"].append(dict(index=i, background=s["background"], cast_top=cast_top,
                                   cast=place_cast(s, g, cast_top, kind), raw=os.path.join(tmp, f"raw_{i:02d}.png")))
    json.dump(plan, open(os.path.join(tmp, "plan.json"), "w"), indent=1)
    print(f"Blender: drawing {len(todo)} slide(s)...", flush=True)
    log = run_blender(os.path.join(tmp, "plan.json"))
    stamps = [float(l.split(" at ")[1]) for l in log.splitlines() if l.startswith("CAROUSEL rendered")]
    if len(stamps) > 1:
        print("  per slide: " + ", ".join(f"{b - a:.1f}s" for a, b in zip(stamps, stamps[1:])))
    t1 = time.time()
    report = {r["index"]: r for r in json.load(open(plan["report"]))}
    paths, qa = [], []
    for ps in plan["slides"]:
        i = ps["index"]
        path = os.path.join(out, f"{i:02d}.png")
        els, total = texts[i]
        probs = compose(slides[i - 1], g, kind, ps["raw"], report[i]["faces"], els, total, path)
        paths.append(path)
        qa.append(dict(slide=i, file=path, faces=report[i]["faces"], problems=probs))
        for p in probs:
            print(f"  WARNING slide {i}: {p}")
    if not a.preview:
        contact_sheet(paths, kind, os.path.join(out, "contact.png"))
    json.dump(dict(kind=kind, name=name, slides=qa), open(os.path.join(out, "layout.json"), "w"), indent=1)
    print(f"done: {len(paths)} slide(s) in {time.time() - t0:.1f}s (Blender {t1 - t0:.1f}s) -> {out}")
    if any(q["problems"] for q in qa):
        raise SystemExit(1)


if __name__ == "__main__":
    if IN_BLENDER:
        args = sys.argv[sys.argv.index("--") + 1:]
        blender_main(args[args.index("--blender") + 1])
    else:
        main(sys.argv[1:])
