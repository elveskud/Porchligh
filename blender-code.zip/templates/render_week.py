# Render a whole approved week in one go.
#   python3 Blender/templates/render_week.py marketing/weekly/<monday>_renders.json [--force] [--dry-run]
# Runs the jobs in order (make.py videos incl. A/B hooks and formats, episodes, carousels, story images,
# thumbnails/covers, stickers), skips anything already rendered with QA passed (unless --force), keeps going after
# a failure, prints a summary table and writes it next to the JSON as <monday>_renders.txt.
# --dry-run lists the jobs, what would be skipped and the estimated render time, without rendering anything.
# The JSON shape is in Blender/README.md (section "Render the week").
import argparse, json, os, re, shutil, subprocess, sys, time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, ".."))
REPO = os.path.normpath(os.path.join(ROOT, ".."))
VIDEOS = os.path.join(ROOT, "videos")
# rough render seconds per job (this Mac, 4 jobs for episodes); voices for new lines add ~60 s
EST = {"video": 90, "alias": 180, "episode_vertical": 300, "episode_horizontal": 480, "carousel": 30, "story": 10,
       "thumbnail": 15, "cover": 15, "sticker": 25}


def path(p):
    return p if os.path.isabs(p) else os.path.normpath(os.path.join(REPO, p))


def video_name(job):
    """The folder make.py will use for this job (it must be stable so reruns can skip finished work)."""
    if job.get("name"):
        return job["name"]
    if job["type"] == "episode":
        sp = path(job["script"])
        n = os.path.basename(os.path.dirname(sp)).replace("-", "_") + "_" + os.path.splitext(os.path.basename(sp))[0]
        return n + ("_h" if job.get("format") == "horizontal" else "")
    raise SystemExit(f"render_week: video job {job.get('id')} needs a 'name' (so a rerun can find and skip it)")


def qa_of(name):
    """(passed, length, fails) from Blender/videos/<name>/qa.txt, or None if it isn't rendered yet."""
    qa = os.path.join(VIDEOS, name, "qa.txt")
    mp4 = os.path.join(VIDEOS, name, f"{name}.mp4")
    if not (os.path.exists(qa) and os.path.exists(mp4)):
        return None
    txt = open(qa).read()
    m = re.search(r"duration [^:]*: ([\d.]+)s", txt)
    fails = re.findall(r"\[FAIL\] ([^:]+)", txt)
    return (not fails, f"{m.group(1)} s" if m else "?", fails)


def plan(job):
    """(label, output path, done?, est seconds, command) for one job."""
    t = job["type"]
    if t in ("video", "episode"):
        name = video_name(job)
        out = os.path.join(VIDEOS, name, f"{name}.mp4")
        q = qa_of(name)
        cmd = [sys.executable, os.path.join(HERE, "make.py"), "episode" if t == "episode" else job["template"], "--name", name]
        for k in ("prompt", "target", "hook", "confess", "format"):
            if job.get(k):
                cmd += [f"--{k}", job[k]]
        if t == "episode":
            cmd += ["--script", path(job["script"]), "--jobs", str(job.get("jobs", 4))]
        for flag in ("reuse_voices",):  # thumbnail/cover run as their own follow-up jobs (see expand)
            if job.get(flag):
                cmd.append("--" + flag.replace("_", "-"))
        est = EST["episode_" + job.get("format", "vertical")] if t == "episode" else EST["alias" if job.get("template") == "alias" else "video"]
        if not (job.get("reuse_voices") or job.get("voices_from")):
            est += 60
        label = job.get("id") or name
        return label, out, bool(q and q[0]), est, cmd
    if t in ("carousel", "story"):
        spec = json.load(open(path(job["json"])))
        out_dir = os.path.join(VIDEOS, "carousels", job.get("name") or spec["name"])
        lay = os.path.join(out_dir, "layout.json")
        done = os.path.exists(os.path.join(out_dir, "contact.png")) and os.path.exists(lay) and \
            not json.load(open(lay)).get("problems")
        cmd = [sys.executable, os.path.join(HERE, "carousel.py"), path(job["json"])] + (["--name", job["name"]] if job.get("name") else [])
        n = max(1, len(spec.get("slides", [])) + (1 if spec.get("kind") == "carousel" else 0))
        return job.get("id") or spec["name"], os.path.join(out_dir, "contact.png"), done, EST[t] * (n if t == "story" else n / 6), cmd
    if t in ("thumbnail", "cover"):
        name = job["video"]
        out = os.path.join(VIDEOS, name, f"{name}_{'cover' if t == 'cover' else 'thumb'}.png")
        cmd = [sys.executable, os.path.join(HERE, "thumbnail.py"), os.path.join(VIDEOS, name)] + (["--cover"] if t == "cover" else []) + \
              (["--text", job["text"]] if job.get("text") else [])
        return job.get("id") or f"{t}:{name}", out, os.path.exists(out), EST[t], cmd
    if t == "sticker":
        name = job.get("name") or f"riot_{job['expr']}" + (f"_{job['costume']}" if job.get("costume") else "")
        out = os.path.join(VIDEOS, "stickers", name, f"{name}.gif")
        cmd = [sys.executable, os.path.join(HERE, "sticker.py"), job["expr"], "--name", name] + \
              (["--costume", job["costume"]] if job.get("costume") else [])
        return job.get("id") or name, out, os.path.exists(out), EST["sticker"], cmd
    raise SystemExit(f"render_week: unknown job type {t!r} (video, episode, carousel, story, thumbnail, cover, sticker)")


def expand(jobs):
    """A video's "thumbnail"/"cover" (and every horizontal episode's thumbnail) become follow-up jobs, so they're
    made even when the video itself is skipped as already rendered."""
    out = []
    for j in jobs:
        out.append(j)
        if j["type"] in ("video", "episode"):
            wants_thumb = j.get("thumbnail") or (j["type"] == "episode" and j.get("format") == "horizontal")
            for t, want in (("thumbnail", wants_thumb), ("cover", j.get("cover"))):
                if want:
                    out.append({"id": f"{j.get('id') or video_name(j)} {t}", "type": t, "video": video_name(j),
                                **({"text": j["thumb_text"]} if j.get("thumb_text") else {})})
    return out


def fmt_table(rows):
    head = ("item", "file", "length", "QA", "render")
    w = [max(len(str(r[i])) for r in rows + [head]) for i in range(5)]
    line = lambda r: "  ".join(str(r[i]).ljust(w[i]) for i in range(5))
    return "\n".join([line(head), line(["-" * x for x in w])] + [line(r) for r in rows])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("jobs", help="marketing/weekly/<monday>_renders.json")
    ap.add_argument("--force", action="store_true", help="re-render jobs that already passed QA")
    ap.add_argument("--dry-run", action="store_true", help="list the jobs and estimated render time; render nothing")
    a = ap.parse_args()
    spec = json.load(open(path(a.jobs)))
    jobs = expand(spec["jobs"])
    plans = [(j, *plan(j)) for j in jobs]
    if a.dry_run:
        total = 0
        print(f"{len(jobs)} jobs in {a.jobs}" + (" (--force)" if a.force else ""))
        for j, label, out, done, est, cmd in plans:
            skip = done and not a.force
            total += 0 if skip else est
            state = ("SKIP (QA passed)" if j["type"] in ("video", "episode") else "SKIP (exists)") if skip else f"~{est / 60:.1f} min"
            print(f"  {state:18s} {j['type']:9s} {label}  ->  {os.path.relpath(out, REPO)}")
        print(f"estimated render time: ~{total / 60:.0f} min")
        return
    rows = []
    for j, label, out, done, est, cmd in plans:
        if done and not a.force:
            q = qa_of(video_name(j)) if j["type"] in ("video", "episode") else None
            rows.append((label, os.path.relpath(out, REPO), q[1] if q else "-", "PASS (skipped)", "-"))
            continue
        if j.get("voices_from"):  # A/B: hook B reuses hook A's voices (only the caption differs)
            src = os.path.join(VIDEOS, j["voices_from"], "vo")
            dst = os.path.join(VIDEOS, video_name(j), "vo")
            if os.path.isdir(src) and not os.path.isdir(dst):
                shutil.copytree(src, dst)
            if "--reuse-voices" not in cmd:
                cmd.append("--reuse-voices")
        print(f"\n=== {label}: {' '.join(os.path.basename(c) if i < 2 else c for i, c in enumerate(cmd))}", flush=True)
        t0 = time.time()
        p = subprocess.run(cmd, capture_output=True, text=True, cwd=HERE)
        dt = time.time() - t0
        if j["type"] in ("video", "episode"):
            q = qa_of(video_name(j))
            ok = p.returncode == 0 and q and q[0]
            qa = "PASS" if ok else ("FAIL: " + ", ".join(q[2]) if q and q[2] else "FAILED (see log)")
            length = q[1] if q else "-"
        else:
            ok = p.returncode == 0 and os.path.exists(out)
            qa, length = ("PASS" if ok else "FAILED (see log)"), "-"
        if not ok:
            print((p.stdout + p.stderr)[-1500:])
        rows.append((label, os.path.relpath(out, REPO), length, qa, f"{dt:.0f} s"))
    table = fmt_table(rows)
    print("\n" + table)
    txt = re.sub(r"\.json$", "", path(a.jobs)) + ".txt"
    open(txt, "w").write(f"Renders for {os.path.basename(a.jobs)} ({time.strftime('%Y-%m-%d %H:%M')})\n\n{table}\n")
    print(f"\n-> {txt}")
    sys.exit(0 if all(r[3].startswith("PASS") for r in rows) else 1)


if __name__ == "__main__":
    main()
