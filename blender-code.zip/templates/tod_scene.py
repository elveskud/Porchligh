# Blender scene for "Truth or Dare" in Game Night HQ (day), Riot in his dare costume (tod_script.py).
#   Blender --background --python tod_scene.py -- <video dir> [FRAMES=10,200 for stills]
import os, sys, json
HERE_T = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE_T, "../characters"))
sys.path.insert(0, HERE_T)
from toon import *
import cast, props, locations, motion, layout
import tod_script as S

OUT = sys.argv[sys.argv.index("--") + 1]
cfg = json.load(open(os.path.join(OUT, "config.json")))
C = json.load(open(os.path.join(OUT, "cues.json")))
END = C["END"]
vo = lambda i: os.path.join(OUT, "vo", f"{i}.wav")
text_of = {i: t for i, _, t in S.lines(cfg)}
beats = lambda i, at: [C[at] + e for e in motion.phrase_ends(vo(i))]
DARE = S.DARES[S.prompt(cfg)]
TGT = S.target(cfg)

F = layout.from_cfg(cfg)
V = F.vertical  # the 9:16 numbers below are the original ones; 16:9 has its own framing and HUD spots
TS = F.text_scale
sc = reset()
F.setup(sc, OFFBLACK)
sc.frame_start, sc.frame_end = 0, END

# ---------- set & cast: the plate line-up, Riot on seat 2 ----------
loc = locations.living_room("day")
if not V:
    locations.widen(loc)
tint = locations.mood_tint(loc, DARE["tint"])
seat = {"bash": 0, "pip": 1, "riot": 2, "rocco": 3}
ch = {"bash": cast.bear(), "pip": cast.bunny(), "riot": cast.riot("dare"), "rocco": cast.raccoon()}
for k, c in ch.items():
    loc.seat(c, seat[k])
set_visible(ch["pip"].extras["sweat"], False)
A = {k: motion.Anim(c) for k, c in ch.items()}
X = {k: loc.seats[seat[k]][0] for k in ch}
r, b, p, k_ = A["riot"], A["bash"], A["pip"], A["rocco"]
side_to = lambda who, at: 1.0 if X[at] > X[who] else -1.0


def munch(a, f, n=2):
    """Rocco: chips up to the mouth and back, n times (left paw holds the bag)."""
    keys = [(f, 8, "linear")]
    for i in range(n):
        keys += [(f + 6 + i * 10, -128, "back"), (f + 11 + i * 10, -95, "smooth")]
    keys.append((f + 12 + n * 10, 8, "smooth"))
    a.add(lambda fr: None if not (f <= fr <= keys[-1][0]) else
          {"arm-1": -8, "hand-1": "fist", "elbow-1": motion.curve(fr, keys)})
    return keys[-1][0]


for a in A.values():
    a.expr(0, "happy")
r.expr(0, "cocky")

# 1. hook: Riot's paw already hovers over the phone, then jabs DARE
tp = C["tap"]
r.add(lambda fr: None if fr > tp + 16 else {
    "arm-1": motion.curve(fr, [(0, 118, "linear"), (tp - 5, 112, "smooth"), (tp - 2, 168, "back"), (tp + 6, 168, "linear"), (tp + 16, 10, "smooth")])
    + (4 * math.sin(fr * 0.5) if fr < tp - 5 else 0),                       # fidgety hover: he can't wait
    "elbow-1": motion.curve(fr, [(0, 40, "linear"), (tp - 5, 46, "smooth"), (tp - 2, 4, "back"), (tp + 6, 4, "linear"), (tp + 16, 8, "smooth")]),
    "hand-1": "point" if tp - 4 <= fr <= tp + 10 else ("open" if fr < tp - 4 else "paw"),
    "y": motion.curve(fr, [(tp - 4, 0, "linear"), (tp - 1, 0.25, "out"), (tp + 4, 0, "in")]),
})
r.look(0, -0.3, 6)
motion.talk(r, C["dare"], vo("riot_dare"), text=text_of["riot_dare"])
for who in ("bash", "pip", "rocco"):
    A[who].look(2 + seat[who], side_to(who, "riot") * 0.6, 6)
p.expr(tp + 2, "nervous")
b.expr(tp + 2, "hype")
motion.hop(b, tp + 2, 0.35)
k_end = munch(k_, 6, 2)

# 2. the card: Riot reads it, the friends lean in
r.look(C["read"] - 6, 0.0, 6)
motion.talk(r, C["read"], vo("riot_read"), text=text_of["riot_read"])
motion.present(r, C["read"] + 4, hold=C["read_end"] - C["read"] - 10, side=-1)
for who in ("bash", "pip"):
    A[who].look(C["read"] - 4, side_to(who, "riot"), 6)
    motion.listen(A[who], C["read"] + 2, C["read_end"] + 2, side_to(who, "riot"), beats("riot_read", "read"))
k_.look(k_end + 2, -0.7, 6)
munch(k_, C["read"] + 30, 2)

# 3. the dare: Riot rises, claws up, the room goes red
pf, pe = C["perform"], C["perform_end"]
r.expr(pf - 2, "cocky")
r.look(pf - 4, 0.0, 4)
motion.talk(r, pf, vo("riot_perform"), energy=1.3, text=text_of["riot_perform"])
r.add(lambda fr: None if not (pf - 6 <= fr <= C["snap"] + 10) else {
    "y": motion.curve(fr, [(pf - 6, 0, "linear"), (pf - 3, -0.12, "out"), (pf + 3, 1.1, "back"), (pe, 1.0, "linear"), (C["snap"] + 8, 0, "smooth")]),
    "sq": 1 + 0.04 * abs(math.sin(fr * 0.9)) * motion.envelope(fr, pf, pe, 4),        # shoulders shake with every "HA"
    "head_rot": 7 * math.sin(fr * 0.45) * motion.envelope(fr, pf, pe, 4),
    "arm1": motion.curve(fr, [(pf - 6, 10, "linear"), (pf + 3, 128, "back"), (pe, 136, "linear"), (C["snap"] + 8, 10, "smooth")]),
    "arm-1": motion.curve(fr, [(pf - 5, 10, "linear"), (pf + 4, 128, "back"), (pe, 136, "linear"), (C["snap"] + 8, 10, "smooth")]),
    "elbow1": 38 * motion.envelope(fr, pf - 2, C["snap"] + 6, 5) + 8,
    "elbow-1": 38 * motion.envelope(fr, pf - 1, C["snap"] + 6, 5) + 8,
    "hand1": "open" if pf <= fr <= C["snap"] + 4 else "paw", "hand-1": "open" if pf + 1 <= fr <= C["snap"] + 4 else "paw",
})
motion.take(b, pf + 3, "shocked", 1.0)
b.look(pf + 2, 1.0, 4)
motion.nervous(p, pf, C["snap"] + 14)
p.look(C["snap"] + 14, 1.0, 5)
if TGT != "rocco":
    k_.look(pf, -1.0, 6)
    munch(k_, pf + 4, 2)                    # unbothered
# lights back on: everyone freezes on Riot, the target delivers the deadpan line
r.expr(C["snap"], "hype")
r.look(C["snap"] + 2, side_to("riot", TGT) * 0.8, 5)
t = A[TGT]
t.expr(C["react"] - 6, "side_eye_l" if X["riot"] < X[TGT] else "side_eye_r")
t.look(C["react"] - 8, side_to(TGT, "riot") * 0.5, 6)
if TGT == "rocco":
    munch(k_, C["react"] - 30, 1)
motion.talk(t, C["react"], vo("target_react"), text=text_of["target_react"])
for who in ("bash", "pip", "rocco"):
    if who != TGT:
        A[who].look(C["react"] - 4, side_to(who, TGT), 5)
        A[who].expr(C["react"] - 2, "suspicious" if who == "bash" else "shocked")
r.expr(C["react"] + 6, "shocked")

# 4. everyone laughs, Riot first
for who, off in (("riot", 0), ("bash", 3), ("pip", 6), ("rocco", 9)):
    motion.laugh(A[who], C["laugh"] + off, C["end"] - 2)
    A[who].look(C["laugh"] + off + 4, 0.0, 6)
for a in A.values():
    a.bake(0, END)

# ---------- camera ----------
EYE = 8.4  # seated eye line (world y)
if V:
    frame_ = lambda x, o, px=1000: (x, EYE - (0.5 - px / 1920) * o, o)  # eye line `px` down a 1920 frame
    low = frame_(0.6, 21.0, 1300)       # the cast sits low so the app screen and the card fit above their heads
    riot_one = frame_(X["riot"] - 0.1, 16.0, 1080)  # room for his ears when he stands
    two = frame_((X["riot"] + X[TGT]) / 2 - (0.3 if TGT == "rocco" else 0), 15.5 if TGT != "bash" else 19.0, 1000)
    wide = loc.cam
else:  # 16:9: the screens sit in the band above the heads, close-ups never cut a neighbour
    low = F.eye_framing(loc.cam_h[0], EYE, 13.5, 0.66)  # heads a little lower: the app screens fill the band above
    riot_one = F.clean_close(loc, seat["riot"], 8.5, EYE, 0.5)  # room for his ears when he stands
    two = F.clean_span(loc, [seat["riot"], seat[TGT]], EYE, 0.46)
    wide = loc.cam_h
cam = F.camera(sc, *wide)
CA = motion.CamAnim(cam, wide, loc.parallax)
CA.keys = [(-999, low, "linear")]
CA.intro()
CA.shake(tp, 8, 0.3)
CA.push(C["read_end"] - 2, pf - 1, riot_one, "out")      # lands before the laugh starts
CA.shake(pf + 2, 12, 0.35)
CA.push(C["snap"], C["react"] - 1, two, "out")             # still for the punchline
CA.cut(C["laugh"], wide)
EX = 100.0
CA.cut(C["end"], (EX, 9.0, 22.0))

# ---------- on-screen graphics: a camera-attached layer built at ortho 22 (x +-6.2, y +-11) ----------
hud = empty("hud", cam, (0, 0), -8)
CA.hud(hud)
hy = lambda px: (0.5 - px / 1920) * 22.0
def on_hud(o, xy, s=1.0):
    """Pin a prop to the HUD through a holder empty, so its own pop/flip keys stay 0..1 and the holder sets the size."""
    holder = empty(o.name + "_at", hud, xy, o.location.z)
    holder.scale = (s, s, 1)
    o.parent = holder
    o.location = (0, 0, 0)
    return o

hook = on_hud(props.caption_box("hook", S.hook(cfg), (0, 0), 1.0, w=10.0, size=0.92), (-0.4, hy(360)) if V else (-10.4, 7.6), 1.0 if V else TS)
set_visible(hook, False, 0)
motion.pop_in(hook, 1, 6, 1.1, 2)
motion.pop_out(hook, C["mystery"] - 2, 5)

choice = on_hud(props.td_choice("choice", "Riot", (0, 0), 0.4, w=7.6, h=8.0), (-0.4, hy(800)) if V else (19.55 - 0.9 - 7.6 * 1.15 / 2, 11.0 - 0.9 - 8.0 * 1.15 / 2), 0.8 if V else 1.15)  # 16:9: top-right, 0.9 margin
set_visible(choice, False, 0)
motion.pop_in(choice, C["choice_in"], 7, 1.12, 4)
dare_btn = bpy.data.objects["choice_dare"]
for fr, v in ((tp - 1, 1.0), (tp + 1, 0.88), (tp + 4, 1.1), (tp + 8, 1.0)):  # pressed, then bounces back
    dare_btn.scale = (v, v, 1)
    dare_btn.keyframe_insert("scale", frame=fr)
flash = bpy.data.objects[choice["flash"]]
set_visible(flash, False, 0)
set_visible(flash, False, C["choice_in"])  # pop_in showed every child
set_visible(flash, True, tp)
set_visible(flash, False, tp + 4)
motion.pop_out(choice, C["mystery"] - 1, 5)

CARD_XY, CARD_S = ((-0.3, hy(620)), 0.82) if V else ((19.55 - 0.9 - 8.4 * 1.4 / 2, 11.0 - 0.9 - 1.3 - 6.6 * 1.4 / 2), 1.4)  # 1.3: the Riot sticker pokes above the card
myst = on_hud(props.mystery_card("myst", (0, 0), 0.5), CARD_XY, CARD_S)
set_visible(myst, False, 0)
motion.pop_in(myst, C["mystery"], 6, 1.1, 3)
set_visible(myst, False, C["flip"])
card = on_hud(props.td_card("card", "dare", S.prompt(cfg), (0, 0), 0.6), CARD_XY, CARD_S)
set_visible(card, False, 0)
motion.card_flip_in(card, C["flip"])
motion.pop_out(card, pf - 8, 5)
# the room goes red for the dare
set_visible(tint, False, 0)
set_visible(tint, True, pf - 2)
set_visible(tint, False, C["snap"])

cf = props.confetti("cf", (0.6, 15.0) if V else (loc.cam_h[0], 15.0), 23, spread=4.5 if V else 8.0)  # above the heads, so it rains down instead of covering faces
set_visible(cf, False, 0)
motion.burst(cf, C["laugh"] + 2, 30)

if V:
    CA.hud(props.word_captions("cap_dare", cam, motion.word_times(text_of["riot_dare"], vo("riot_dare")), C["dare"], y_px=1440))
    for i, at in (("riot_perform", pf), ("target_react", C["react"])):
        CA.hud(props.word_captions(i, cam, motion.word_times(text_of[i], vo(i)), at, y_px=1340))
else:
    for i, at in (("cap_dare", C["dare"]), ("riot_perform", pf), ("target_react", C["react"])):
        line = "riot_dare" if i == "cap_dare" else i
        CA.hud(props.word_captions(i, cam, motion.word_times(text_of[line], vo(line)), at, fmt=F.fmt, y_frac=0.8,
                                   max_chars=22, size=1.45 * TS))
CA.bake(0, END)

# ---------- end card: dare Riot waves, then a thumbs up ----------
props.end_card("end", f"{S.TITLE} · free on Friendzy", (EX, 9.0), -5, **({} if V else {"fmt": F.fmt}))
er = cast.riot("dare")
er.root.location = (EX, -12.5, 2) if V else (EX + 10.5, -15.5, 2)
er.root.scale = (1.15, 1.15, 1) if V else (1.75, 1.75, 1)
ea = motion.Anim(er)
ea.expr(0, "hype")
motion.talk(ea, C["end_vo"], vo("riot_end"), text=text_of["riot_end"])
mid = (C["end"] + END) // 2
motion.wave(ea, C["end"] + 4, mid - 2, side=-1)
motion.thumbs_up(ea, mid, hold=max(8, END - mid - 10))
ea.add(lambda fr: {"y": 7.0 * motion.curve(fr, [(C["end"], 0, "linear"), (C["end"] + 6, 1.0, "back")]) / 1.15})
ea.bake(C["end"] - 1, END)
for i in range(8):
    l = bpy.data.objects[f"end_l{i}"]
    set_visible(l, False, 0)
    motion.pop_in(l, C["end"] + 1 + i * 2, 5, 1.3, 8)
sub = bpy.data.objects["end_sub"]
set_visible(sub, False, 0)
motion.pop_in(sub, C["end"] + 14, 6)

bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, "scene.blend"))
frames = os.environ.get("FRAMES")
if frames:
    for fr in map(int, frames.split(",")):
        still(sc, os.path.join(OUT, "stills", f"s_{fr:04d}.png"), fr)
else:
    sc.render.filepath = os.path.join(OUT, "frames", "f_")
    bpy.ops.render.render(animation=True)
