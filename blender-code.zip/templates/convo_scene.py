# Blender scene for the conversation test (convo_script.py) in Game Night HQ (day).
#   Blender --background --python convo_scene.py -- <video dir>
import os, sys, json
HERE_T = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE_T, "../characters"))
sys.path.insert(0, HERE_T)
from toon import *
import cast, props, locations, motion
import convo_script as S

OUT = sys.argv[sys.argv.index("--") + 1]
cfg = json.load(open(os.path.join(OUT, "config.json")))
C = json.load(open(os.path.join(OUT, "cues.json")))
END = C["END"]
vo = lambda i: os.path.join(OUT, "vo", f"{i}.wav")
text_of = {i: t for i, _, t in S.lines(cfg)}

sc = reset()
setup_render(sc, 1080, 1920, bg=OFFBLACK)
sc.frame_start, sc.frame_end = 0, END

# ---------- set & cast ----------
loc = locations.living_room("day")
seat = {"bash": 0, "pip": 1, "riot": 2, "rocco": 3}
ch = {"bash": cast.bear(), "pip": cast.bunny(), "riot": cast.riot(), "rocco": cast.raccoon()}
for k, c in ch.items():
    loc.seat(c, seat[k])
set_visible(ch["pip"].extras["sweat"], False)
A = {k: motion.Anim(c) for k, c in ch.items()}
X = {k: loc.seats[seat[k]][0] for k in ch}
r, b, p, k_ = A["riot"], A["bash"], A["pip"], A["rocco"]


def listen(speaker, at):
    """Everyone else turns to the speaker (a little less if they're right next to each other)."""
    for who, a in A.items():
        if who != speaker:
            d = X[speaker] - X[who]
            a.look(at, (1.0 if d > 0 else -1.0) * (0.75 if abs(d) < 4 else 1.0), 6)


for i, who, text, _ in S.SCRIPT:
    motion.talk(A[who], C[i], vo(i), text=text)
    listen(who, C[i] - 4)
    if i in ("l4_bash", "l5_rocco"):  # Pip is being yelled at / Bash is being called out: no agreeable nods
        continue
    beats = [C[i] + e for e in motion.phrase_ends(vo(i))]
    for w2, a in A.items():
        if w2 != who:
            motion.listen(a, C[i] + 4, C[i + "_end"] + 4, 1.0 if X[who] > X[w2] else -1.0, beats)

# 1. Riot kicks it off: wave + hop, looking around the couch
r.expr(0, "hype")
motion.wave(r, C["l1_riot"] - 6, C["l1_riot"] + 34, side=-1)
motion.hop(r, C["l1_riot"] + 8, 0.5)
r.look(C["l1_riot"] + 2, -0.8, 6)
r.look(C["l1_riot"] + 22, 0.5, 6)
for who in ("bash", "pip", "rocco"):
    A[who].expr(0, "happy")
# 2. Bash: thumbs up, cocky
motion.thumbs_up(b, C["l2_bash"] - 2, hold=36)
b.expr(C["l2_bash"] + 10, "hype")
r.look(C["l2_bash"] - 4, -1.0, 6)
# 3. Pip: nervous shrug
motion.shrug(p, C["l3_pip"] + 2, hold=30)
p.expr(C["l3_pip"] + 4, "nervous")
# 4. Bash yells and points at Pip; Pip flinches and shivers
motion.yell(b, C["l4_bash"] - 3, C["l4_bash_end"] + 8, side=1)
motion.take(p, C["l4_bash"] + 1, "shocked", 0.5)
motion.nervous(p, C["l4_bash"] + 10, C["l5_rocco_end"] + 4)
# 5. Rocco munches, then the deadpan line
k_.add(lambda fr: None if not (C["l5_rocco"] - 26 <= fr <= C["l5_rocco"] + 2) else {
    "arm-1": -8, "hand-1": "fist",  # chips up to the mouth, across the chest: two munches
    "elbow-1": motion.curve(fr, [(C["l5_rocco"] - 26, 8, "linear"), (C["l5_rocco"] - 20, -128, "back"),
                                 (C["l5_rocco"] - 15, -95, "smooth"), (C["l5_rocco"] - 10, -128, "back"),
                                 (C["l5_rocco"] + 2, 8, "smooth")])})
k_.expr(C["l5_rocco"] - 2, "side_eye_l")
# laugh beat: Riot, Pip and Rocco crack up, Bash facepalms
motion.laugh(r, C["laugh"], C["l6_riot"] - 2)
motion.laugh(p, C["laugh"] + 5, C["l6_riot"] - 4)
motion.laugh(k_, C["laugh"] + 9, C["l6_riot"] - 4)
motion.facepalm(b, C["laugh"] + 2, hold=34)
# 6. Riot presents the dare card; Pip's shocked take, Bash cheers, Rocco hops
r.look(C["l6_riot"], -0.6, 6)
motion.present(r, C["l6_riot"] + 12, hold=40)
motion.take(p, C["l6_riot_end"], "shocked", 1.0)
motion.cheer(b, C["l6_riot_end"] + 4, hold=14)
motion.hop(k_, C["l6_riot_end"] + 6)
k_.expr(C["l6_riot_end"] + 6, "hype")
for a in A.values():
    a.bake(0, END)

# ---------- props & graphics ----------
hook = props.caption_box("hook", S.hook(cfg), (0.6, 17.35), 21, w=11.6, size=1.0)
set_visible(hook, False, 0)
motion.pop_in(hook, 1, 6, 1.1, 2)
motion.pop_out(hook, C["l2_bash"] - 6, 5)
card = props.prompt_card("card", "dare", S.DARE, (0.6, 15.2), 20, w=9.6, size=0.85)
set_visible(card, False, 0)
motion.card_flip_in(card, C["l6_riot"] + 16)
motion.pop_out(card, C["reaction_end"] - 4, 5)
sp = props.emote("sp", "sparkle", (4.9, 17.8), 21, 0.9)
set_visible(sp, False, 0)
motion.pop_in(sp, C["l6_riot"] + 22, 6)
motion.float_up(sp, C["l6_riot"] + 28, C["l6_riot"] + 60, 0.8)
sc.frame_set(C["l4_bash"])
bh = ch["bash"].extras["head"].matrix_world.translation.copy()
ang = props.emote("ang", "anger", (bh.x + 1.4, bh.y + 3.2), 21, 0.9)
set_visible(ang, False, 0)
motion.pop_in(ang, C["l4_bash"] + 2, 5)
motion.pop_out(ang, C["l4_bash_end"] + 8, 4)
cf = props.confetti("cf", (0.6, 14.5), 23, spread=4.5)  # above the heads, so it rains down instead of covering faces
set_visible(cf, False, 0)
motion.burst(cf, C["l6_riot_end"] + 4, 30)

# ---------- camera: drift toward whoever is talking, punch in on the yell ----------
cam = camera(sc, *loc.cam)
CA = motion.CamAnim(cam, loc.cam, loc.parallax)
CA.intro()                                       # moving from frame 0
wide = (0.2, 9.4, 25.5)
prev_end = 14  # the first move starts after the intro settles
for i, who, _, _ in S.SCRIPT:
    # every move lands before the line starts, then the camera holds still while they talk
    f0 = max(C[i] - 12, prev_end - 2, 0)
    f1 = max(C[i] - 1, f0 + 4)
    if i == "l4_bash":
        CA.push(f0, f1, ((X["bash"] + X["pip"]) / 2 + 0.6, 8.6, 15.0), "out")
        CA.shake(C[i] + 2, 12, 0.45)  # the yell's slam
    elif i == "l6_riot":
        CA.push(f0, f1, (0.6, 10.4, 23.0), "smooth")
    else:
        CA.push(f0, f1, (0.6 + (X[who] - 0.6) * 0.32, 9.0, 20.5), "smooth")
    prev_end = C[i + "_end"]
CA.push(C["laugh"], C["laugh"] + 10, wide, "out")
CA.shake(C["l6_riot_end"] + 4, 10, 0.25)
EX = 100.0
CA.cut(C["end"], (EX, 9.0, 22.0))
for i, who, text, _ in S.SCRIPT:
    CA.hud(props.word_captions(i, cam, motion.word_times(text, vo(i)), C[i], y_px=1320))
CA.bake(0, END)

# ---------- end card ----------
props.end_card("end", f"{S.TITLE} · free on Friendzy", (EX, 9.0), -5)
er = cast.riot()
er.root.location = (EX, -12.5, 2)
er.root.scale = (1.15, 1.15, 1)
ea = motion.Anim(er)
ea.expr(0, "hype")
motion.talk(ea, C["end_vo"], vo("riot_end"), text=text_of["riot_end"])
mid = (C["end"] + END) // 2  # wave, then a thumbs up: never one pose for the whole card
motion.wave(ea, C["end"] + 4, mid + 4, side=-1)
motion.thumbs_up(ea, mid, hold=END - mid - 10)
ea.add(lambda fr: {"y": 7.0 * motion.curve(fr, [(C["end"], 0, "linear"), (C["end"] + 8, 1.0, "back")]) / 1.15})
ea.bake(C["end"] - 1, END)
for i in range(8):
    l = bpy.data.objects[f"end_l{i}"]
    set_visible(l, False, 0)
    motion.pop_in(l, C["end"] + 2 + i * 2, 5, 1.3, 8)
sub = bpy.data.objects["end_sub"]
set_visible(sub, False, 0)
motion.pop_in(sub, C["end"] + 20, 6)

bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, "scene.blend"))
frames = os.environ.get("FRAMES")
if frames:
    for fr in map(int, frames.split(",")):
        still(sc, os.path.join(OUT, "stills", f"s_{fr:04d}.png"), fr)
else:
    sc.render.filepath = os.path.join(OUT, "frames", "f_")
    bpy.ops.render.render(animation=True)
