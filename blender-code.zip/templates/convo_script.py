# Test: a casual game-night conversation in Game Night HQ (day). Everyone talks, reacts and does things.
#   python3 make.py convo --name convo_test
FPS = 30
STANDALONE = True  # fixed script: no --prompt / --target needed
TITLE = "Game night"
HOOK = "when your friend group\ntries to pick a game"
DARE = "Do 10 push-ups right now."  # real dare from TruthOrDarePromptLibrary.swift

# (id, speaker, line, frames of pause before this line)
SCRIPT = [
    ("l1_riot", "riot", "Okay, who's ready for game night?", 16),
    ("l2_bash", "bash", "Born ready. I'm winning everything tonight.", 8),
    ("l3_pip", "pip", "Can we play something where nobody yells?", 10),
    ("l4_bash", "bash", "I do NOT yell!", 4),
    ("l5_rocco", "rocco", "Mm... you're yelling right now.", 10),
    ("l6_riot", "riot", "Then it's settled. Truth or Dare!", 50),  # gap = the laugh beat
]


def hook(cfg):
    return HOOK


def lines(cfg):
    return [(i, who, text) for i, who, text, _ in SCRIPT] + [("riot_end", "riot", f"{TITLE}. Free on Friendzy.")]


def timeline(cfg, dur):
    f = lambda s: int(round(s * FPS))
    s = lambda fr: round(fr / FPS, 3)
    c, t = {}, 0
    for i, who, text, gap in SCRIPT:
        t += gap
        c[i] = t
        t += f(dur[i])
        c[i + "_end"] = t
    c["laugh"] = c["l5_rocco_end"] + 4
    c["reaction_end"] = c["l6_riot_end"] + 36
    c["end"] = c["reaction_end"] + 4
    c["end_vo"] = c["end"] + 4   # short end card: Riot speaks almost at once
    c["END"] = c["end_vo"] + f(dur["riot_end"]) + 10
    c["voices"] = [[i, s(c[i])] for i, *_ in SCRIPT] + [["riot_end", s(c["end_vo"])]]
    c["sfx"] = [
        ["boing", s(c["l1_riot"] + 10), 0.3],                  # Riot's hop
        ["swish", s(c["l2_bash"] - 4), 0.25], ["pop", s(c["l2_bash"] + 6), 0.35],   # thumbs up
        ["slide_down", s(c["l3_pip"] + 4), 0.2],               # Pip's shrug
        ["whoosh", s(c["l4_bash"] - 3), 0.4], ["slam", s(c["l4_bash"] + 2), 0.3],   # the yell
        ["crunch", s(c["l5_rocco"] - 8), 0.5], ["crunch", s(c["l5_rocco"] - 2), 0.4],
        ["scratch", s(c["l5_rocco_end"]), 0.3],
        ["card_flip", s(c["l6_riot"] + 18), 0.6], ["sparkle", s(c["l6_riot"] + 20), 0.35],
        ["boing", s(c["l6_riot_end"] + 2), 0.35], ["slide_up", s(c["l6_riot_end"] + 6), 0.3],
        ["sting_fanfare", s(c["end"]), 0.45], ["popper", s(c["end"] + 2), 0.4],
    ]
    c["ambience"] = []
    c["music"] = ["hype", 0.0, 0.17, s(c["l4_bash"] - 2), s(c["l4_bash_end"] + 6)]  # music ducks out for the yell
    return c
