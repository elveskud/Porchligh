# YouTube thumbnails (1280x720) and vertical covers (1080x1920) for a made video, as single images (no re-render).
#   python3 thumbnail.py <video dir> [--cover] [--text "ONE TIME?!"]
# make.py calls it with --thumbnail / --cover (and always for a horizontal episode).
# What it draws: an expressive close-up of 1-2 characters on the video's set (headless Blender still), then Pillow adds
# 2-4 words of big Boogaloo text and a small FRIENDZY mark. The thumbnail keeps the bottom-right corner (YouTube's
# timestamp) empty; the cover keeps TikTok/Reels/Shorts' top, bottom and right-hand UI zones clear of faces and text.
# Episode JSON can steer it: "thumb_text": "ONE TIME?!", "thumb": {"location": "campfire",
#   "cast": [{"who": "riot", "expr": "shocked", "pose": "point"}, {"who": "rocco", "expr": "cocky"}]}
import argparse, json, os, subprocess, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, ".."))
BLENDER = "/Applications/Blender.app/Contents/MacOS/Blender"
FONT = os.path.normpath(os.path.join(ROOT, "../Friendzy/Resources/Fonts/Boogaloo-Regular.ttf"))
ORANGE, YELLOW, OFFBLACK, CHALK = "#FF6B00", "#FFD600", "#121212", "#F5F0E8"
LOCATIONS = ("campfire", "living_room_day", "living_room_night", "car", "game_show", "village_night", "party_room")
TEMPLATE_SET = {"nhie": "campfire", "hottakes": "campfire", "mlt": "car", "mafia": "village_night", "trivia": "game_show",
                "whosaid": "party_room", "spy": "party_room", "closecall": "party_room", "wordassoc": "party_room",
                "comeback": "party_room", "feature": "party_room"}


def plan(out, text=None):
    """What to draw: (location, [(who, costume, expr, pose)], words) from the video's config / episode JSON."""
    cfg = json.load(open(os.path.join(out, "config.json")))
    t = cfg.get("template", "")
    loc, cast_, words = TEMPLATE_SET.get(t, "living_room_day"), None, None
    if t == "episode" and cfg.get("script"):
        ep = json.load(open(cfg["script"]))
        words = ep.get("thumb_text") or ep.get("title")
        th = ep.get("thumb", {})
        loc = th.get("location") or ep["beats"][0].get("location", "campfire")
        if th.get("cast"):
            cast_ = [(c["who"], c.get("costume"), c.get("expr", "hype"), c.get("pose", "idle")) for c in th["cast"]]
        else:  # Riot, shocked, next to the first game's target, who looks guilty
            tgt = next((b["game"]["target"] for b in ep["beats"] if b.get("game", {}).get("target", "riot") != "riot"), "bash")
            cast_ = [(tgt, None, "nervous", "idle"), ("riot", None, "shocked", "point")]
    else:
        try:
            sys.path.insert(0, HERE)
            S = __import__(f"{t}_script")
            words = getattr(S, "TITLE", None)
        except Exception:
            words = None
        tgt = cfg.get("target") or "bash"
        costume = {"mafia": "mafia", "trivia": "host", "tod": "dare", "alias": "coach"}.get(t)
        cast_ = [(tgt, None, "nervous", "idle"), ("riot", costume, "shocked", "point")]
    words = (text or words or "FRIENDZY").upper()
    if loc == "living_room":
        loc = "living_room_day"
    return loc, cast_, words


BLENDER_SCRIPT = r'''
import sys, json
sys.path.insert(0, ARGS["chars"])
from toon import *
import cast, locations
w, h = ARGS["size"]
sc = reset()
setup_render(sc, w, h, bg=OFFBLACK)
name = ARGS["loc"]
L = (locations.living_room(name.split("_")[-1]) if name.startswith("living_room") else
     locations.plate(name) if name in locations.PLATE_SETS else getattr(locations, name)())
if w > h and name != "car":
    locations.widen(L)
for o in list(L.root.children):  # light beams and vignettes are made for moving shots; a still reads cleaner without
    if o.name.endswith(("_beam", "_beam-1", "_beam1", "_vig", "_vig_h")) or "beam" in o.name:
        set_visible(o, False)
import roster
make = {n: (lambda c, n=n: roster.make(n, c)) for n in roster.PROFILES}
chars = []
n = len(ARGS["cast"])
for k, (who, costume, expr, pose) in enumerate(ARGS["cast"]):
    c = make[who](costume)
    s = ARGS["scale"]
    c.root.scale = (s, s, 1)
    x = ARGS["xs"][n - 1][k]
    c.root.location = (x, 0, 14 + k * 3)
    c.expr(expr)
    c.pose(pose)
    if who == "pip":
        set_visible(c.extras["sweat"], expr == "nervous")
    if n == 2:  # face each other a little
        c.turn(0.45 if k == 0 else -0.45)
    chars.append(c)
bpy.context.view_layer.update()
hy = max(c.extras["head"].matrix_world.translation.y for c in chars)
ortho = ARGS["ortho"]
camera(sc, ARGS["cam_x"], hy - ARGS["head_at"] * ortho, ortho)
still(sc, ARGS["png"], 0)
'''


def render_bg(loc, cast_, size, png, vertical):
    args = {"chars": os.path.join(ROOT, "characters"), "loc": loc, "cast": cast_, "size": size, "png": png,
            # standing characters at 1.25x; two side by side (left one a little lower, it faces right)
            "scale": 1.25, "xs": [[0.0], [-3.0, 3.4]] if not vertical else [[0.0], [-2.4, 2.6]],
            # the cover pulls back and shifts the pair left: the right-hand column holds the app's buttons
            "ortho": 11.0 if not vertical else 24.0, "cam_x": 0.6 if not vertical else 1.9,
            # where the top head sits: thumbnail heads in the lower 60% (text on top), cover heads mid-frame
            "head_at": -0.1 if not vertical else -0.06}
    with tempfile.NamedTemporaryFile("w", suffix=".py", delete=False) as f:
        f.write("import json\nARGS = json.loads(" + repr(json.dumps(args)) + ")\n" + BLENDER_SCRIPT)
    p = subprocess.run([BLENDER, "--background", "--python", f.name], capture_output=True, text=True)
    os.remove(f.name)
    if "Traceback (most recent call last)" in p.stdout + p.stderr or not os.path.exists(png):
        sys.exit("thumbnail: Blender failed\n" + (p.stdout + p.stderr)[-1500:])


def big_text(draw, img_w, words, box, font_path, max_size, fill, stroke):
    """Words on at most two lines, as big as fits inside box (x0, y0, x1, y1). Returns the bottom y."""
    from PIL import ImageFont
    x0, y0, x1, y1 = box
    ws = words.split()
    lines_opts = [[words]] + ([[" ".join(ws[:k]), " ".join(ws[k:])] for k in range(1, len(ws))] if len(ws) > 1 else [])
    best = None
    for lines in lines_opts:
        size = max_size
        while size > 30:
            font = ImageFont.truetype(font_path, size)
            widths = [draw.textbbox((0, 0), l, font=font, stroke_width=size // 12)[2] for l in lines]
            height = len(lines) * size * 1.02
            if max(widths) <= x1 - x0 and height <= y1 - y0:
                break
            size -= 4
        if best is None or size > best[0]:
            best = (size, lines)
    size, lines = best
    font = ImageFont.truetype(font_path, size)
    y = y0
    for i, l in enumerate(lines):
        w = draw.textbbox((0, 0), l, font=font, stroke_width=size // 12)[2]
        x = x0 + (x1 - x0 - w) / 2
        draw.text((x, y), l, font=font, fill=fill if i == len(lines) - 1 else CHALK, stroke_width=size // 12, stroke_fill=stroke)
        y += size * 1.02
    return y


def mark(draw, xy, size):
    """Small FRIENDZY badge: orange rounded rect, yellow Boogaloo letters."""
    from PIL import ImageFont
    font = ImageFont.truetype(FONT, size)
    tw = draw.textbbox((0, 0), "FRIENDZY", font=font)[2]
    x, y = xy
    draw.rounded_rectangle((x, y, x + tw + size * 0.8, y + size * 1.35), radius=size // 3, fill=ORANGE, outline=OFFBLACK, width=max(3, size // 10))
    draw.text((x + size * 0.4, y + size * 0.12), "FRIENDZY", font=font, fill=YELLOW, stroke_width=max(2, size // 14), stroke_fill=OFFBLACK)


def make(out, cover=False, text=None):
    from PIL import Image, ImageDraw
    loc, cast_, words = plan(out, text)
    name = os.path.basename(os.path.normpath(out))
    if cover:
        size, dst = (1080, 1920), os.path.join(out, f"{name}_cover.png")
    else:
        size, dst = (1280, 720), os.path.join(out, f"{name}_thumb.png")
    tmp = dst.replace(".png", "_bg.png")
    render_bg(loc, cast_, size, tmp, cover)
    img = Image.open(tmp).convert("RGBA")
    os.remove(tmp)
    W, H = size
    shade = Image.new("RGBA", size, (0, 0, 0, 0))  # darken behind the words so they read on any set
    sd = ImageDraw.Draw(shade)
    band = (0, 0, W, int(H * (0.36 if not cover else 0.33)))
    for i in range(band[3]):
        a = int(150 * (1 - i / band[3]) ** 1.4)
        sd.line([(0, i), (W, i)], fill=(18, 18, 18, a))
    img = Image.alpha_composite(img, shade)
    d = ImageDraw.Draw(img)
    if cover:  # TikTok/Reels/Shorts: text below the top 220 px, mark above the bottom 440 px, both left of the buttons
        mark(d, (60, 240), 52)
        big_text(d, W, words, (60, 340, W - 160, 700), FONT, 190, YELLOW, OFFBLACK)
    else:  # YouTube: words across the top, mark top-right, the bottom-right timestamp corner stays empty
        big_text(d, W, words, (40, 26, W - 260, 250), FONT, 170, YELLOW, OFFBLACK)
        mark(d, (W - 230, 30), 40)
    img.convert("RGB").save(dst)
    print(dst)
    return dst


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("out", help="the video's folder in Blender/videos/")
    ap.add_argument("--cover", action="store_true", help="1080x1920 cover for Shorts/Reels/TikTok instead of a YouTube thumbnail")
    ap.add_argument("--text", help="2-4 words (default: the episode's thumb_text or title, else the game's name)")
    a = ap.parse_args()
    make(os.path.abspath(a.out), a.cover, a.text)
