# Blender scene for "Spy" in the Party Room (spy_script.py).
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import joke
from joke import *
import spy_script as S

J = joke.Joke(S, locations.party_room, {"bash": None, "pip": None, "riot": None, "rocco": None})
C, A = J.C, J.A
r, b, p, k_ = A["riot"], A["bash"], A["pip"], A["rocco"]
loc = J.loc
loc.extras["code"].data.body = "SPY"
for who in A:
    A[who].expr(0, "happy")
    J.hold_phone(who, 0, C["laugh"] - 2, side=1 if who == "rocco" else -1)
r.expr(C["spy_card"], "cocky")
r.look(C["spy_card"] + 2, 0.0, 4)
for who in ("bash", "pip", "rocco"):
    A[who].expr(C["cards_out"], "suspicious")
    A[who].look(C["cards_out"] + 2 + J.seat[who] * 3, (-0.5, 0.5)[J.seat[who] % 2], 5)
# Bash questions Riot; Riot bluffs, perfectly
b.expr(C["bash_ask"] - 2, "suspicious")
J.talk("bash", "bash_ask")
motion.point_at(b, C["bash_ask"] + 2, 1, hold=C["bash_ask_end"] - C["bash_ask"], expr="suspicious")
J.listen_all("bash", "bash_ask")
r.expr(C["riot_bluff"] - 4, "cocky")
J.talk("riot", "riot_bluff", energy=0.7)
motion.shrug(r, C["riot_bluff"] + 2, hold=12)
p.expr(C["pip_wow"] - 2, "hype")
J.talk("pip", "pip_wow")
# Bash accuses Pip (wrong, as always)
b.expr(C["bash_accuse"] - 2, "yelling")
J.talk("bash", "bash_accuse", energy=1.3)
motion.yell(b, C["bash_accuse"], C["bash_accuse_end"] + 6, 1)
motion.nervous(p, C["bash_accuse"] + 2, C["verdict"] + 6)
for who in ("riot", "rocco"):
    A[who].look(C["bash_accuse"] - 2, J.side(who, "bash"), 5)
motion.take(b, C["verdict"] + 8, "shocked", 0.8)
p.expr(C["verdict"] + 10, "happy")
# the real spy, to camera
r.look(C["riot_heh"] - 6, 0.0, 5)
r.expr(C["riot_heh"] - 4, "cocky")
J.shh("riot", C["riot_heh"] - 4, C["riot_heh_end"] + 4)
J.talk("riot", "riot_heh", energy=0.6)
J.laugh_all(C["laugh"], C["end"] - 2)
J.munch(C["pip_wow"], 2)
# camera + graphics: Bash's phone, then Riot's phone, as the app shows them
CA = J.camera("wide", band=True)
CA.push(C["spy_card"] - 4, C["spy_card"] + 6, J.frame("close:riot"), "out")
CA.cut(C["cards_out"] + 2, J.frame("wide"))
CA.push(C["riot_bluff"] - 8, C["riot_bluff"] - 1, J.frame("close:riot"), "out")
CA.cut(C["pip_wow"] - 1, J.frame("two:bash,pip"))
CA.cut(C["verdict"] - 1, J.frame("wide", band=True))
CA.push(C["verdict"] + 22, C["riot_heh"] - 1, J.frame("close:riot"), "out")
CA.cut(C["laugh"], J.frame("wide"))
J.hook(C["spy_card"] - 4)
J.card(props.reveal_card("locc", "THE LOCATION IS", S.LOCATION, (0, 0), 0.6, color=OFFBLACK, tint="#DDF3EC", big_size=1.5),
       C["loc_card"], C["spy_card"] - 2, vxy=(0.0, J.F.hud_y(0.42)), hxy=(10.6, 5.6), s=0.9, flip=False)
J.card(props.reveal_card("spyc", "You are the", "SPY", (0, 0), 0.6, color=RED, tint="#FFF6C7"),
       C["spy_card"], C["cards_out"], vxy=(0.0, J.F.hud_y(0.3)), hxy=(10.6, 5.6), s=0.9)
J.card(props.reveal_card("verd", "Pip was accused…", "Not the spy", (0, 0), 0.6, color=ORANGE, big_size=1.4),
       C["verdict"], C["riot_heh"] - 8, s=0.95, flip=False)
J.captions(["bash_ask", "riot_bluff", "pip_wow", "bash_accuse", "riot_heh"], y_px=1400)
J.confetti(C["laugh"] + 2)
J.finish(S.TITLE)
