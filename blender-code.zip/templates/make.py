# One command -> finished video.
#   python3 make.py nhie --prompt "Never have I ever ..." --target pip [--name nhie_pip_01] [--stills 20,200]
#   python3 make.py nhie --batch 5          (5 videos: best unused app prompts, rotating targets)
# Steps: voices (Chatterbox, cloned per character) -> timing from real line lengths -> generated soundtrack
# -> Blender render -> encode (with + without sound) -> QA report + contact sheet with safe zones.
# Output: Blender/videos/<name>/
import argparse, csv, importlib, json, os, re, shutil, subprocess, sys, time, types, wave

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.normpath(os.path.join(HERE, ".."))
VENV_PY = os.path.join(ROOT, "voices/.venv/bin/python")
SPEAK = os.path.join(ROOT, "voices/speak.py")
BLENDER = "/Applications/Blender.app/Contents/MacOS/Blender"
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(ROOT, "characters"))
import layout


def run(cmd, **kw):
    t = time.time()
    p = subprocess.run(cmd, capture_output=True, text=True, **kw)
    if p.returncode or (cmd[0] == BLENDER and "Traceback (most recent call last)" in p.stdout + p.stderr):  # Blender exits 0 on script errors
        sys.exit(f"FAILED: {' '.join(cmd[:4])}...\n{p.stdout[-2000:]}\n{p.stderr[-2000:]}")
    return p.stdout, time.time() - t


def wav_seconds(path):
    with wave.open(path) as w:
        return w.getnframes() / w.getframerate()


TRACK_COLS = ["video", "made", "template", "target", "hook", "prompt", "length_s", "posted", "platform",
              "views_24h", "likes", "shares", "comments", "avg_watch_pct", "notes", "hashtags"]


def track(row):
    """Add the video's row, or update it in place on a re-render (posting stats, notes and hashtags are kept).
    Rewrites the whole file with csv's CRLF line endings, like the original."""
    path = os.path.join(ROOT, "videos", "tracker.csv")
    rows, cols = [], TRACK_COLS
    if os.path.exists(path):
        with open(path, newline="") as f:
            r = csv.DictReader(f)
            cols = r.fieldnames + [c for c in TRACK_COLS if c not in r.fieldnames]  # keep any extra columns
            rows = list(r)
    mine = [x for x in rows if x["video"] == row["video"]]
    if mine:
        for k in ("made", "template", "target", "hook", "prompt", "length_s"):
            mine[0][k] = row.get(k, "")
        if row.get("notes") and not mine[0].get("notes"):
            mine[0]["notes"] = row["notes"]
        rows = [x for x in rows if x["video"] != row["video"] or x is mine[0]]  # also folds any old duplicates
    else:
        rows.append({k: row.get(k, "") for k in cols})
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, cols, restval="")
        w.writeheader()
        w.writerows(rows)


HOOK_CHECK = """
import bpy, sys
from bpy_extras.object_utils import world_to_camera_view
sc = bpy.context.scene
hook = bpy.data.objects.get("hook")
if hook is None:
    print("HOOKCHECK none"); sys.exit()
texts = [o for o in [hook] + list(hook.children_recursive) if o.type == "FONT"]
for fr in range(0, 31):
    sc.frame_set(fr)
    for t in texts:
        chain, o = [], t
        while o is not None:
            chain.append(o); o = o.parent
        if any(o.hide_render for o in chain) or hook.scale.x < 0.5:  # still popping in
            continue
        p = world_to_camera_view(sc, sc.camera, t.matrix_world.translation)
        if 0.02 < p.x < 0.98 and 0.02 < p.y < 0.98:
            print(f"HOOKCHECK {fr}"); sys.exit()
print("HOOKCHECK late")
"""


def hook_frame(out):
    """First frame (0-30) where the hook caption's text is rendered, at least half size and inside the frame."""
    script = os.path.join(out, "hookcheck.py")
    open(script, "w").write(HOOK_CHECK)
    p = subprocess.run([BLENDER, "--background", os.path.join(out, "scene.blend"), "--python", script],
                       capture_output=True, text=True)
    os.remove(script)
    m = re.search(r"HOOKCHECK (\S+)", p.stdout)
    return m.group(1) if m else "error"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("template")
    ap.add_argument("--prompt")
    ap.add_argument("--target", choices=["bash", "pip", "rocco"])
    ap.add_argument("--name")
    ap.add_argument("--hook", help="override the first-second caption (use \\n for a line break)")
    ap.add_argument("--confess")
    ap.add_argument("--batch", type=int, help="make N videos from the best unused app prompts")
    ap.add_argument("--stills", help="only render these frames as stills (fast preview)")
    ap.add_argument("--reuse-voices", action="store_true", help="keep existing vo/ (iterate on visuals)")
    ap.add_argument("--format", choices=list(layout.FORMATS), default="vertical", help="vertical 1080x1920 or horizontal 1920x1080")
    ap.add_argument("--script", help="episode JSON (template 'episode'), e.g. templates/examples/campfire-confessions/ep01.json")
    ap.add_argument("--jobs", type=int, default=3, help="parallel Blender renders for long templates (default 3)")
    ap.add_argument("--thumbnail", action="store_true", help="also make a 1280x720 YouTube thumbnail (automatic for horizontal episodes)")
    ap.add_argument("--cover", action="store_true", help="also make a 1080x1920 cover for Shorts/Reels/TikTok")
    ap.add_argument("--ones", action="store_true", help="long horizontal episodes render on twos by default; this renders every frame")
    a = ap.parse_args()
    if a.batch:
        import prompts
        targets = ["pip", "bash", "rocco"]
        for i, p in enumerate(prompts.pick(a.template, a.batch, int(time.time()))):
            print(f"\n=== {i + 1}/{a.batch}: {p}")
            make(a.template, p, targets[i % 3], None, a.hook, a.confess, None, False, a.format)
        return
    S = importlib.import_module(f"{a.template}_script")
    if not getattr(S, "STANDALONE", False) and not (a.prompt and a.target):
        ap.error("--prompt and --target are required (or use --batch)")
    make(a.template, a.prompt, a.target, a.name, a.hook, a.confess, a.stills, a.reuse_voices, a.format,
         os.path.abspath(a.script) if a.script else None, a.jobs, a.ones, a.thumbnail, a.cover)


def make(template, prompt, target, name, hook, confess, stills, reuse_voices, fmt="vertical", script=None, jobs=1, ones=False,
         thumbnail=False, cover=False):
    a = types.SimpleNamespace(template=template, prompt=prompt, target=target, name=name, confess=confess,
                              stills=stills, reuse_voices=reuse_voices)

    S = importlib.import_module(f"{a.template}_script")
    a.prompt = a.prompt or getattr(S, "DEFAULT_PROMPT", None)  # templates with defaults still log them in the tracker
    a.target = a.target or getattr(S, "DEFAULT_TARGET", None)
    if fmt not in getattr(S, "FORMATS", ("vertical",)):
        sys.exit(f"{a.template}: no {fmt} layout yet (its script's FORMATS = {getattr(S, 'FORMATS', ('vertical',))})")
    F = layout.Frame(fmt)
    stem = os.path.splitext(os.path.basename(script))[0] if script else None  # episode: <series folder>_<ep>
    if script:
        stem = os.path.basename(os.path.dirname(script)).replace("-", "_") + "_" + stem
    name = a.name or "_".join(filter(None, [stem or a.template, None if script else a.target,
                                            None if script else time.strftime("%m%d_%H%M"), None if F.vertical else "h"]))
    out = os.path.join(ROOT, "videos", name)
    os.makedirs(out, exist_ok=True)
    cfg = {"template": a.template, "prompt": a.prompt or "", "target": a.target or "", "format": fmt}
    if a.confess:
        cfg["confess"] = a.confess
    if hook:
        cfg["hook"] = hook
    if script:
        cfg["script"] = script
    json.dump(cfg, open(os.path.join(out, "config.json"), "w"), indent=2)
    log = [f"video: {name}", f"format: {fmt} {F.w}x{F.h}", f"prompt: {a.prompt}", f"target: {a.target}"]

    # 1. voices
    lines = S.lines(cfg)
    vo = os.path.join(out, "vo")
    os.makedirs(vo, exist_ok=True)
    # each line is voiced once and reused until its speaker or text changes (vo/<id>.txt remembers them)
    said = lambda i: open(os.path.join(vo, f"{i}.txt")).read() if os.path.exists(os.path.join(vo, f"{i}.txt")) else None
    todo = [(i, w, t) for i, w, t in lines if not os.path.exists(os.path.join(vo, f"{i}.wav"))
            or (not a.reuse_voices and said(i) != f"{w}\n{t}")]
    if todo:
        json.dump(todo, open(os.path.join(out, "job.json"), "w"))
        _, dt = run([VENV_PY, SPEAK, os.path.join(out, "job.json"), vo])
        log.append(f"voices: {len(todo)} of {len(lines)} lines in {dt:.0f}s")
    else:
        log.append(f"voices: all {len(lines)} lines reused")
    for i, w, t in lines:
        open(os.path.join(vo, f"{i}.txt"), "w").write(f"{w}\n{t}")
    dur = {i: wav_seconds(os.path.join(vo, f"{i}.wav")) for i, _, _ in lines}

    # 2. timing
    cues = S.timeline(cfg, dur)
    json.dump(cues, open(os.path.join(out, "cues.json"), "w"), indent=1)
    log.append(f"length: {(cues['END'] + 1) / 30:.1f}s ({cues['END'] + 1} frames)")

    # 3. sound
    o, _ = run([VENV_PY, os.path.join(HERE, "mix.py"), out])
    lufs = re.search(r"(-?\d+\.\d) LUFS", o)
    log.append(f"audio: {o.strip()}")

    # 4. render
    env = dict(os.environ)
    if a.stills:
        env["FRAMES"] = a.stills
    shutil.rmtree(os.path.join(out, "frames"), ignore_errors=True)
    scene_py = os.path.join(HERE, f"{a.template}_scene.py")
    n = max(1, jobs if getattr(S, "PARALLEL", False) and not a.stills else 1)
    # long 16:9 episodes animate "on twos" (each drawing held 2 frames, a classic 2D look) to halve render time
    step = 2 if getattr(S, "PARALLEL", False) and not F.vertical and not ones and not a.stills else 1
    env["FRAME_STEP"] = str(step)
    t0 = time.time()
    if n == 1:
        run([BLENDER, "--background", "--python", scene_py, "--", out], env=env)
    else:  # split the frame range over n Blender processes; job 0 also saves scene.blend
        total = cues["END"] + 1
        procs = []
        for k in range(n):
            lo_, hi_ = (k * total // n) // step * step, ((k + 1) * total // n) // step * step - 1 if k < n - 1 else total - 1
            e = dict(env, FRAME_RANGE=f"{lo_}-{hi_}", SAVE_BLEND="1" if k == 0 else "0")
            procs.append(subprocess.Popen([BLENDER, "--background", "--python", scene_py, "--", out], env=e,
                                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True))
        for pr in procs:
            o = pr.communicate()[0]
            if pr.returncode or "Traceback (most recent call last)" in o:
                sys.exit(f"FAILED: Blender render job\n{o[-2000:]}")
    if step > 1:  # fill the held frames
        fdir = os.path.join(out, "frames")
        for fr in range(cues["END"] + 1):
            dst = os.path.join(fdir, f"f_{fr:04d}.png")
            if not os.path.exists(dst):
                shutil.copy(os.path.join(fdir, f"f_{fr - fr % step:04d}.png"), dst)
    dt = time.time() - t0
    log.append(("render on twos: " if step > 1 else "render: ") + f"{dt:.0f}s" + (f" on {n} jobs ({dt / ((cues['END'] + 1) / 30) * 60:.0f} s per minute of video)" if n > 1 or getattr(S, "PARALLEL", False) else ""))
    if a.stills:
        print("\n".join(log), f"\nstills in {out}/stills")
        return

    # 5. encode
    mp4 = os.path.join(out, f"{name}.mp4")
    run(["ffmpeg", "-v", "error", "-y", "-framerate", "30", "-i", os.path.join(out, "frames", "f_%04d.png"),
         "-i", os.path.join(out, "audio.wav"), "-c:v", "libx264", "-pix_fmt", "yuv420p", "-crf", "18", "-preset", "slow",
         "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart", mp4])
    run(["ffmpeg", "-v", "error", "-y", "-i", mp4, "-c:v", "copy", "-an", mp4.replace(".mp4", "_silent.mp4")])

    # 6. QA
    qa = []
    vdur = float(run(["ffprobe", "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", mp4])[0])
    lo, hi = S.length(cfg) if hasattr(S, "length") else getattr(S, "LENGTH", (8, 20))  # templates can allow longer
    qa.append((f"duration {lo}-{hi}s", lo <= vdur <= hi, f"{vdur:.1f}s"))
    qa.append(("loudness -14 LUFS (+/-1)", bool(lufs) and abs(float(lufs.group(1)) + 14) <= 1, lufs.group(1) if lufs else "?"))
    p = subprocess.run(["ffmpeg", "-i", mp4, "-vf", "blackdetect=d=0.25:pix_th=0.06", "-an", "-f", "null", "-"],
                       capture_output=True, text=True)
    blacks = re.findall(r"black_start:(\S+)", p.stderr)
    qa.append(("no black gaps", not blacks, ", ".join(blacks) or "none"))
    p = subprocess.run(["ffmpeg", "-i", mp4, "-af", "silencedetect=n=-45dB:d=1.2", "-vn", "-f", "null", "-"],
                       capture_output=True, text=True)
    silences = re.findall(r"silence_start: (\S+)", p.stderr)
    qa.append(("no dead air > 1.2s", not silences, ", ".join(silences) or "none"))
    hf = hook_frame(out)
    hook_txt = S.hook(cfg).replace("\n", " ") if hasattr(S, "hook") else ""
    qa.append(("hook in first second", hf.isdigit(),
               f"visible at frame {hf}: {hook_txt}" if hf.isdigit() else
               {"none": "no object named 'hook' in the scene", "late": "hook not visible by frame 30"}.get(hf, "check failed")))
    # contact sheet: one frame a second, with the platform safe zones drawn on top
    sheet = os.path.join(out, "qa_sheet.png")
    tw, th = F.sheet_tile()
    zones = F.ffmpeg_zones()
    every = 1 if vdur <= 64 else 2  # one frame a second (every 2 s for long episodes), 8 per row
    rows = max(2, -(-int(vdur / every + 1) // 8))
    run(["ffmpeg", "-v", "error", "-y", "-i", mp4, "-vf", f"fps=1/{every},scale={tw}:{th},{zones},tile=8x{rows}", "-frames:v", "1", sheet])
    if cues.get("chapters"):  # YouTube chapters from the beat times
        fmt_t = lambda sec: f"{int(sec) // 60}:{int(sec) % 60:02d}"
        open(os.path.join(out, "chapters.txt"), "w").write("\n".join(f"{fmt_t(t)} {c}" for t, c in cues["chapters"]) + "\n")
        log.append(f"chapters: {len(cues['chapters'])} -> chapters.txt")
    rep = log + ["", "QA:"] + [f"  [{'PASS' if ok else 'FAIL'}] {k}: {v}" for k, ok, v in qa]
    open(os.path.join(out, "qa.txt"), "w").write("\n".join(rep) + "\n")
    shutil.rmtree(os.path.join(out, "frames"), ignore_errors=True)
    print("\n".join(rep))
    print(f"\n{mp4}")
    # 7. thumbnail / cover (single images; thumbnail.py can also make them later for any finished video)
    if thumbnail or (a.template == "episode" and not F.vertical):
        o, _ = run([sys.executable, os.path.join(HERE, "thumbnail.py"), out])
        print("thumbnail:", o.strip())
    if cover:
        o, _ = run([sys.executable, os.path.join(HERE, "thumbnail.py"), out, "--cover"])
        print("cover:", o.strip())
    hk = S.hook(cfg).replace("\n", " ") if hasattr(S, "hook") else ""
    track({"video": name, "made": time.strftime("%Y-%m-%d"), "template": a.template, "target": a.target,
           "hook": hk, "prompt": a.prompt, "length_s": f"{vdur:.1f}", "notes": S.notes(cfg) if hasattr(S, "notes") else ""})


if __name__ == "__main__":
    main()
