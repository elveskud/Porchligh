# Mystery teaser for room games ("Something's coming"): Riot alone in the dark with four glowing phones.
#   python3 make.py teaser --name teaser_mystery_01
FPS = 30
STANDALONE = True  # fixed script: no --prompt / --target needed
HOOK = "Don't tell anyone…"
CARD = "Something new is coming…"
CARD_SUB = "Already on Android"
CODE_LETTERS = "BCDFGHJKLMNPQRSTVWXZ"  # the app's room-code alphabet

SCRIPT = [
    ("l1_riot", "riot", "Psst... okay. I'm not supposed to show you this."),
    ("l2_riot", "riot", "Everyone's gonna play. Everyone."),
]


def hook(cfg):
    return HOOK


def lines(cfg):
    return [(i, who, text) for i, who, text in SCRIPT]


def timeline(cfg, dur):
    f = lambda s: int(round(s * FPS))
    s = lambda fr: round(fr / FPS, 3)
    c = {"click": 3}
    c["l1_riot"] = 14
    c["l1_riot_end"] = c["l1_riot"] + f(dur["l1_riot"])
    c["phones"] = [c["l1_riot_end"] + 8 + 15 * k for k in range(4)]  # one phone every half second
    c["code"] = c["phones"][-1] + 14
    c["code_end"] = c["code"] + 54                                     # letters spin, slow down, land on ????
    c["l2_riot"] = c["code_end"] + 6
    c["l2_riot_end"] = c["l2_riot"] + f(dur["l2_riot"])
    c["friends"] = c["l2_riot"] + 10
    c["caught"] = c["l2_riot_end"] + 8                                 # Riot notices the camera
    c["paw"] = c["caught"] + 12
    c["end"] = c["paw"] + 8
    c["END"] = c["end"] + 52
    c["voices"] = [[i, s(c[i])] for i, *_ in SCRIPT]
    sfx = [["click", s(c["click"]), 0.6]]
    for k, fr in enumerate(c["phones"]):
        sfx += [["thunk", s(fr), 0.45], [f"rise{k + 1}", s(fr + 1), 0.32]]
    sfx += [["tick", s(fr), 0.22] for fr in code_frames(c)]
    sfx += [["ting", s(c["code_end"]), 0.35],
            ["sparkle", s(c["friends"]), 0.25],
            ["boing", s(c["caught"]), 0.3], ["whoosh", s(c["paw"] - 3), 0.5], ["slam", s(c["end"] - 1), 0.25]]
    sfx += [["spray", s(c["end"] + 2 + 2 * k), 0.16] for k in range(0, 8, 2)]
    sfx += [["boom", s(c["end"] + 20), 0.4]]
    c["sfx"] = sfx
    c["ambience"] = [["hum", s(c["click"]), 0.22, s(c["end"] - c["click"])]]  # the hum dies with the cut
    c["music"] = []
    return c


def code_frames(c):
    """Frames where the code letters change: fast at first, slowing down like a slot machine."""
    out, fr, step = [], c["code"], 2.0
    while fr < c["code_end"]:
        out.append(int(fr))
        fr += step
        step *= 1.09
    return out
