# Blender scene for the "Never Have I Ever" template. Reads <video dir>/cues.json (made by make.py).
#   Blender --background --python nhie_scene.py -- <video dir> [FRAMES=10,200 for stills]
import os, sys, json
HERE_T = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE_T, "../characters"))
sys.path.insert(0, HERE_T)
from toon import *
import cast, props, locations, motion, layout
import nhie_script as S

OUT = sys.argv[sys.argv.index("--") + 1]
cfg = json.load(open(os.path.join(OUT, "config.json")))
cues = json.load(open(os.path.join(OUT, "cues.json")))
C = cues
END = C["END"]
vo = lambda i: os.path.join(OUT, "vo", f"{i}.wav")
text_of = {i: t for i, _, t in S.lines(cfg)}

F = layout.from_cfg(cfg)
V = F.vertical  # 9:16 numbers below are the original ones; 16:9 has its own framing
sc = reset()
F.setup(sc, OFFBLACK)
sc.frame_start, sc.frame_end = 0, END

# ---------- set & cast ----------
loc = locations.campfire()
if not V:
    locations.widen(loc)
seats = {"bash": 0, "pip": 1, "riot": 2, "rocco": 3}
chars = {"bash": cast.bear(), "pip": cast.bunny(), "riot": cast.riot(), "rocco": cast.raccoon()}
for k, c in chars.items():
    loc.seat(c, seats[k])
set_visible(chars["pip"].extras["sweat"], False)
A = {k: motion.Anim(c) for k, c in chars.items()}
target = cfg["target"]
tx = loc.seats[seats[target]][0]
toward = lambda k: (1.0 if tx > loc.seats[seats[k]][0] else -1.0)

# ---------- performances ----------
r = A["riot"]
motion.present(r, C["card_in"] - 2, hold=C["read_end"] - C["card_in"])
r.expr(C["read"], "hype")
motion.talk(r, C["read"], vo("riot_prompt"), text=text_of["riot_prompt"])
beats = [C["read"] + e for e in motion.phrase_ends(vo("riot_prompt"))]
for k, a in A.items():  # listen to Riot read: turn, lean in, nod at his phrase ends
    if k != "riot":
        d = 1.0 if loc.seats[seats["riot"]][0] > loc.seats[seats[k]][0] else -1.0
        a.look(C["read"] + 4, d, 8)
        a.expr(C["read"], "happy")
        motion.listen(a, C["read"] + 6, C["read_end"] + 6, d, beats, 0.6 if k == target else 1.0)

# innocent looking around; the target starts sweating
for i, (k, a) in enumerate(A.items()):
    if k == target:
        motion.nervous(a, C["sweat"], C["confess"] + 4)
    else:
        a.look(C["look"] + i * 3, (-0.6, 0.6)[i % 2], 5)
        a.look(C["look"] + 16 + i * 2, (0.6, -0.6)[i % 2], 5)
        a.expr(C["look"], "side_eye_l" if i % 2 else "side_eye_r")
# everyone turns to stare at the target
for k, a in A.items():
    if k != target:
        a.look(C["stare"] + (2 if k == "riot" else 0), toward(k), 4)
        a.expr(C["stare"] + 2, "suspicious")
# confession
t = A[target]
t.expr(C["confess"], "nervous")
motion.talk(t, C["confess"], vo("target_confess"), text=text_of["target_confess"])
# "Nooo way!" + everyone laughs (the target too: laughing with, never at)
motion.take(r, C["noway"] - 2, "shocked", 0.8)
motion.talk(r, C["noway"] + 2, vo("riot_noway"), text=text_of["riot_noway"])
motion.laugh(r, C["noway"] + 14, C["laugh_end"])
for k, a in A.items():  # staggered starts: the laugh spreads around the fire
    if k not in ("riot",):
        motion.laugh(a, C["noway"] + 6 + {"bash": 0, "pip": 5, "rocco": 9}[k] + (4 if k == target else 0), C["laugh_end"])
        a.look(C["noway"] + 4, 0.0, 6)
r.look(C["noway"] + 10, 0.0, 6)
for a in A.values():
    a.bake(0, max(END, C.get("BAKE_END", END)))

# ---------- props & graphics ----------
motion.flicker(loc.extras["flames"], 0, END, 0.1)
motion.flicker(loc.extras["glow"], 0, END, 0.05, seed=7)
card = props.prompt_card("card", "nhie", cfg["prompt"], (0.4, 13.3) if V else (6.8, 14.6), 20, w=11.0 if V else 10.0, size=0.66 if V else 0.62)
set_visible(card, False, 0)
motion.card_flip_in(card, C["card_in"])
motion.pop_out(card, C["stare"] - 4, 5)
hook = props.caption_box("hook", S.hook(cfg), (0.6, 17.35) if V else (-6.6, 15.9), 21, w=11.2, size=1.0)
set_visible(hook, False, 0)
motion.pop_in(hook, 2, 6, 1.1, 2)
motion.pop_out(hook, C["stare"] - 6, 5)
tgt_head = chars[target].extras["head"]
sc.frame_set(C["confess"])
hp = tgt_head.matrix_world.translation.copy()
ex = props.emote("ex", "exclaim", (hp.x + 0.2, hp.y + 4.6), 22, 1.1)
set_visible(ex, False, 0)
motion.pop_in(ex, C["stare"] + 4, 6)
motion.pop_out(ex, C["confess"] + 6, 4)
if target != "pip":
    sw = props.emote("sw", "sweat", (hp.x - 1.7, hp.y + 2.4), 22, 0.9)
    set_visible(sw, False, 0)
    motion.pop_in(sw, C["sweat"] + 6, 6)
    motion.pop_out(sw, C["noway"] + 4, 4)
WIDE = C.get("wide", C["noway"] + 30)
cf = props.confetti("cf", (0.6, 15.0), 23, spread=4.5)  # above the heads, so it rains down instead of covering faces
set_visible(cf, False, 0)
motion.burst(cf, WIDE, 30)

# ---------- camera ----------
rx = loc.seats[seats["riot"]][0]
# (x, y, ortho) per beat; ortho is the frame height. 16:9: the group fills ~60% of the height with the hook and
# card in the band above their heads, and close-ups whose edges fall in the gaps between characters
shot = dict(open=loc.cam, read=(0.6, 9.3, 23.5), target=(tx, 8.6, 13.0), riot=(rx + 0.3, 8.8, 14.5), wide=(0.6, 9.2, 21.0)) if V else \
       dict(open=(0.3, 9.4, 13.5), read=(0.3, 9.3, 13.2), target=F.clean_close(loc, seats[target], 7.5, 8.2, 0.46),
            riot=F.clean_close(loc, seats["riot"], 7.5, 8.2, 0.46), wide=F.default_cam(loc))
start = shot["open"]
cam = F.camera(sc, *start)
CA = motion.CamAnim(cam, start, loc.parallax)
if not V:  # hook + card ride on the camera layer in 16:9, scaled up to read on a sideways phone or a TV
    hud = empty("hud", cam, (0, 0), -8)
    CA.hud(hud)
    for o, xy in ((hook, (-10.2, 8.2)), (card, (10.6, 6.6))):  # both above the heads
        holder = empty(o.name + "_at", hud, xy, o.location.z - 30)
        holder.scale = (F.text_scale, F.text_scale, 1)
        o.parent = holder
        o.location = (0, 0, 0)
CA.intro()                                                                  # moving from frame 0
CA.push(C["read"], C["read_end"], shot["read"], "smooth")                  # slow creep while reading
CA.push(C["stare"], C["stare"] + 16, shot["target"], "out")                # snap toward the target
CA.push(C["confess_end"] - 2, C["noway"] + 1, shot["riot"], "out")         # whip to Riot BEFORE his line...
CA.cut(WIDE, shot["wide"])                                                  # ...held still through it, then wide for the laugh
EX = 100.0
CA.cut(C["end"], (EX, 9.0, 22.0))
# captions for the spoken lines (the prompt is already on the card); they keep their size through zooms
for lid in ("target_confess", "riot_noway"):
    start = {"target_confess": C["confess"], "riot_noway": C["noway"] + 2}[lid]
    CA.hud(props.word_captions(lid, cam, motion.word_times(text_of[lid], vo(lid)), start, y_px=1300) if V else
           props.word_captions(lid, cam, motion.word_times(text_of[lid], vo(lid)), start, fmt=F.fmt, y_frac=0.8, max_chars=22, size=1.45 * F.text_scale))
CA.bake(0, END)

# ---------- end card ----------
props.end_card("end", f"{S.TITLE} · free on Friendzy", (EX, 9.0), -5, fmt=F.fmt)
er = cast.riot()
er.root.location = (EX, -12.5, 2) if V else (EX + 10.5, -15.5, 2)
er.root.scale = (1.15, 1.15, 1) if V else (1.75, 1.75, 1)
ea = motion.Anim(er)
ea.expr(0, "laughing")
motion.talk(ea, C["end_vo"], vo("riot_end"), text=text_of["riot_end"])
mid = (C["end"] + END) // 2  # wave, then a thumbs up: never one pose for the whole card
motion.wave(ea, C["end"] + 4, mid + 4, side=-1)
motion.thumbs_up(ea, mid, hold=END - mid - 10)
ea.add(lambda fr: {"y": 7.0 * motion.curve(fr, [(C["end"], 0, "linear"), (C["end"] + 8, 1.0, "back")]) / 1.15})
ea.bake(C["end"] - 1, END)
for i in range(8):
    l = bpy.data.objects[f"end_l{i}"]
    set_visible(l, False, 0)
    motion.pop_in(l, C["end"] + 2 + i * 2, 5, 1.3, 8)
sub = bpy.data.objects["end_sub"]
set_visible(sub, False, 0)
motion.pop_in(sub, C["end"] + 20, 6)

bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, "scene.blend"))
frames = os.environ.get("FRAMES")
if frames:
    for fr in map(int, frames.split(",")):
        still(sc, os.path.join(OUT, "stills", f"s_{fr:04d}.png"), fr)
else:
    sc.render.filepath = os.path.join(OUT, "frames", "f_")
    bpy.ops.render.render(animation=True)
