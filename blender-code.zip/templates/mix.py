# Builds a video's soundtrack from its cues.json (generated SFX + music bed + voices) and masters it.
#   ../voices/.venv/bin/python mix.py <video dir>
import json, os, sys
import numpy as np
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "../audio"))
import sfxkit as K

SOUNDS = {
    "pop": K.pop, "whoosh": K.whoosh, "swish": K.swish, "slam": K.slam, "stamp": K.stamp, "card_flip": K.card_flip,
    "ting": K.ting, "sparkle": K.sparkle, "boing": K.boing, "slide_up": lambda: K.slide_whistle(True),
    "slide_down": lambda: K.slide_whistle(False), "drumroll": K.drumroll, "crash": K.crash, "boom": K.boom,
    "scratch": K.scratch, "tick": K.tick, "slurp": K.slurp, "crunch": K.crunch, "popper": K.popper, "tap": K.tap,
    "sting_dun_dun_dunnn": K.dun_dun_dunnn, "sting_fanfare": K.fanfare, "sting_sad_trombone": K.sad_trombone,
    "sting_suspense": lambda: K.suspense(3.0), "whistle": K.whistle, "buzzer": K.buzzer,
    "click": K.tap, "thunk": lambda: K.slam(0.5), "spray": K.spray,
    "drumroll_short": lambda: K.drumroll(0.55),
    "door": K.door,
    "breath": K.breath, "theme": K.theme,
    **{f"step_{k}{i}": (lambda k=k, i=i: K.footstep(k, 61 + i)) for k in ("wood", "sand", "stone") for i in range(4)},  # surfaces
    **{f"rise{k}": (lambda k=k: K.ting(0.8 + 0.2 * k)) for k in range(1, 5)},  # each phone a step higher
}

out = sys.argv[1]
cues = json.load(open(os.path.join(out, "cues.json")))
length = (cues["END"] + 1) / 30
mix = K.Mix(length)
for name, at, gain in cues.get("sfx", []):
    mix.add(SOUNDS[name](), at, gain)
for name, at, gain, *span in cues.get("ambience", []):  # optional 4th value: how long it lasts
    d = span[0] if span else length
    amb = {"fire": K.fire, "road": lambda d: K.norm(K.filt(K.brown(d, 3), "lp", 160), 0.7),
           "hum": K.suspense, **{k: (lambda d, k=k: np.tile(K.ROOMS[k](8.0), int(d / 8.0) + 2)[: int(d * K.SR)]) for k in K.ROOMS}}[name](d)
    if name in K.ROOMS:  # room tones ease in and out, so changing places is a soft crossfade, not a hard cut
        n_ = len(amb)
        t_ = np.arange(n_) / K.SR
        amb = amb * np.clip(t_ / 0.5, 0, 1) * np.clip((n_ / K.SR - t_) / 0.5, 0, 1)
        at = max(0.0, at - 0.25)
    mix.add(amb, at, gain)
if cues.get("music"):
    mood, at, gain, drop0, drop1 = cues["music"]
    bed = K.bed(mood, 8)
    reps = int(np.ceil(length * K.SR / len(bed))) + 1
    m = np.tile(bed, reps)[: int(length * K.SR)]
    t = np.arange(len(m)) / K.SR
    env = np.ones_like(t)
    env *= np.clip((drop0 - t) / 0.3, 0, 1) + np.clip((t - drop1) / 0.6, 0, 1)  # music drops out for the tense beat
    env *= np.clip(t / 0.4, 0, 1) * np.clip((length - t) / 0.8, 0, 1)
    mix.music(m * env, at, gain, loop=False)
for mood, a, b, gain, drops in cues.get("music_segments", []):  # episodes: one bed per run of same-mood beats
    bed = K.bed(mood, 16 if mood == "lofi" else 8)  # lofi: 16 bars (~49 s) so the loop doesn't wear thin
    n = int((b - a) * K.SR)
    m = np.tile(bed, n // len(bed) + 2)[:n]
    t = np.arange(n) / K.SR + a
    env = np.clip((t - a) / 0.3, 0, 1) * np.clip((b - t) / 0.5, 0, 1)
    for d0, d1 in drops:
        env *= np.clip((d0 - t) / 0.3, 0, 1) + np.clip((t - d1) / 0.6, 0, 1)
    mix.music(m * env, a, gain, loop=False)
ROOM_VERB = {"hall": (0.85, 0.32), "room": (0.3, 0.1)}  # voices in big empty rooms get a touch of their echo (room size, wet)
for line_id, at, *room in cues["voices"]:
    sig = K.read_wav(os.path.join(out, "vo", f"{line_id}.wav"))
    if room and room[0] in ROOM_VERB:
        sig = K.reverb(sig, *ROOM_VERB[room[0]])
    mix.voice(sig, at)
lufs = mix.write(os.path.join(out, "audio.wav"))
print(f"MIX {length:.2f}s  {lufs:.1f} LUFS")
