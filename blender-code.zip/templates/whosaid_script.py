# "Who Said That?" (a room game: every phone joins with a code) in the Party Room. Everyone holds their own phone.
# Beats (the app's real flow: answer privately -> one anonymous answer goes up on every screen -> everyone guesses
# -> reveal): Riot asks a real app question -> everyone types -> Riot reads the featured answer -> everyone points
# at Rocco -> "...Not me." -> it was PIP -> laugh -> end card.
#   python3 make.py whosaid --name whosaid_pizza_01 [--format horizontal]
from jokecues import end_cues, sequence

FPS = 30
STANDALONE = True
FORMATS = ("vertical", "horizontal")
TITLE = "Who Said That?"
HOOK = "we ALL guessed\nwrong"
QUESTION = "What's your most useless talent?"     # real prompt (Friendzy/Models/RoomGameDecks.swift, Who Said That?)
ANSWER = "I can eat a whole pizza in my sleep."     # what a player typed (answers are player-written in the game)
WRITER = "pip"

SCRIPT = [  # id, speaker, line, pause before (frames)
    ("riot_q", "riot", QUESTION, 12),
    ("riot_read", "riot", "I can eat a whole pizza... in my sleep.", 52),   # the gap = everyone typing
    ("bash_guess", "bash", "ROCCO. Obviously.", 10),
    ("rocco_no", "rocco", "...Not me.", 14),
    ("pip_hi", "pip", "...Hi.", 26),                                          # the gap = the reveal
]


def hook(cfg):
    return (cfg.get("hook") or HOOK).replace("\\n", "\n")


def lines(cfg):
    return [(i, w, t) for i, w, t, _ in SCRIPT] + [("riot_end", "riot", "Who Said That? Free on Friendzy.")]


def timeline(cfg, dur):
    f = lambda s: int(round(s * FPS))
    s = lambda fr: round(fr / FPS, 3)
    c = {}
    sequence(c, dur, f, SCRIPT)
    c["type"] = c["riot_q_end"] + 4
    c["sent"] = c["riot_read"] - 8
    c["point"] = c["bash_guess"] + 6
    c["reveal"] = c["pip_hi"] - 20
    c["laugh"] = c["pip_hi_end"] + 6
    end_cues(c, dur, f)
    taps = [["tap", s(c["type"] + k * 5), 0.35] for k in range(8)]
    c["voices"] = [[i, s(c[i])] for i, *_ in SCRIPT] + [["riot_end", s(c["end_vo"])]]
    c["sfx"] = taps + [
        ["pop", s(1 / 30), 0.4], ["ting", s(c["sent"]), 0.4], ["card_flip", s(c["sent"] + 4), 0.5],
        ["whoosh", s(c["point"] - 2), 0.45], ["slam", s(c["point"] + 4), 0.25],
        ["drumroll_short", s(c["reveal"] - 16), 0.4], ["stamp", s(c["reveal"]), 0.35], ["boing", s(c["pip_hi"] - 2), 0.3],
        ["popper", s(c["laugh"] + 2), 0.5], ["sting_fanfare", s(c["end"]), 0.45],
    ]
    c["ambience"] = []
    c["music_segments"] = [["hype", 0.0, s(c["END"]), 0.15, [[s(c["reveal"] - 18), s(c["pip_hi_end"])]]]]
    return c
