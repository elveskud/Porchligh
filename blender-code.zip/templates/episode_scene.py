# Blender scene for series episodes (episode_script.py): plays a JSON list of beats across locations.
#   Blender --background --python episode_scene.py -- <video dir>   (FRAMES=10,200 stills | FRAME_RANGE=a-b one render job)
import os, sys, json
HERE_T = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE_T, "../characters"))
sys.path.insert(0, HERE_T)
from toon import *
from mathutils import Vector
import cast, props, locations, motion, layout
import episode_script as S
import features

OUT = sys.argv[sys.argv.index("--") + 1]
cfg = json.load(open(os.path.join(OUT, "config.json")))
C = json.load(open(os.path.join(OUT, "cues.json")))
END = C["END"]
vo = lambda i: os.path.join(OUT, "vo", f"{i}.wav")
phrase_beats = lambda ev: [ev["start"] + e for e in motion.phrase_ends(vo(ev["id"]))]
F = layout.from_cfg(cfg)
V = F.vertical

# a render job only needs its own frames baked (plus a warm-up so springs and idle settle the same way)
_rng = os.environ.get("FRAME_RANGE")
R0, R1 = map(int, _rng.split("-")) if _rng else (0, END)
WARM = 45

sc = reset()
F.setup(sc, OFFBLACK)
if not V:
    sc.display.render_aa = "8"  # 16:9 episodes: half the samples, no visible difference at 1080p
sc.frame_start, sc.frame_end = 0, END

# ---------- locations: each one built once, side by side ----------
BUILD = {"campfire": locations.campfire, "living_room": lambda: locations.living_room("day"),
         "living_room_day": lambda: locations.living_room("day"), "living_room_night": lambda: locations.living_room("night"),
         "car": locations.car, "game_show": locations.game_show, "village_night": locations.village_night,
         "party_room": locations.party_room,
         **{n: (lambda n=n: locations.plate(n)) for n in locations.PLATE_SETS}}  # Porchlight painted sets
SPACING = 300.0
locs = {}
for B in C["beats"]:
    n = B["location"]
    if n not in locs:
        if n not in BUILD:
            raise SystemExit(f"episode: unknown location {n!r} ({', '.join(BUILD)})")
        L = BUILD[n]()
        if not V:
            try:
                locations.widen(L)
            except KeyError:
                raise SystemExit(f"episode: location {n!r} has no 16:9 version yet (locations.widen)")
        off = SPACING * len(locs)
        L.root.location.x = off
        locs[n] = (L, off, {o: Vector(o.location) for o, _ in L.parallax})
        if n == "car":
            locations.drive(L, 0, END, 1.0)
        if "flames" in L.extras:
            motion.flicker(L.extras["flames"], 0, END, 0.1)
        if "glow" in L.extras and n == "campfire":
            motion.flicker(L.extras["glow"], 0, END, 0.05, seed=7)


def seat_of(B, who):
    defaults = S.SEATS["car" if B["location"] == "car" else "default"]
    if who not in defaults and who not in (B.get("seats") or {}):  # anyone else: the first spot nobody in the beat uses
        taken = {defaults.get(w) for w in B["cast"] if w in defaults}
        defaults = {who: next(i for i in range(8) if i not in taken)}
    v = (B.get("seats") or {}).get(who, defaults.get(who))
    if isinstance(v, str):  # painted sets: a named spot ("sofa_l", "step", "tower", ...)
        L = locs[B["location"]][0]
        if v not in getattr(L, "spot_names", {}):
            raise SystemExit(f"episode: no spot {v!r} on {B['location']} ({', '.join(getattr(L, 'spot_names', {}))})")
        v = L.spot_names[v]
    return v


def seat_x(B, who):
    L, off, _ = locs[B["location"]]
    return L.seats[seat_of(B, who)][0] + off


def eye_y(B, who="riot"):
    L, _, _ = locs[B["location"]]
    _, hip, s, _ = L.seats[seat_of(B, who)]
    return hip + 5.4 * s


# ---------- cast: one instance per (location, character, costume), parked off-set when not in a beat ----------
import roster
MAKE = {name: (lambda cos, name=name: roster.make(name, cos)) for name in roster.PROFILES}  # every character in the roster
inst = {}
for B in C["beats"]:
    for who, cos in B["cast"].items():
        key = (B["location"], who, cos or "", str(seat_of(B, who)))  # a new spot on the same set = its own instance
        if key not in inst:
            L, off, _ = locs[B["location"]]
            c = roster.make(who, cos)
            L.seat(c, seat_of(B, who))
            c.root.location.x += off
            holder = empty(f"park_{who}_{len(inst)}", None, (0, 0), 0)
            c.root.parent = holder
            if who == "pip":
                set_visible(c.extras["sweat"], False)
            inst[key] = dict(c=c, a=motion.Anim(c), holder=holder, beats=[], busy=[])
        inst[key]["beats"].append(B["index"])
        B.setdefault("_inst", {})[who] = inst[key]


def park(I, frame, on):
    I["holder"].location.x = 0 if on else 5000
    I["holder"].keyframe_insert("location", frame=frame)


prefs = bpy.context.preferences.edit
interp0 = prefs.keyframe_new_interpolation_type
prefs.keyframe_new_interpolation_type = "CONSTANT"  # characters jump on/off set at beat cuts
for I in inst.values():
    park(I, 0, False)
for B in C["beats"]:
    for I in inst.values():
        park(I, B["start"], I in B.get("_inst", {}).values())  # empty-cast beats (riot_optional) have no instances
prefs.keyframe_new_interpolation_type = interp0


def fcurves_of(o):
    """Every F-curve on an object, for both classic and layered (Blender 4.4+) actions."""
    act = o.animation_data.action if o.animation_data else None
    if not act:
        return []
    if getattr(act, "layers", None):
        return [fc for lay in act.layers for st in lay.strips for bag in st.channelbags for fc in bag.fcurves]
    return list(act.fcurves)


for I in inst.values():  # the preference above isn't honoured in background renders: force the jumps
    for fc in fcurves_of(I["holder"]):
        for k in fc.keyframe_points:
            k.interpolation = "CONSTANT"


def A(B, who):
    return B["_inst"][who]["a"]


def busy(B, who, f0, f1):
    B["_inst"][who]["busy"].append((f0, f1))


def is_busy(B, who, f0, f1):
    return any(a < f1 and f0 < b for a, b in B["_inst"][who]["busy"])


def side(B, who, at):
    return 1.0 if seat_x(B, at) > seat_x(B, who) else -1.0


def munch(a, f, n=2):
    """Rocco: chips up to the mouth and back, n times (left paw holds the bag)."""
    keys = [(f, 8, "linear")]
    for i in range(n):
        keys += [(f + 6 + i * 10, -128, "back"), (f + 11 + i * 10, -95, "smooth")]
    keys.append((f + 12 + n * 10, 8, "smooth"))
    a.add(lambda fr: None if not (f <= fr <= keys[-1][0]) else {"arm-1": -8, "hand-1": "fist", "elbow-1": motion.curve(fr, keys)})
    return keys[-1][0]


def stare(B, who, f, f_end):
    """The look at the camera: head to us, eyes level, a held beat with one slow blink, camera close on him."""
    a = A(B, who)
    a.look(f, 0.0, 3)
    a.look_up(f, 0.0, 3)
    a.expr(f, "suspicious")
    CA.cut(f, framing(B, f"close:{who}"))


def dust(B, who, f):
    """A little cloud of dust at the feet when someone lands (hops, takes, cheers) on a painted set."""
    c = B["_inst"][who]["c"]
    s0 = c.root.scale.x
    col = {"sand": "#F2DDB8", "stone": "#C8C8D0", "wood": "#D8C8B0"}.get(S.SURFACE.get(B["location"]), "#E0D8C8")
    for k, dx in enumerate((-1.3, -0.5, 0.5, 1.3)):
        g = empty(f"dust_{who}_{f}_{k}", None, (seat_x(B, who) + dx * s0, c.root.location.y + 0.2 * s0), c.root.location.z + 0.5)
        shape(f"dust_{who}_{f}_{k}_s", ell(0, 0, 0.45 * s0, 0.3 * s0, n=16), col, g, 0.0, ol=0)
        set_visible(g, False, 0)
        set_visible(g, True, f)
        set_visible(g, False, f + 14)
        for fr, sc_, dy in ((f, 0.3, 0.0), (f + 6, 1.0, 0.25), (f + 13, 0.6, 0.45)):
            g.scale = (sc_, sc_, 1)
            g.location.y = c.root.location.y + (0.2 + dy) * s0 + dy
            g.location.x = seat_x(B, who) + dx * s0 * (1 + 0.6 * (fr - f) / 13)
            g.keyframe_insert("scale", frame=fr)
            g.keyframe_insert("location", frame=fr)


def do_move(B, who, move, f, f_end, target=None):
    a = A(B, who)
    if B["location"] in locations.PLATE_SETS and move in ("hop", "take", "cheer") and \
            locs[B["location"]][0].spot_kind[seat_of(B, who)] == "stand":
        dust(B, who, f + {"hop": 12, "take": 12, "cheer": 14}[move])
    tgt = target or next((w for w in B["cast"] if w != who), who)
    sd = side(B, who, tgt) if tgt != who else 1.0
    end = {"take": f + 30, "laugh": f_end + 30, "cheer": f + 30, "nervous": f_end + 10, "yell": f_end, "shrug": f + 26,
           "facepalm": f + 40, "wave": f + 30, "thumbs": f + 30, "present": f_end, "hop": f + 14, "double_take": f + 50,
           "point": f + 34, "munch": f + 34, "fan": f_end, "shiver": f_end, "stare": f_end}[move]
    {"stare": lambda: stare(B, who, f, end), "shiver": lambda: motion.shiver(a, f, end), "fan": lambda: motion.fan(a, f, end), "take": lambda: motion.take(a, f, "shocked"), "laugh": lambda: motion.laugh(a, f, end),
     "cheer": lambda: motion.cheer(a, f), "nervous": lambda: motion.nervous(a, f, end),
     "yell": lambda: motion.yell(a, f, end, int(sd)), "shrug": lambda: motion.shrug(a, f),
     "facepalm": lambda: motion.facepalm(a, f), "wave": lambda: motion.wave(a, f, end),
     "thumbs": lambda: motion.thumbs_up(a, f), "present": lambda: motion.present(a, f, hold=max(10, f_end - f - 8)),
     "hop": lambda: motion.hop(a, f), "double_take": lambda: motion.double_take(a, f, sd),
     "point": lambda: motion.point_at(a, f, int(sd), hold=26), "munch": lambda: munch(a, f, 2)}[move]()
    busy(B, who, f, end)


def speak(B, ev, listen=True):
    who = ev["who"]
    a = A(B, who)
    if ev.get("face"):
        a.expr(ev["start"] - 2, ev["face"])
    lk = ev.get("look")  # a cast member, or a direction: "left", "right", "up", "down", "up_left", "down_right"...
    if lk in B["cast"]:
        a.look(ev["start"] - 4, side(B, who, lk) * 0.7, 6)
    elif lk:
        ud, _, lr = lk.partition("_") if lk.split("_")[0] in ("up", "down") else ("", "", lk)
        if ud:
            a.look_up(ev["start"] - 4, 1.0 if ud == "up" else -1.0, 6)
        if lr in ("left", "right"):
            a.look(ev["start"] - 4, -0.7 if lr == "left" else 0.7, 6)
    if ev.get("quiet"):  # a quiet, emotional line: smaller acting, no hand gestures, the head barely moves
        motion.talk(a, ev["start"], vo(ev["id"]), text=ev["text"], energy=0.55, gestures=False)
    else:
        motion.talk(a, ev["start"], vo(ev["id"]), text=ev["text"])
    if ev.get("emote"):  # sweat, anger, sparkle, question, exclaim, heart, zzz
        emote_jobs.append((B, who, ev["emote"], ev["start"], ev["end"] + 10))
    c_ = B["_inst"][who]["c"]
    if "sweat" in c_.extras and ev.get("face") in ("nervous", "scared"):  # Pip sweats on nervous and scared lines
        set_visible(c_.extras["sweat"], True, ev["start"])
        set_visible(c_.extras["sweat"], False, ev["end"] + 12)
    if not ev.get("camera"):
        if ev.get("quiet"):  # emotional lines: a slow push-in while they speak
            x_, y_, o_ = framing(B, f"close:{who}")
            CA.push(ev["start"], ev["end"] + 6, (x_, y_, o_ * 0.88), "smooth")
        elif ev.get("punch"):  # the joke lands: a quick snap in, then hold
            x_, y_, o_ = framing(B, f"close:{who}")
            CA.push(ev["start"] - 4, ev["start"] + 3, (x_, y_, o_ * 0.82), "out")
    if ev.get("react"):  # cut to the listener's face for the reaction
        CA.cut(ev["end"] + 2, framing(B, f"close:{ev['react']}"))
    if who == "bash" and ev.get("face") == "yelling":
        CA.shake(ev["start"] + 2, 8, 0.15)
    if ev.get("do"):
        do_move(B, who, ev["do"], ev["start"] + 2, ev["end"], ev.get("target"))
    if listen:
        for other in B["cast"]:
            if other == who:
                continue
            o = A(B, other)
            o.look(ev["start"] - 3, side(B, other, who), 6)
            if not is_busy(B, other, ev["start"], ev["end"]):
                motion.listen(o, ev["start"] + 2, ev["end"] + 4, side(B, other, who), phrase_beats(ev))


# ---------- camera framings ----------
def framing(B, spec, band=False):
    x, y, o = _framing(B, spec, band)
    if B["location"] in locations.PLATE_SETS:  # painted sets: never let the frame run past the painting
        _, off, _ = locs[B["location"]]
        ph = locations.PLATE_O * locations.PLATE_BLEED
        o = min(o, ph - 0.4)
        mx_ = ph * 16 / 9 / 2 - o * 16 / 9 / 2 - 0.25  # 0.25: room for the camera's drift
        my_ = ph / 2 - o / 2 - 0.15
        x = off + max(-mx_, min(mx_, x - off))
        y = locations.PLATE_O / 2 + max(-my_, min(my_, y - locations.PLATE_O / 2))
    return (x, y, o)


def _framing(B, spec, band=False):
    L, off, _ = locs[B["location"]]
    if spec == "wide" or not spec:
        x, y, o = L.cam if V else L.cam_h
        if band and not V:      # 16:9 with a card up: lift the group so the card fits above their heads
            y += 0.6
        if band and V and B["game"] and B["game"]["type"] == "td":
            x, y, o = F.eye_framing(L.cam[0], eye_y(B), 21.0, 0.68)
        return (x + off, y, o)
    kind, _, who = spec.partition(":")
    if kind == "at":  # point of view / insert shot on a spot in the painting: "at:px,py,ortho"
        px, py, o = (float(v) for v in who.split(","))
        x, y = locations.plate_xy(B["location"], px, py)
        return (x + off, y, o)
    names = who.split(",")
    if kind == "ots" and len(names) == 2 and not V:  # over the shoulder: favour the 2nd, the 1st cut by the frame edge
        xa, xb = seat_x(B, names[0]) - off, seat_x(B, names[1]) - off
        x = xb + 0.35 * (xa - xb)
        o = max(5.0, abs(xa - x) / 0.92 * 2 * 9 / 16)
        x, y, o = F.eye_framing(x, eye_y(B, names[1]), o, 0.42)
        return (x + off, y, o)
    seats = [seat_of(B, w) for w in names]
    ey = eye_y(B, names[0])
    if kind == "close" and len(names) == 1:
        if V:
            return (seat_x(B, names[0]) + 0.3, ey + 0.4, 13.0)
        x, y, o = F.clean_close(L, seats[0], 7.5, ey, 0.46)
    else:
        if V:
            xs = [seat_x(B, w) for w in names]
            return ((min(xs) + max(xs)) / 2 + 0.2, ey + 0.4, max(14.0, (max(xs) - min(xs) + 4.6) / F.aspect))
        x, y, o = F.clean_span(L, seats, ey, 0.46)
    return (x + off, y, o)


cam = F.camera(sc, *framing(C["beats"][0], C["beats"][0]["camera"]))
CA = motion.CamAnim(cam, framing(C["beats"][0], C["beats"][0]["camera"]), ())
CA.intro()
hud = empty("hud", cam, (0, 0), -8)
CA.hud(hud)


def on_hud(o, xy, s=1.0):
    holder = empty(o.name + "_at", hud, xy, o.location.z)
    holder.scale = (s, s, 1)
    o.parent = holder
    o.location = (0, 0, 0)
    return o


TS = F.text_scale
TEXT_XY = (0.0, F.hud_y(0.17)) if V else (-10.2, 8.2)
CARD_XY, CARD_S = ((0.0, F.hud_y(0.29)), 1.0) if V else ((10.6, 6.4), 1.3)
CHOICE_XY, CHOICE_S = ((-0.4, F.hud_y(0.42)), 0.8) if V else ((11.0, 2.0), 1.05)


def caption_at(name, body, f_in, f_out):
    if "\n" not in body and len(body) > 24:
        body = props.wrap(body, 10.0, 1.2)
    box = on_hud(props.caption_box(name, body, (0, 0), 1.0, w=10.4 if V else 11.2, size=0.95), TEXT_XY, TS)
    set_visible(box, False, 0)
    motion.pop_in(box, f_in, 6, 1.1, 2)
    motion.pop_out(box, f_out, 5)
    return box


def card_at(name, game, text, f_in, f_out, flip=True):
    card = on_hud(props.prompt_card(name, game, text, (0, 0), 0.6, w=10.4 if V else 10.0, size=0.72 if V else 0.6), CARD_XY, CARD_S)
    set_visible(card, False, 0)
    (motion.card_flip_in if flip else motion.pop_in)(card, f_in)
    motion.pop_out(card, f_out, 5)
    return card


def head_xy(B, who, f):
    sc.frame_set(f)
    h = B["_inst"][who]["c"].extras["head"].matrix_world.translation
    return h.x, h.y


emote_jobs = []  # (B, who, kind, f_in, f_out): placed after the characters are baked


# ---------- beats ----------
for bi, B in enumerate(C["beats"]):
    st, en = B["start"], B["end"]
    # camera: cut to the beat's framing (the first beat already starts there)
    if bi:
        CA.cut(st, framing(B, B["camera"]))
    if B.get("move"):  # a slow camera move across the beat: from its camera to "move" (any camera spec)
        CA.push(st + 4, en - 4, framing(B, B["move"]), "smooth")
    for who in B["cast"]:
        A(B, who).expr(st, "hype" if who == "riot" else "happy")
        A(B, who).look(st, 0.0, 4)
        A(B, who).look_up(st, 0.0, 4)
    # on-screen text: the first beat's text is the hook (named "hook" for QA)
    if B["text"]:
        first_game = B["game"] and (B["game"].get("card_in") or B["game"].get("choice_in") or B["game"].get("timer_in"))
        prev = next((ev for ev in B["events"] if ev.get("previously")), None)
        out_at = min(x for x in (en - 6, (first_game or 10 ** 9) - 6, (prev["start"] - 4) if prev else 10 ** 9) if x is not None)
        if C.get("ending") == "porch_light" and not V:  # Porchlight: styled like the title, top left
            hk = empty("hook" if bi == 0 else f"text{bi}", None, (0, 0), 0.5)
            props.outlined_text(f"{hk.name}_t", B["text"], 1.3, "#FFD27A", hk, (0, 0), 0.0, 0.09, align="LEFT")
            on_hud(hk, (-17.5, 8.6), TS)
            set_visible(hk, False, 0)
            motion.pop_in(hk, 1 if bi == 0 else st + 2, 6)
            motion.pop_out(hk, out_at, 5)
        else:
            caption_at("hook" if bi == 0 else f"text{bi}", B["text"], 1 if bi == 0 else st + 2, out_at)
    # party scenes: everyone nods along to the music a little (118 bpm hype bed: a beat every ~15 frames)
    if B["mood"] == "party":
        for who in B["cast"]:
            if who in B.get("asleep", []):
                continue
            A(B, who).add(lambda fr, st=st, en=en: None if not (st <= fr <= en) else
                          {"head_y": 0.035 * abs(math.sin(math.pi * (fr - st) / 15.25))})
    # asleep for the beat: eyes shut, head tipped, slow breathing, floating "z"s; no listening reactions
    for who in B.get("asleep", []):
        A(B, who).expr(st, "asleep")
        motion.sleep(A(B, who), st, en)
        busy(B, who, st, en)
        emote_jobs.append((B, who, "zzz", st + 6, en))
    # spoken lines (game lines are handled with their game below)
    for ev in B["events"]:
        if ev.get("role") in ("read", "confess", "choose", "perform", "clue", "guess") or "_after" in ev["id"]:
            continue  # game lines are played with their game below
        if ev.get("previously"):
            if V:  # red PREVIOUSLY pill above the recap; 16:9 has no room above, so the word leads the box
                pl = on_hud(props.pill("prevpill", "PREVIOUSLY", (0, 0), 1.1, bg=RED, size=1.0), (TEXT_XY[0], TEXT_XY[1] + 2.4), 1.0)
                set_visible(pl, False, 0)
                motion.pop_in(pl, ev["start"] - 6, 6)
                motion.pop_out(pl, ev["end"] + 4, 4)
                caption_at("prevtext", ev["previously"], ev["start"] - 4, ev["end"] + 6)
            else:
                caption_at("prevtext", "previously...\n" + props.wrap(ev["previously"], 14.0, 1.2), ev["start"] - 4, ev["end"] + 6)
        speak(B, ev)
        if ev.get("camera"):
            CA.push(ev["start"] - 10, ev["start"] - 1, framing(B, ev["camera"]), "out")
    # walking on and off: from just past the frame edge to their spot, or from their spot off the side
    if B.get("enter") or B.get("exit"):
        cx, _, co = framing(B, B["camera"])
        hw_ = co * (9 / 16 if V else 16 / 9) / 2 + 2.5
        for who, sd in B.get("enter", {}).items():
            I_ = B["_inst"][who]
            off_x = ((cx - hw_ if sd == "left" else cx + hw_) - seat_x(B, who)) / I_["c"].root.scale.x
            motion.walk(I_["a"], st + 2, st + 2 + motion.WALK, off_x, 0.0)
            busy(B, who, st, st + motion.WALK + 4)
        for who, sd in B.get("exit", {}).items():
            I_ = B["_inst"][who]
            off_x = ((cx - hw_ if sd == "left" else cx + hw_) - seat_x(B, who)) / I_["c"].root.scale.x
            motion.walk(I_["a"], en - motion.WALK - 4, en - 4, 0.0, off_x)
            busy(B, who, en - motion.WALK - 6, en)
    # props carried for the whole beat ("carry": {"who": "phone" | "flashlight" | "cup"}), in the left paw
    for who, what in B.get("carry", {}).items():
        hand = B["_inst"][who]["c"].extras["hand-1"]
        g = empty(f"hold{bi}_{who}", hand, (0.0, -0.5), 0.06)
        if what == "phone":
            props.phone(f"hold{bi}_{who}_p", g, (0, 0), 0.0, 0.75)
        elif what == "flashlight":
            shape(f"hold{bi}_{who}_body", rect(-0.18, -0.9, 0.18, 0.5), "#3A3F4A", g, 0.0, smooth=0)
            shape(f"hold{bi}_{who}_head", [(-0.3, 0.5, "s"), (0.3, 0.5, "s"), (0.24, 0.9, "s"), (-0.24, 0.9, "s")], "#5A606C", g, 0.01, smooth=0)
            shape(f"hold{bi}_{who}_lens", ell(0, 0.92, 0.22, 0.06), "#FFF4C2", g, 0.02, ol=0)
        elif what == "cup":
            shape(f"hold{bi}_{who}_cup", [(-0.35, 0.45, "s"), (0.35, 0.45, "s"), (0.27, -0.45, "s"), (-0.27, -0.45, "s")], "#F4F2F6", g, 0.0, smooth=0)
            stroke(f"hold{bi}_{who}_handle", [(0.33, 0.25), (0.6, 0.15), (0.6, -0.15), (0.3, -0.25)], 0.08, OUTLINE, g, -0.01)
        set_visible(g, False, 0)
        set_visible(g, True, st)
        set_visible(g, False, en)
    # walking to another spot during the beat: "walk_to": {"riot": ["s3", 2.0]} (spot, seconds in); he stays there
    for who, (spot, sec) in B.get("walk_to", {}).items():
        L_ = locs[B["location"]][0]
        i_ = L_.spot_names[spot] if isinstance(spot, str) else spot
        I_ = B["_inst"][who]
        dx = (L_.seats[i_][0] + locs[B["location"]][1] - seat_x(B, who)) / I_["c"].root.scale.x
        f_ = st + int(sec * S.FPS)
        motion.walk(I_["a"], f_, f_ + motion.WALK, 0.0, dx, hold_until=en + 2)
        busy(B, who, f_ - 8, f_ + motion.WALK + 6)
    # footprints: walking on sand leaves prints that stay for the rest of the beat
    if S.SURFACE.get(B["location"]) == "sand":
        for walks, inn in ((B.get("enter", {}), True), (B.get("exit", {}), False)):
            for who, sd in walks.items():
                I_ = B["_inst"][who]
                s0 = I_["c"].root.scale.x
                cx, _, co = framing(B, B["camera"])
                hw_ = co * 16 / 9 / 2 + 2.5
                far = (cx - hw_ if sd == "left" else cx + hw_) - seat_x(B, who)
                f0_ = st + 2 if inn else en - motion.WALK - 4
                gy = I_["c"].root.location.y
                for i in range(1, motion.WALK // motion.STEP + 1):
                    u = i * motion.STEP / motion.WALK
                    e = u * u * (3 - 2 * u) * 0.35 + u * 0.65
                    px = seat_x(B, who) + (far * (1 - e) if inn else far * e)
                    fp = shape(f"print{bi}_{who}_{i}", ell(px + (0.35 if i % 2 else -0.35) * s0, gy + 0.05, 0.42 * s0, 0.14 * s0, n=16),
                               "#C99A6A", None, -0.8, ol=0)
                    set_visible(fp, False, 0)
                    set_visible(fp, True, f0_ + i * motion.STEP)
                    set_visible(fp, False, en)
    # group chat: [["Riot", "LIGHT'S ON"], ...] bubbles stack up on the right, each in its sender's colour
    if B.get("chat"):
        CHAT_COL = {"riot": "#FF6B00", "bash": "#E8192C", "pip": "#3D6DFF", "rocco": "#22B573"}
        for k, (who_, msg) in enumerate(B["chat"]):
            f_in = st + S.CHAT_IN + k * S.CHAT_EVERY
            col = CHAT_COL.get(who_.lower(), "#6A6A7A")
            w_ = max(len(msg), len(who_)) * 0.52 + 1.4
            cam_x = framing(B, B["camera"])[0]
            right = sum(seat_x(B, w) for w in B["cast"]) / max(1, len(B["cast"])) < cam_x  # bubbles go where the cast isn't
            bx = (18.4 - w_ * TS / 2) if right else (-18.4 + w_ * TS / 2)
            bx, by = (bx, 7.4 - k * 2.5 * TS) if not V else (0.0, F.hud_y(0.2) - k * 2.4)  # edges stay in frame
            bub = empty(f"chat{bi}_{k}", None, (0, 0), 0.5)
            shape(f"chat{bi}_{k}_bg", props.rrect4(-w_ / 2, -1.0, w_ / 2, 1.0, (0.55, 0.55, 0.15, 0.55)), "#FFFFFF", bub, 0.0, smooth=0)
            shape(f"chat{bi}_{k}_bar", props.rrect4(-w_ / 2, 0.2, w_ / 2, 1.0, (0.0, 0.55, 0.55, 0.0)), col, bub, 0.01, ol=0, smooth=0)
            text(f"chat{bi}_{k}_who", who_, 0.62, "#FFFFFF", bub, (-w_ / 2 + 0.5, 0.6), 0.02, align="LEFT")
            text(f"chat{bi}_{k}_msg", msg, 0.82, OFFBLACK, bub, (-w_ / 2 + 0.5, -0.4), 0.02, align="LEFT")
            on_hud(bub, (bx, by), TS)
            set_visible(bub, False, 0)
            motion.pop_in(bub, f_in, 6, 1.12, 3)
            motion.pop_out(bub, en - 6, 5)
    # transitions: "transition": "fade" fades in from black (a time jump); letterbox bars for cinematic beats
    if B.get("transition") == "fade" or B.get("letterbox"):
        if B.get("transition") == "fade":
            fd = on_hud(shape(f"fade{bi}", rect(-30, -20, 30, 20), OFFBLACK, None, 0.0, ol=0, smooth=0), (0, 0), 1.0)
            fd.location.z = 3.0
            fm = mat("#121212").copy()
            fd.material_slots[0].material = fm
            for fr_, a_ in ((st - 12, 0.0), (st, 1.0), (st + 14, 0.0)):
                fm.diffuse_color[3] = a_
                fm.keyframe_insert("diffuse_color", index=3, frame=fr_)
            set_visible(fd, False, 0)
            set_visible(fd, True, st - 12)
            set_visible(fd, False, st + 15)
        if B.get("letterbox"):
            for sg in (1, -1):
                bar = on_hud(shape(f"lbox{bi}{sg}", rect(-30, 0, 30, 3.0), OFFBLACK, None, 0.0, ol=0, smooth=0), (0, sg * 9.6), 1.0)
                bar.scale.y = sg
                set_visible(bar, False, 0)
                set_visible(bar, True, st)
                set_visible(bar, False, en)
    # weather: a summer storm (rain streaks, lightning flashes, a darker sky over everything)
    if B.get("weather") == "storm":
        _, off_, _ = locs[B["location"]]
        cx, cy, co = framing(B, B["camera"])
        dark = light(f"storm{bi}_dark", rect(off_ - 60, -30, off_ + 60, 40), "#141A30", 0.32, None, 14.0, smooth=0)
        flash = light(f"storm{bi}_flash", rect(off_ - 60, -30, off_ + 60, 40), "#E8F0FF", 0.0, None, 14.6, smooth=0)
        m_ = flash.material_slots[0].material.copy()
        flash.material_slots[0].material = m_
        for fr in range(st, en + 1):
            u = (fr - st - 40) % S.STORM_EVERY
            a_ = 0.55 if u in (0, 1) else 0.25 if u in (4, 5) else 0.0  # a double flicker
            m_.diffuse_color[3] = a_
            if u == 18:
                CA.shake(fr, 10, 0.25)  # the thunder lands
            if fr == st or a_ or u in (2, 6):
                m_.keyframe_insert("diffuse_color", index=3, frame=fr)
        for fc in fcurves_of(m_):  # flashes snap on and off
            for kp in fc.keyframe_points:
                kp.interpolation = "CONSTANT"
        rnd_ = __import__("random").Random(bi)
        rain = empty(f"storm{bi}_rain", None, (0, 0), 13.0)
        for i in range(70):
            x0_, y0_ = rnd_.uniform(cx - 16, cx + 16), rnd_.uniform(-2, 16)
            dr = stroke(f"storm{bi}_r{i}", [(0, 0), (-0.25, -1.1)], 0.035, "#C8D6F0", rain, 0.0)
            ph_ = rnd_.uniform(0, 1)
            for fr in range(st, en + 1, 2):
                u = ((fr - st) / 14.0 + ph_) % 1.0
                dr.location = (x0_ - 3.0 * u, y0_ + 8 - 16 * u, 0)
                dr.keyframe_insert("location", frame=fr)
        for o_ in (dark, flash, rain):
            set_visible(o_, False, 0)
            set_visible(o_, True, st)
            set_visible(o_, False, en)
    # set effects: a lamp switching on, a flashlight sweeping a dark room (painted sets; positions in painting px)
    for fx in B.get("fx", []):
        L_, off_, _ = locs[B["location"]]
        pt = lambda px, py: (locations.plate_xy(B["location"], px, py)[0] + off_, locations.plate_xy(B["location"], px, py)[1])
        if fx["type"] == "lamp_on":
            g = empty(f"lamp{bi}", None, pt(*fx["at_px"]), 9.0)
            glow(f"lamp{bi}_g", (0, 0), fx.get("r", 2.4), fx.get("r", 2.4), fx.get("color", "#FFC861"), 0.022, 40, g, 0.0)
            on = st + int(fx.get("at", 0.5) * S.FPS)
            room = light(f"lamp{bi}_room", rect(off_ - 60, -30, off_ + 60, 40), fx.get("color", "#FFC861"), fx.get("room", 0.05), None, 14.5, smooth=0)
            for o_ in (g, room):  # the light and the warmth it gives the whole place
                set_visible(o_, False, 0)
                set_visible(o_, True, on)
                set_visible(o_, False, en)
        elif fx["type"] == "title":  # the show's title card: big outlined letters that pop in one by one, warm glow behind
            word = fx.get("text", "PORCHLIGHT")
            t0 = st + int(fx.get("at", 0.5) * S.FPS)
            tg = empty(f"title{bi}", None, (0, 0), 0.5)
            glow(f"title{bi}_glow", (0, 0.2), 10.0, 2.6, "#FFC861", 0.009, 50, tg, -0.1)
            n_ = len(word)
            for k, ch in enumerate(word):
                lg = empty(f"title{bi}_l{k}", tg, ((k - (n_ - 1) / 2) * 1.85, 0.0), 0.0)
                props.outlined_text(f"title{bi}_l{k}_t", ch, 3.2, "#FFD27A", lg, (0, 0), 0.0, 0.16)
                set_visible(lg, False, 0)
                motion.pop_in(lg, t0 + k * 3, 6, 1.25, 4)
            if fx.get("sub"):
                sg = empty(f"title{bi}_sub", tg, (0, -2.6), 0.0)
                props.outlined_text(f"title{bi}_sub_t", fx["sub"], 1.0, "#FFFFFF", sg, (0, 0), 0.0, 0.06)
                set_visible(sg, False, 0)
                motion.pop_in(sg, t0 + n_ * 3 + 8, 6)
            on_hud(tg, (0.0, 1.0), 1.0)
            glo = bpy.data.objects[f"title{bi}_glow"]
            set_visible(glo, False, 0)
            set_visible(glo, True, t0)
            set_visible(tg, False, en)  # everything off at the end of the beat
        elif fx["type"] == "card":  # a time card: "Later that night." over the shot
            t0 = st + int(fx.get("at", 0.2) * S.FPS)
            cg = empty(f"tcard{bi}", None, (0, 0), 0.5)
            props.outlined_text(f"tcard{bi}_t", fx.get("text", "Later that night."), 1.6, "#FFFFFF", cg, (0, 0), 0.0, 0.1)
            on_hud(cg, (0.0, 6.5), TS)
            set_visible(cg, False, 0)
            motion.pop_in(cg, t0, 6)
            motion.pop_out(cg, t0 + int(fx.get("for", 2.0) * S.FPS), 5)
        elif fx["type"] == "critter":  # a small animal from Porchlight/art/parts/critters, bobbing; ripples on water
            x_, y_ = pt(*fx["at_px"])
            g = empty(f"critter{bi}_{fx['piece']}", None, (x_, y_), fx.get("z", 3.0))
            # poses: [[seconds, piece], ...] switch on cue; "blink": a piece shown for 4 frames every few seconds
            sched = [(st, fx["piece"])] + [(st + int(t_ * S.FPS), pc) for t_, pc in fx.get("poses", [])]
            pcs = {}
            w0_ = None
            for pc in dict.fromkeys([p_ for _, p_ in sched] + ([fx["blink"]] if fx.get("blink") else [])):
                path = os.path.expanduser(f"~/Desktop/Porchlight/art/parts/critters/{pc}.png")
                im_ = bpy.data.images.get(path) or bpy.data.images.load(path)
                w_, h_ = im_.size
                w0_ = w0_ or w_  # every pose at the first pose's scale
                pcs[pc] = img(f"critter{bi}_{pc}_img", path, g, (w_ / 2, h_ * fx.get("anchor_y", 1.0)), w0_ / fx.get("width", 1.4), 0.0)
            def piece_at(fr):
                cur = [p_ for f_, p_ in sched if f_ <= fr][-1]
                if fx.get("blink") and cur == fx["piece"] and (fr - st) % 95 < 4 and fr - st > 20:
                    return fx["blink"]
                return cur
            for pc, o_ in pcs.items():
                set_visible(o_, False, 0)
            prev_ = None
            for fr in range(st, en + 1):
                cur = piece_at(fr)
                if cur != prev_:
                    for pc, o_ in pcs.items():
                        set_visible(o_, pc == cur, fr)
                    prev_ = cur
            ph0 = bi * 7.0
            for fr in range(st, en + 1, 2):
                g.location.y = y_ + fx.get("bob", 0.0) * math.sin(fr * 0.12 + ph0)
                g.rotation_euler.z = fx.get("rock", 0.0) * math.sin(fr * 0.09 + ph0)
                g.keyframe_insert("location", index=1, frame=fr)
                g.keyframe_insert("rotation_euler", index=2, frame=fr)
            if fx.get("ripples"):
                for k in range(3):
                    rg = empty(f"ripple{bi}_{k}", None, (x_, y_ + 0.02), fx.get("z", 3.0) - 0.05)
                    ring = [(math.cos(2 * math.pi * j / 40), 0.22 * math.sin(2 * math.pi * j / 40)) for j in range(41)]
                    stroke(f"ripple{bi}_{k}_s", ring, 0.035, "#D8E8F5", rg, 0.0)
                    set_visible(rg, False, 0)
                    set_visible(rg, True, st)
                    set_visible(rg, False, en)
                    for fr in range(st, en + 1, 2):
                        u = ((fr - st) / 60.0 + k / 3) % 1.0
                        sc_ = 0.4 + 1.4 * u
                        rg.scale = (sc_ * fx.get("width", 1.4) * 0.6, sc_ * fx.get("width", 1.4) * 0.6, 1)
                        rg.keyframe_insert("scale", frame=fr)
            set_visible(g, False, 0)
            set_visible(g, True, st)
            set_visible(g, False, en)
        elif fx["type"] == "flashlight":  # a beam from off-screen; its spot follows the path [[px, py, seconds], ...]
            src = pt(*fx["from_px"])
            g = empty(f"torch{bi}", None, (0, 0), 8.0)
            spot = empty(f"torch{bi}_spot", g, pt(*fx["path"][0][:2]), 0.1)
            glow(f"torch{bi}_sg", (0, 0), 1.6, 0.7, "#FFE9A8", 0.03, 24, spot, 0.0)
            keys = [(st + int(t * S.FPS), pt(px, py)) for px, py, t in fx["path"]]
            beam = light(f"torch{bi}_beam", [(0, 0.06, "s"), (1, 0.6, "s"), (1, -0.6, "s"), (0, -0.06, "s")], "#FFE9A8", 0.16, g, 0.0, smooth=0)
            beam.location = (src[0], src[1], 0)
            for fr in range(st, en + 1, 2):
                i_ = max([k for k, (kf, _) in enumerate(keys) if kf <= fr] or [0])
                (f0_, p0), (f1_, p1) = keys[i_], keys[min(i_ + 1, len(keys) - 1)]
                u = 0.0 if f1_ == f0_ else max(0.0, min(1.0, (fr - f0_) / (f1_ - f0_)))
                u = u * u * (3 - 2 * u)
                tx, ty = p0[0] + (p1[0] - p0[0]) * u, p0[1] + (p1[1] - p0[1]) * u
                spot.location = (tx, ty, 0.1)
                dx, dy = tx - src[0], ty - src[1]
                beam.rotation_euler.z = math.atan2(dy, dx)
                d = math.hypot(dx, dy)
                beam.scale = (d, d * 0.12, 1)
                spot.keyframe_insert("location", frame=fr)
                beam.keyframe_insert("rotation_euler", index=2, frame=fr)
                beam.keyframe_insert("scale", frame=fr)
            set_visible(g, False, 0)
            set_visible(g, True, st + int(fx.get("on", 0.0) * S.FPS))
            set_visible(g, False, min(en, st + int(fx.get("off", 999) * S.FPS)))
    # a prop shown for the whole beat
    pr = B.get("prop")
    if pr:
        t_ = pr["type"]
        if t_ == "prompt_card":
            card_at(f"prop{bi}", pr.get("game", "nhie"), pr["text"], st + 4, en - 6)
        elif t_ == "td_card":
            o = on_hud(props.td_card(f"prop{bi}", pr.get("kind", "dare"), pr["text"], (0, 0), 0.6), CARD_XY, CARD_S * 0.82)
            set_visible(o, False, 0); motion.card_flip_in(o, st + 4); motion.pop_out(o, en - 6, 5)
        elif t_ == "td_choice":
            o = on_hud(props.td_choice(f"prop{bi}", pr.get("player", "Riot"), (0, 0), 0.4, w=7.6, h=8.0), CHOICE_XY, CHOICE_S)
            set_visible(o, False, 0); motion.pop_in(o, st + 4, 7, 1.12, 4); motion.pop_out(o, en - 6, 5)
        elif t_ == "timer":
            o = on_hud(props.timer(f"prop{bi}", pr.get("seconds", 60), (0, 0), 0.5), (4.6, 7.2) if V else (16.0, 7.6), TS)
            set_visible(o, False, 0); motion.slam_in(o, st + 4); motion.pop_out(o, en - 6, 5)
        elif t_ == "phone":
            o = on_hud(props.phone(f"prop{bi}", None, (0, 0), 0.5, 2.6), CARD_XY, TS)
            set_visible(o, False, 0); motion.pop_in(o, st + 4); motion.pop_out(o, en - 6, 5)
        else:
            raise SystemExit(f"episode: unknown prop {t_!r} (prompt_card, td_card, td_choice, timer, phone)")

    # ---------- game moments ----------
    G = B["game"]
    if G:
        ev = {e.get("role"): e for e in B["events"] if e.get("role")}
        r = A(B, "riot")
        others = [w for w in B["cast"] if w != "riot"]
        if G["type"] in ("nhie", "mlt"):
            CA.cut(G["card_in"] - 2, framing(B, "wide", band=True))
            card_at(f"card{bi}", G["type"], G["prompt"], G["card_in"], G["card_out"])
            motion.present(r, G["card_in"] - 2, hold=G["read_end"] - G["card_in"])
            if C.get("riot_phone"):  # he reads the card off his real phone: left paw brings it up, then down again
                f0_, f1_ = G["card_in"] - 4, G["read_end"] + 8
                ph = props.phone(f"rphone{bi}", B["_inst"]["riot"]["c"].extras["hand-1"], (0.0, -0.55), 0.06, 0.75)
                set_visible(ph, False, 0)
                set_visible(ph, True, f0_)
                set_visible(ph, False, f1_ + 10)
                if B["location"] in ("stoop_night", "lake_night", "hall") or locations.PLATE_SETS.get(B["location"], {}).get("cast", ("", 0))[1] > 0.3:
                    gl = empty(f"phglow{bi}", B["_inst"]["riot"]["c"].extras["head"], (0, 1.2), 0.9)
                    glow(f"phglow{bi}_g", (0, 0), 2.2, 2.2, "#BFE0FF", 0.025, 16, gl, 0.0)  # the screen lights his face
                    set_visible(gl, False, 0)
                    set_visible(gl, True, f0_ + 6)
                    set_visible(gl, False, f1_)
                r.add(lambda fr, f0_=f0_, f1_=f1_: None if not (f0_ <= fr <= f1_ + 10) else {
                    "arm-1": motion.curve(fr, [(f0_, 10, "linear"), (f0_ + 7, 18, "back"), (f1_, 18, "linear"), (f1_ + 9, 10, "smooth")]),
                    "elbow-1": motion.curve(fr, [(f0_, 8, "linear"), (f0_ + 7, 92, "back"), (f1_, 92, "linear"), (f1_ + 9, 8, "smooth")]),
                    "hand-1": "fist" if f0_ + 3 <= fr <= f1_ + 6 else "paw"})
            busy(B, "riot", G["card_in"] - 2, G["read_end"] + 10)
            speak(B, ev["read"])
            tgt = G["target"]
            for w in B["cast"]:
                if w != tgt:
                    A(B, w).look(G["stare"] + (2 if w == "riot" else 0), side(B, w, tgt), 4)
                    A(B, w).expr(G["stare"] + 2, "suspicious")
            if G["type"] == "nhie":
                CA.push(G["stare"], G["stare"] + 14, framing(B, f"close:{tgt}"), "out")
                motion.nervous(A(B, tgt), G["stare"] - 10, ev["confess"]["start"] + 4)
                busy(B, tgt, G["stare"] - 10, ev["confess"]["end"])
                A(B, tgt).expr(ev["confess"]["start"], "nervous")
                speak(B, ev["confess"], listen=False)
                emote_jobs.append((B, tgt, "exclaim", G["stare"] + 4, ev["confess"]["start"] + 6))
            else:
                for w in B["cast"]:
                    if w != tgt:
                        motion.point_at(A(B, w), G["stare"] + (1 if w == "pip" else 0), int(side(B, w, tgt)),
                                        hold=max(20, G["laugh"] - G["stare"] - 14), expr="cocky")
                        busy(B, w, G["stare"], G["laugh"])
                motion.take(A(B, tgt), G["stare"] + 6, "shocked", 0.8)
                busy(B, tgt, G["stare"] + 6, G["stare"] + 36)
                CA.push(G["stare"] + 4, G["stare"] + 16, framing(B, f"close:{tgt}"), "out")
                CA.shake(G["stare"] + 4, 10, 0.3)
        elif G["type"] == "td":
            pl = G.get("player", "riot")
            CA.cut(G["choice_in"] - 2, framing(B, "wide", band=True))
            ch_ = on_hud(props.td_choice(f"choice{bi}", pl.capitalize(), (0, 0), 0.4, w=7.6, h=8.0), CHOICE_XY, CHOICE_S)
            set_visible(ch_, False, 0)
            motion.pop_in(ch_, G["choice_in"], 7, 1.12, 4)
            btn = bpy.data.objects[f"choice{bi}_{G.get('choice', 'dare')}"]
            for fr, v in ((G["tap"] - 1, 1.0), (G["tap"] + 1, 0.88), (G["tap"] + 4, 1.1), (G["tap"] + 8, 1.0)):
                btn.scale = (v, v, 1)
                btn.keyframe_insert("scale", frame=fr)
            fl = bpy.data.objects[ch_["flash"]]
            set_visible(fl, False, 0)
            set_visible(fl, False, G["choice_in"])
            if G.get("choice", "dare") == "dare":
                set_visible(fl, True, G["tap"])
                set_visible(fl, False, G["tap"] + 4)
            motion.pop_out(ch_, G["mystery"] - 1, 5)
            my = on_hud(props.mystery_card(f"myst{bi}", (0, 0), 0.5), CARD_XY, CARD_S * 0.82)
            set_visible(my, False, 0)
            motion.pop_in(my, G["mystery"], 6, 1.1, 3)
            set_visible(my, False, G["flip"])
            tc = on_hud(props.td_card(f"tdc{bi}", G.get("choice", "dare"), G["prompt"], (0, 0), 0.6), CARD_XY, CARD_S * 0.82)
            set_visible(tc, False, 0)
            motion.card_flip_in(tc, G["flip"])
            motion.pop_out(tc, G["card_out"], 5)
            speak(B, ev["choose"])
            CA.shake(G["tap"], 8, 0.3)
            speak(B, ev["read"])
            # the dare: the player goes all in, the room goes red, the friends react
            tint = locations.mood_tint(locs[B["location"]][0], "#B0102A", name=f"tint{bi}")
            set_visible(tint, False, 0)
            set_visible(tint, True, G["perform"] - 2)
            set_visible(tint, False, G["perform_end"] + 4)
            CA.push(G["card_out"], G["perform"] - 1, framing(B, f"close:{pl}"), "out")
            CA.shake(G["perform"] + 2, 12, 0.35)
            do_move(B, pl, "cheer", G["perform"], G["perform_end"])
            speak(B, ev["perform"], listen=False)
            for w in B["cast"]:
                if w != pl:
                    A(B, w).look(G["perform"], side(B, w, pl), 4)
                    if w == "pip":
                        do_move(B, w, "nervous", G["perform"], G["perform_end"])
                    elif w == "bash":
                        do_move(B, w, "take", G["perform"] + 3, G["perform_end"])
        elif G["type"] == "feature":  # the presenter shows the app; the real screenshot fills the frame
            pr_ = G.get("who", "riot")
            do_move(B, pr_, "present", G["screen_in"], ev["say"]["end"])
            speak(B, ev["say"])
            scr = on_hud(props.app_phone(f"screen{bi}", features.shot(G["feature"]), None, (0, 0), 0.8, 15.0 if V else 18.5),
                         (0.0, -0.4) if V else (0.0, 0.0), 1.0)
            set_visible(scr, False, 0)
            motion.pop_in(scr, G["screen_in"], 7, 1.06, 2)
            motion.pop_out(scr, G["screen_out"], 5)
        elif G["type"] == "alias":
            tm = on_hud(props.timer(f"timer{bi}", 60, (0, 0), 0.5), (4.6, 7.2) if V else (16.0, 7.6), TS)
            set_visible(tm, False, 0)
            motion.slam_in(tm, G["timer_in"])
            motion.pop_out(tm, G["card_out"], 5)
            card_at(f"card{bi}", "alias", G["word"], G["card_in"], G["card_out"])
            speak(B, ev["clue"])
            do_move(B, G["describer"], "present", ev["clue"]["start"], ev["clue"]["end"])
            speak(B, ev["guess"])
            mk = on_hud(props.mark(f"tick{bi}", "tick", (0, 0), 0.7, 1.1), (CARD_XY[0] + 3.0 * CARD_S, CARD_XY[1] - 2.4 * CARD_S), TS)
            set_visible(mk, False, 0)
            motion.slam_in(mk, G["tick"], start=1.7)
            motion.pop_out(mk, G["card_out"], 4)
            do_move(B, G["guesser"], "cheer", G["tick"], G["tick"] + 20)
        afters = [e for e in B["events"] if e["id"].startswith(f"{B['id']}_after")]
        for e in afters:  # follow-up lines: the camera goes to whoever speaks unless the line says otherwise
            speak(B, e)
            CA.push(e["start"] - 10, e["start"] - 1, framing(B, e.get("camera") or f"close:{e['who']}"), "out")
        if G["laughs"]:
            CA.cut(G["laugh"], framing(B, "wide"))
            for k, w in enumerate(["riot"] + others):
                motion.laugh(A(B, w), G["laugh"] + k * 3, G["laugh_end"] - 2)
                A(B, w).look(G["laugh"] + k * 3 + 4, 0.0, 6)
            cf = props.confetti(f"cf{bi}", (framing(B, "wide")[0], eye_y(B) + 6.6), 23, spread=4.5 if V else 8.0, seed=bi)
            set_visible(cf, False, 0)
            motion.burst(cf, G["laugh"] + 2, 30)
    elif B["mood"] == "party":
        cf = props.confetti(f"cf{bi}", (framing(B, "wide")[0], eye_y(B) + 6.6), 23, spread=4.5 if V else 8.0, seed=bi)
        set_visible(cf, False, 0)
        motion.burst(cf, max(st + 4, en - 46), 30)
    # word-by-word captions for every spoken line except card reads (the card shows them)
    for ev_ in B["events"]:
        if ev_.get("caption", True):
            CA.hud(props.word_captions(f"cap_{ev_['id']}", cam, motion.word_times(ev_["text"], vo(ev_["id"])), ev_["start"], y_px=1300)
                   if V else props.word_captions(f"cap_{ev_['id']}", cam, motion.word_times(ev_["text"], vo(ev_["id"])),
                                                 ev_["start"], fmt=F.fmt, y_frac=0.88 if S.SURFACE.get(B["location"]) and B["location"] in locations.PLATE_SETS else 0.8,
                                                 max_chars=22, size=1.45 * TS))  # painted sets: below the bodies

# bake every character over the frames its location is on screen
for I in inst.values():
    f0 = min(C["beats"][b]["start"] for b in I["beats"]) - 2
    f1 = max(C["beats"][b]["end"] for b in I["beats"]) + 2
    f0, f1 = max(0, f0, R0 - WARM), min(END, f1, R1 + 2)
    if f0 < f1:
        I["a"].bake(f0, f1)
for B, who, kind, f_in, f_out in emote_jobs:
    hx, hy_ = head_xy(B, who, f_in)
    e = props.emote(f"em_{who}_{f_in}", kind, (hx + 0.2, hy_ + 3.0), 22, 1.0)
    set_visible(e, False, 0)
    motion.pop_in(e, f_in, 6)
    motion.pop_out(e, f_out, 4)

# ---------- ending ----------
EX = -SPACING
if C.get("ending") == "porch_light":
    # Porchlight: the porch light on the stoop at night, a beat, click: off. Black. A small Friendzy logo.
    PL = locations.plate("stoop_night")
    PL.root.location.x = EX
    lx, ly = locations.plate_xy("stoop_night", 994, 176)
    CA.cut(C["end"], (EX + 5.4, ly - 1.0, 7.5))
    P = S.PORCH
    lit = empty("porch_lit", None, (EX + lx, ly), 9.0)
    glow("porch_glow", (0, 0), 2.6, 2.6, "#FFC861", 0.022, 40, lit, 0.0)
    light("porch_pool", ell(*locations.plate_xy("stoop_night", 840, 450), 3.6, 1.1), "#FFC861", 0.1, PL.root, 9.1)
    pool = bpy.data.objects["porch_pool"]
    for o, off_at in ((lit, P["click"]), (pool, P["click"])):
        set_visible(o, True, 0)
        set_visible(o, False, C["end"] + off_at)
    blk = shape("porch_black", rect(EX - 20, -20, EX + 30, 30), OFFBLACK, None, 40.0, ol=0, smooth=0)
    set_visible(blk, False, 0)
    set_visible(blk, True, C["end"] + P["black"])
    icon = os.path.join(HERE_T, "../../Friendzy/Assets.xcassets/AppIcon.appiconset/1528a01b-6704-40f9-86b2-ed364e164cf4.png")
    logo = img("porch_logo", icon, None, (512, 512), 1024 / 1.1, 41.0, loc=(EX + 5.4, ly - 1.0))
    set_visible(logo, False, 0)
    motion.pop_in(logo, C["end"] + P["logo"], 8, 1.08, 3)
else:
    nxt = f"Next episode: {C['next']}" if C.get("next") else f"{C['series']}"
    props.end_card("end", nxt, (EX, 9.0), -5, fmt=F.fmt, line2=f"{C['series']} · free on Friendzy")
    er = cast.riot()
    er.root.location = (EX, -12.5, 2) if V else (EX + 10.5, -15.5, 2)
    er.root.scale = (1.15, 1.15, 1) if V else (1.75, 1.75, 1)
    ea = motion.Anim(er)
    ea.expr(0, "hype")
    motion.talk(ea, C["end_vo"], vo("end"), text=[t for i, _, t in S.lines(cfg) if i == "end"][0])
    mid = (C["end"] + END) // 2
    motion.wave(ea, C["end"] + 4, mid - 2, side=-1)
    motion.thumbs_up(ea, mid, hold=max(8, END - mid - 10))
    ea.add(lambda fr: {"y": 7.0 * motion.curve(fr, [(C["end"], 0, "linear"), (C["end"] + 8, 1.0, "back")]) / 1.15})
    if R1 >= C["end"] - 1:
        ea.bake(max(C["end"] - 1, R0 - WARM), END)
    for i in range(8):
        l = bpy.data.objects[f"end_l{i}"]
        set_visible(l, False, 0)
        motion.pop_in(l, C["end"] + 2 + i * 2, 5, 1.3, 8)
    for n_ in ("end_sub", "end_sub2"):
        sub = bpy.data.objects[n_]
        set_visible(sub, False, 0)
        motion.pop_in(sub, C["end"] + (16 if n_ == "end_sub" else 22), 6)

CA.bake(max(0, R0 - 2), min(END, R1 + 2))
# parallax per location: far layers trail the camera while it's on that set
for n, (L, off, base) in locs.items():
    x0, y0, _ = L.cam if V else L.cam_h
    for o, fac in L.parallax:
        for fr in range(max(0, R0 - 2), min(END, R1 + 2) + 1):
            x, y, _ = CA._at(fr)
            here = abs(x - off) < SPACING / 2
            o.location = base[o] + (Vector(((x - off - x0) * (1 - fac), (y - y0) * (1 - fac), 0)) if here else Vector((0, 0, 0)))
            o.keyframe_insert("location", frame=fr)

if os.environ.get("SAVE_BLEND", "1") != "0":
    bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, "scene.blend"))
frames = os.environ.get("FRAMES")
if frames:
    for fr in map(int, frames.split(",")):
        still(sc, os.path.join(OUT, "stills", f"s_{fr:04d}.png"), fr)
else:
    rng = os.environ.get("FRAME_RANGE")
    if rng:
        a_, b_ = map(int, rng.split("-"))
        sc.frame_start, sc.frame_end = a_, b_
    sc.frame_step = int(os.environ.get("FRAME_STEP", "1"))
    sc.render.filepath = os.path.join(OUT, "frames", "f_")
    bpy.ops.render.render(animation=True)
