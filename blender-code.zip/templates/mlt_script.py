# "Most Likely To" in the Road Trip car. Rocco is asleep in the back; Riot reads the card; everyone points
# at Rocco at once; he wakes up denying it; Pip calls him out; everyone laughs.
#   python3 make.py mlt --name mlt_car_01
FPS = 30
STANDALONE = True
FORMATS = ("vertical", "horizontal")  # make.py --format
TITLE = "Most Likely To"
HOOK = "4 people. 1 answer.\n0 hesitation."
PROMPT = "Most likely to fall asleep the second they sit down."  # real prompt from the app

SCRIPT = [  # id, speaker, line, pause before (frames)
    ("riot_q", "riot", "Okay. Who's most likely to fall asleep the second they sit down?", 14),
    ("rocco_wake", "rocco", "Mm... what? I was resting my eyes.", 30),   # gap = the beat + everyone pointing
    ("pip_call", "pip", "You were SNORING!", 6),
]


def hook(cfg):
    return cfg.get("hook") or HOOK


def lines(cfg):
    return [(i, w, t) for i, w, t, _ in SCRIPT] + [("riot_end", "riot", f"{TITLE}. Free on Friendzy.")]


def timeline(cfg, dur):
    f = lambda s: int(round(s * FPS))
    s = lambda fr: round(fr / FPS, 3)
    c, t = {}, 0
    for i, who, text, gap in SCRIPT:
        t += gap
        c[i] = t
        t += f(dur[i])
        c[i + "_end"] = t
    c["point"] = c["riot_q_end"] + 8
    c["laugh"] = c["pip_call_end"] + 2
    c["end"] = c["laugh"] + 46
    c["end_vo"] = c["end"] + 4   # short end card: Riot speaks almost at once
    c["END"] = c["end_vo"] + f(dur["riot_end"]) + 10
    c["voices"] = [[i, s(c[i])] for i, *_ in SCRIPT] + [["riot_end", s(c["end_vo"])]]
    c["sfx"] = [
        ["card_flip", s(c["riot_q"] + 6), 0.6], ["pop", s(c["riot_q"] + 10), 0.35],
        ["whoosh", s(c["point"] - 2), 0.5], ["slam", s(c["point"] + 4), 0.25],
        ["slide_up", s(c["rocco_wake"] - 6), 0.3], ["boing", s(c["rocco_wake"] - 4), 0.3],
        ["popper", s(c["laugh"] + 2), 0.45],
        ["sting_fanfare", s(c["end"]), 0.45],
    ]
    c["ambience"] = [["road", 0.0, 0.18]]
    c["music"] = ["hype", 0.0, 0.16, s(c["point"] - 4), s(c["rocco_wake"] + 4)]
    return c
