# Blender scene for "Trivia" on the game-show stage (trivia_script.py).
#   Blender --background --python trivia_scene.py -- <video dir>
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import joke
from joke import *
import trivia_script as S

J = joke.Joke(S, locations.game_show, {"bash": None, "pip": None, "riot": "host", "rocco": None})
C, A = J.C, J.A
r, b, p, k_ = A["riot"], A["bash"], A["pip"], A["rocco"]
loc = J.loc

for who in A:
    A[who].expr(0, "happy")
r.expr(0, "hype")
J.ch["riot"].pose("mic")
# Riot asks, mic up; the contestants lean in
J.talk("riot", "riot_q")
J.listen_all("riot", "riot_q")
for k, fr in enumerate(loc.extras["bulbs"]):  # chase lights on the sign
    for f0 in range(0, J.END, 8):
        set_visible(fr, (k + f0 // 8) % 2 == 0, f0)

# Bash slams his buzzer: wrong
b.expr(C["buzz"] - 2, "hype")
b.add(lambda fr: None if not (C["buzz"] - 8 <= fr <= C["buzz"] + 12) else {
    "arm1": motion.curve(fr, [(C["buzz"] - 8, 10, "linear"), (C["buzz"] - 3, 70, "out"), (C["buzz"], 18, "in"), (C["buzz"] + 12, 10, "smooth")]),
    "elbow1": motion.curve(fr, [(C["buzz"] - 8, 8, "linear"), (C["buzz"] - 3, 60, "out"), (C["buzz"], 40, "in"), (C["buzz"] + 12, 8, "smooth")]),
    "hand1": "open", "y": motion.curve(fr, [(C["buzz"] - 3, 0.2, "out"), (C["buzz"], -0.1, "in"), (C["buzz"] + 6, 0, "smooth")])})
bz = loc.extras["buzzers"][J.seat["bash"]]
for fr, v in ((C["buzz"] - 1, 1.0), (C["buzz"] + 1, 0.7), (C["buzz"] + 5, 1.08), (C["buzz"] + 9, 1.0)):
    bz.scale = (1, v, 1)
    bz.keyframe_insert("scale", frame=fr)
J.talk("bash", "bash_buzz", energy=1.3)
J.listen_all("bash", "bash_buzz", skip=("riot",))
r.look(C["wrong"], J.side("riot", "bash") * 0.7, 5)
r.expr(C["wrong"], "cocky")
motion.shrug(r, C["wrong"] + 2, hold=14)

# Pip, barely audible: right
p.expr(C["pip_answer"] - 4, "nervous")
J.talk("pip", "pip_answer", energy=0.8)
for who in ("bash", "rocco", "riot"):
    A[who].look(C["pip_answer"] - 2, J.side(who, "pip"), 5)
p.expr(C["right"] + 2, "hype")
motion.cheer(p, C["right"] + 2, hold=18)
motion.take(b, C["right"] + 4, "shocked", 0.8)
scr = loc.extras["screens"]
for i, who in enumerate(("bash", "pip", None, "rocco")):
    if who is None:
        continue
    zero = text(f"score{i}_0", "0", 0.8, YELLOW, scr[i], (0, -0.03), 0.01)
    set_visible(zero, True, 0)
    if who == "pip":
        one = text(f"score{i}_1", "1", 0.8, YELLOW, scr[i], (0, -0.03), 0.01)
        set_visible(one, False, 0)
        set_visible(one, True, C["right"] + 6)
        set_visible(zero, False, C["right"] + 6)

# Bash protests, then the twist
b.expr(C["bash_no"] - 2, "yelling")
J.talk("bash", "bash_no", energy=1.3)
motion.yell(b, C["bash_no"], C["bash_no_end"], 1)
for who in ("pip", "rocco", "riot"):
    A[who].look(C["bash_no"] - 2, J.side(who, "bash"), 5)
b.expr(C["bash_twist"] - 4, "happy")
b.look(C["bash_twist"] - 4, 0.0, 8)  # gazes into the distance
b.add(lambda fr: None if not (C["bash_twist"] - 4 <= fr <= C["bash_twist_end"]) else {"head_rot": 8 * motion.envelope(fr, C["bash_twist"] - 4, C["bash_twist_end"], 6)})
J.talk("bash", "bash_twist", energy=0.7)
k_.expr(C["bash_twist"] + 6, "side_eye_l")
J.munch(C["pip_answer"] + 4, 2)
J.laugh_all(C["laugh"], C["end"] - 2)

# ---- camera + graphics ----
if J.V:
    CA = J.camera("wide", band=True)
    CARD = dict(vxy=(0.0, J.F.hud_y(0.34)), s=0.85)
else:  # 16:9: the contestants slide left, the question takes the right third
    start = (loc.cam_h[0] + 5.0, loc.cam_h[1] + 2.0, 18.0)
    CA = J.camera("wide")
    CA.keys = [(-999, start, "linear")]
    CA.intro()
    CARD = dict(hxy=(12.8, 0.6), s=0.8)
# while the question is up the camera stays on the whole stage (a slow creep), so the card never covers a face
x0, y0, o0 = CA._at(C["card_in"])
CA.push(C["card_in"], C["card_out"] - 2, (x0, y0 - 0.25, o0 * 0.95), "smooth")
CA.shake(C["buzz"], 8, 0.3)
CA.shake(C["right"], 6, 0.15)
CA.push(C["card_out"], C["bash_no"] - 1, J.frame("close:bash"), "out")
CA.cut(C["laugh"], J.frame("wide"))
J.hook(C["card_in"] - 4)
card = J.card(props.trivia_card("q", S.QUESTION, S.OPTIONS, (0, 0), 0.6), C["card_in"], C["card_out"], **CARD)
for i in range(4):  # after the card's flip keys (they show every child): highlights off, then the two that matter
    for kind in ("good", "bad"):
        o = bpy.data.objects[f"q_{kind}{i}"]
        set_visible(o, False, 0)
        set_visible(o, False, C["card_in"])
        if (kind, i) in (("bad", S.BASH_PICK), ("good", S.CORRECT)):
            set_visible(o, True, C["wrong"] if kind == "bad" else C["right"])
J.captions(["bash_buzz", "pip_answer", "bash_no", "bash_twist"], y_px=1400)
J.confetti(C["laugh"] + 2)
J.finish(S.TITLE, "host")
