# "Trivia" on the game-show stage, Riot hosting in his sparkle blazer with the mic.
# Beats (the app's real flow: a question with A-D, tap an answer, right/wrong feedback, score): Riot asks a real app
# question -> Bash buzzes in, sure of himself, wrong (red) -> Pip quietly gets it right (yellow, +1) -> Bash protests
# -> his twist -> laugh -> end card.
#   python3 make.py trivia --name trivia_unicorn_01 [--format horizontal]
from jokecues import end_cues, sequence

FPS = 30
STANDALONE = True
FORMATS = ("vertical", "horizontal")
TITLE = "Trivia"
HOOK = "bash was SO sure"
# real question from the app (Friendzy/Models/GamePromptExtra*.swift), with its options and correct index
QUESTION = "What is the national animal of Scotland?"
OPTIONS = ["Stag", "Red squirrel", "Unicorn", "Golden eagle"]
CORRECT, BASH_PICK = 2, 0

SCRIPT = [  # id, speaker, line, pause before (frames)
    ("riot_q", "riot", QUESTION, 14),
    ("bash_buzz", "bash", "STAG! Obviously!", 12),
    ("pip_answer", "pip", "...Unicorn?", 22),
    ("bash_no", "bash", "Unicorns aren't REAL!", 16),
    ("bash_twist", "bash", "...I'm moving to Scotland.", 18),
]


def hook(cfg):
    return (cfg.get("hook") or HOOK).replace("\\n", "\n")


def lines(cfg):
    return [(i, w, t) for i, w, t, _ in SCRIPT] + [("riot_end", "riot", f"{TITLE}. Free on Friendzy.")]


def timeline(cfg, dur):
    f = lambda s: int(round(s * FPS))
    s = lambda fr: round(fr / FPS, 3)
    c = {}
    sequence(c, dur, f, SCRIPT)
    c["card_in"] = 40
    c["buzz"] = c["bash_buzz"] - 4
    c["wrong"] = c["bash_buzz_end"] + 2
    c["right"] = c["pip_answer_end"] + 2
    c["card_out"] = c["bash_no"] - 10
    c["laugh"] = c["bash_twist_end"] + 4
    end_cues(c, dur, f)
    c["voices"] = [[i, s(c[i])] for i, *_ in SCRIPT] + [["riot_end", s(c["end_vo"])]]
    c["sfx"] = [
        ["sparkle", s(1 / 30), 0.4], ["card_flip", s(c["card_in"]), 0.6], ["pop", s(c["card_in"] + 4), 0.3],
        ["slam", s(c["buzz"]), 0.3], ["tap", s(c["buzz"]), 0.6], ["buzzer", s(c["wrong"]), 0.45],
        ["ting", s(c["right"]), 0.55], ["sparkle", s(c["right"] + 3), 0.45], ["stamp", s(c["right"] + 8), 0.25],
        ["scratch", s(c["bash_twist"] - 6), 0.35],
        ["popper", s(c["laugh"] + 2), 0.5], ["sting_fanfare", s(c["end"]), 0.45],
    ]
    c["ambience"] = []
    c["music_segments"] = [["hype", 0.0, s(c["END"]), 0.15, [[s(c["bash_twist"] - 8), s(c["bash_twist_end"])]]]]
    return c
