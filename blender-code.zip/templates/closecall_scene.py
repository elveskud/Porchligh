# Blender scene for "Close Call" in the Party Room (closecall_script.py).
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import joke
from joke import *
import closecall_script as S

J = joke.Joke(S, locations.party_room, {"bash": None, "pip": None, "riot": None, "rocco": None})
C, A = J.C, J.A
r, b, p, k_ = A["riot"], A["bash"], A["pip"], A["rocco"]
loc = J.loc
loc.extras["code"].data.body = "???"
for who in A:
    A[who].expr(0, "happy")
    ph = J.hold_phone(who, 0, C["laugh"] - 2, side=1 if who == "rocco" else -1)
    for k in range(3):
        fr = C["type"] + k * 9 + J.seat[who] * 2
        for f_, v in ((fr, 1.0), (fr + 2, 1.08), (fr + 5, 1.0)):
            ph.scale = (v, v, 1)
            ph.keyframe_insert("scale", frame=f_)
r.expr(0, "hype")
motion.present(r, C["card_in"] - 2, hold=C["riot_q_end"] - C["card_in"], side=-1)
J.talk("riot", "riot_q")
J.listen_all("riot", "riot_q")
b.expr(C["bash_g"] - 2, "yelling")
J.talk("bash", "bash_g", energy=1.4)
motion.cheer(b, C["bash_g"] + 2, hold=10)
k_.expr(C["rocco_g"] - 2, "side_eye_l")
J.talk("rocco", "rocco_g")
p.expr(C["pip_g"] - 2, "nervous")
J.talk("pip", "pip_g", energy=0.8)
for who in A:  # everyone turns to the TV for the answer, then to Pip
    A[who].look(C["answer"] - 14, 0.0, 6)
for who in ("bash", "riot", "rocco"):
    A[who].look(C["answer"] + 8, J.side(who, "pip"), 4)
    motion.take(A[who], C["answer"] + 10, "shocked", 0.8)
p.expr(C["pip_read"] - 4, "cocky")
J.talk("pip", "pip_read", energy=0.8)
motion.shrug(p, C["pip_read"] + 2, hold=14)
J.laugh_all(C["laugh"], C["end"] - 2, order=("riot", "pip", "bash", "rocco"))
# the answer on the TV
tv = loc.extras["tv"]
ans = text("tv_ans", S.ANSWER, 2.4, YELLOW, tv, (0, -0.5), 0.03)
lab = text("tv_lab", "THE ANSWER", 0.75, CHALK, tv, (0, 1.2), 0.03)
for o in (ans, lab):
    set_visible(o, False, 0)
    set_visible(o, True, C["answer"])
for o in (bpy.data.objects["pr_tv_t"], loc.extras["code"]):
    set_visible(o, True, 0)
    set_visible(o, False, C["answer"])
# camera + graphics
CA = J.camera("wide", band=True)
CA.cut(C["card_out"], J.frame("wide"))
CA.cut(C["answer"] - 16, J.frame("wide", band=True))
CA.shake(C["answer"], 8, 0.3)
CA.push(C["answer"] + 12, C["pip_read"] - 1, J.frame("close:pip"), "out")
CA.cut(C["laugh"], J.frame("wide"))
J.hook(C["card_in"] + 26)
J.card(props.prompt_card("q", "trivia", S.QUESTION, (0, 0), 0.6, w=10.4, size=0.8), C["card_in"] + 30, C["card_out"],
       vxy=(0.0, J.F.hud_y(0.36)))
bpy.data.objects["q_hdr"].data.body = "CLOSE CALL"
order = {w: g for w, g in S.GUESSES}
for k, who in enumerate(("bash", "rocco", "pip")):  # each guess pops up as it's said; Riot's sits quietly
    pl = props.pill(f"g_{who}", order[who], (J.X[who], J.eye(who) + 3.0 + 1.3 * (J.seat[who] % 2)), 22, bg=OFFBLACK,
                    fg=YELLOW if who == "pip" else CHALK, size=0.85)
    set_visible(pl, False, 0)
    motion.pop_in(pl, C[f"{who}_g"], 6)
    motion.pop_out(pl, C["laugh"] - 4, 4)
pr = props.pill("g_riot", order["riot"], (J.X["riot"], J.eye("riot") + 3.0), 22, size=0.85)
set_visible(pr, False, 0)
motion.pop_in(pr, C["pip_g"] + 6, 6)
motion.pop_out(pr, C["laugh"] - 4, 4)
star = props.emote("win", "sparkle", (J.X["pip"] + 1.6, J.eye("pip") + 3.4), 23, 0.9)
set_visible(star, False, 0)
motion.pop_in(star, C["answer"] + 4, 6)
motion.pop_out(star, C["laugh"], 4)
J.captions(["riot_q", "bash_g", "rocco_g", "pip_g", "pip_read"], y_px=1400)
J.confetti(C["laugh"] + 2)
J.finish(S.TITLE)
