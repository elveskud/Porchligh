# Blender scene for "How to play Alias" (alias_script.py) in Game Night HQ (day), coach Riot hosting.
#   Blender --background --python alias_scene.py -- <video dir> [FRAMES=10,200 for stills]
import os, sys, json
HERE_T = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE_T, "../characters"))
sys.path.insert(0, HERE_T)
from toon import *
import cast, props, locations, motion, layout
import alias_script as S

OUT = sys.argv[sys.argv.index("--") + 1]
cfg = json.load(open(os.path.join(OUT, "config.json")))
C = json.load(open(os.path.join(OUT, "cues.json")))
END = C["END"]
vo = lambda i: os.path.join(OUT, "vo", f"{i}.wav")
text_of = {i: t for i, _, t in S.lines(cfg)}
beats = lambda i: [C[i] + e for e in motion.phrase_ends(vo(i))]

LF = layout.from_cfg(cfg)  # (not "F": the timer code below loops with F)
V = LF.vertical  # the 9:16 numbers below are the original ones; 16:9 has its own framing and HUD spots
TS = LF.text_scale
sc = reset()
LF.setup(sc, OFFBLACK)
sc.frame_start, sc.frame_end = 0, END

# ---------- set & cast: Pip sits next to Rocco (her guesser), Riot coaches from seat 1 ----------
loc = locations.living_room("day")
if not V:
    locations.widen(loc)
seat = {"bash": 0, "riot": 1, "pip": 2, "rocco": 3}
ch = {"bash": cast.bear(), "riot": cast.riot("coach"), "pip": cast.bunny(), "rocco": cast.raccoon()}
for k, c in ch.items():
    loc.seat(c, seat[k])
set_visible(ch["pip"].extras["sweat"], False)
A = {k: motion.Anim(c) for k, c in ch.items()}
X = {k: loc.seats[seat[k]][0] for k in ch}
r, b, p, k_ = A["riot"], A["bash"], A["pip"], A["rocco"]
side_to = lambda who, at: 1.0 if X[at] > X[who] else -1.0


def listen_all(speaker, line, skip=()):
    for who, a in A.items():
        if who != speaker and who not in skip:
            a.look(C[line] - 4, side_to(who, speaker), 6)
            motion.listen(a, C[line] + 2, C[line + "_end"] + 4, side_to(who, speaker), beats(line))


def munch(a, f, n=2):
    """Rocco: chips up to the mouth and back, n times (left paw holds the bag)."""
    keys = [(f, 8, "linear")]
    for i in range(n):
        keys += [(f + 6 + i * 10, -128, "back"), (f + 11 + i * 10, -95, "smooth")]
    keys.append((f + 12 + n * 10, 8, "smooth"))
    a.add(lambda fr: None if not (f <= fr <= keys[-1][0]) else
          {"arm-1": -8, "hand-1": "fist", "elbow-1": motion.curve(fr, keys)})


for a in A.values():
    a.expr(0, "happy")
r.expr(0, "hype")

# hook: Bash is already mid-yell, Riot whistles him down
motion.yell(b, 0, 24, side=1)
motion.whistle(r, C["whistle1"], side=-1, dur=12)
p.look(4, -1.0, 4)
k_.look(6, -0.6, 5)
# 1. Riot: the rule
r.look(C["riot_intro"] - 2, 0.0, 6)
motion.talk(r, C["riot_intro"], vo("riot_intro"), text=text_of["riot_intro"])
motion.present(r, C["riot_intro"] + 20, hold=26)
listen_all("riot", "riot_intro")
# 2. Bash's turn: ASTRONAUT... "An ASTRO-"
b.expr(C["bash_astro"] - 4, "hype")
motion.hop(b, C["bash_astro"] + 2, 0.4)  # "Easy!"
motion.talk(b, C["bash_astro"], vo("bash_astro"), energy=1.3, text=text_of["bash_astro"])
b.expr(C["bash_astro_end"] - 18, "yelling")
listen_all("bash", "bash_astro")
# whistle! skip
motion.whistle(r, C["whistle2"], side=-1, dur=12, point=False)  # "stop!" palm: Bash's face stays visible
motion.take(b, C["whistle2"] + 2, "shocked", 0.6)
p.look(C["whistle2"] + 2, -1.0, 4)
k_.look(C["whistle2"] + 4, -1.0, 4)
r.expr(C["riot_skip"], "cocky")
motion.talk(r, C["riot_skip"], vo("riot_skip"), text=text_of["riot_skip"])
motion.shrug(r, C["riot_skip"] + 6, hold=16)
motion.facepalm(b, C["riot_skip"] + 4, hold=22)
# 3. Pip's turn: BEEKEEPER; Rocco answers without even looking up
p.expr(C["turn2"], "nervous")
p.look(C["turn2"] + 2, 1.0, 6)
r.look(C["turn2"], 1.0, 6)
b.look(C["turn2"] + 4, 1.0, 6)
b.expr(C["turn2"] + 4, "suspicious")
motion.talk(p, C["pip_bee"], vo("pip_bee"), text=text_of["pip_bee"])
k_.look(C["turn2"], 0.0, 6)
munch(k_, C["pip_bee"] - 6, 2)
k_.expr(C["rocco_bee"] - 2, "side_eye_l")
motion.talk(k_, C["rocco_bee"], vo("rocco_bee"), text=text_of["rocco_bee"])
motion.double_take(p, C["rocco_bee"] - 12, 1.0)
p.expr(C["tick1"] + 2, "hype")
motion.hop(p, C["tick1"] + 2, 0.5)
k_.expr(C["tick1"] + 6, "happy")
# 4. Riot: tick or skip
r.look(C["riot_rules"] - 4, 0.0, 6)
r.expr(C["riot_rules"], "hype")
motion.talk(r, C["riot_rules"], vo("riot_rules"), text=text_of["riot_rules"])
motion.thumbs_up(r, C["rule_tick"] - 4, hold=12)
motion.shrug(r, C["rule_cross"] - 3, hold=12)
listen_all("riot", "riot_rules", skip=("rocco",))
munch(k_, C["riot_rules"], 2)
# 5. speed round: every card, Rocco answers before Pip can open her mouth
p.look(C["speed"][0] - 4, 1.0, 5)
r.look(C["speed"][0] - 2, 1.0, 6)
b.look(C["speed"][0], 1.0, 6)
for n, (fl, tk) in enumerate(zip(C["speed"], C["speed_tick"])):
    gid = f"rocco_g{n + 1}"
    p.expr(fl + 2, "happy")
    motion.talk(k_, C[gid], vo(gid), text=text_of[gid])
    p.expr(tk, "hype")
    if n < len(C["speed"]) - 1:
        motion.hop(p, tk, 0.4 + 0.1 * n)
k_.expr(C["speed"][0], "side_eye_l")
motion.take(b, C["speed_tick"][1], "shocked", 0.5)
b.expr(C["speed_tick"][1] + 20, "suspicious")
motion.take(r, C["speed_tick"][-1], "shocked", 0.5)
motion.cheer(p, C["speed_tick"][-1], hold=10)
# 6. buzzer, "Time! Most points wins!", scoreboard 5-0
for who in ("pip", "rocco", "bash"):
    A[who].look(C["time_up"] + 2, side_to(who, "riot"), 5)
r.look(C["time_up"], 0.0, 5)
r.expr(C["riot_time"], "hype")
motion.talk(r, C["riot_time"], vo("riot_time"), text=text_of["riot_time"])
motion.present(r, C["score"] - 2, hold=28)
r.expr(C["riot_time_end"], "laughing")
k_.expr(C["score"], "happy")
motion.shrug(k_, C["score"] + 4, hold=16)
b.expr(C["time_up"] + 2, "shocked")
b.look(C["score"] + 2, 0.0, 6)
# 7. "I was SO close!" and the laugh (Bash laughs too)
b.expr(C["bash_close"] - 2, "yelling")
motion.talk(b, C["bash_close"], vo("bash_close"), energy=1.2, text=text_of["bash_close"])
for who in ("riot", "pip", "rocco"):
    A[who].look(C["bash_close"] - 4, side_to(who, "bash"), 5)
for who, off in (("riot", 0), ("pip", 4), ("bash", 6), ("rocco", 9)):
    motion.laugh(A[who], C["laugh"] + off, C["end"] - 2)
    A[who].look(C["laugh"] + off + 4, 0.0, 6)
for a in A.values():
    a.bake(0, END)

# ---------- camera ----------
wide = loc.cam if V else loc.cam_h
cam = LF.camera(sc, *wide)
CA = motion.CamAnim(cam, wide, loc.parallax)
EYE = 8.4  # seated eye line (world y); framed ~1000px down so captions (1320px) and cards (above) stay off faces
if V:
    frame_ = lambda x, o, px=1000: (x, EYE - (0.5 - px / 1920) * o, o)  # eye line `px` down a 1920 frame
    bash_two = frame_((X["bash"] + X["riot"]) / 2, 18.0)
    pip_two = frame_((X["pip"] + X["rocco"]) / 2 + 0.2, 18.0)
    riot_one = frame_(X["riot"] + 0.3, 17.0)
    speed = frame_(0.6, 22.0)
    bash_one = frame_(X["bash"] + 0.8, 16.0, 860)  # no card up: sit him higher, clear of the captions
else:  # 16:9: two-shots and singles whose edges fall between characters; cards on the right of the band
    # wider than a true close-up and the eye line lower, so the card group (right of the band) clears the heads
    bash_two = LF.clean_span(loc, [seat["bash"], seat["riot"]], EYE, 0.62, min_ortho=10.0)
    pip_two = LF.clean_span(loc, [seat["pip"], seat["rocco"]], EYE, 0.62, min_ortho=10.0)
    riot_one = LF.clean_span(loc, [seat["riot"]], EYE, 0.62, min_ortho=10.0)
    speed = LF.eye_framing(loc.cam_h[0], EYE, 13.5, 0.62)
    bash_one = LF.clean_close(loc, seat["bash"], 7.5, EYE, 0.46)
CA.intro()
CA.shake(C["whistle1"] + 2, 8, 0.25)                                         # the timer slams in
CA.push(C["riot_intro_end"] + 2, C["bash_astro"] - 1, bash_two, "out")       # every move lands before the line
CA.shake(C["cross1"], 10, 0.3)
CA.push(C["riot_skip_end"] + 2, C["pip_bee"] - 1, pip_two, "out")
CA.push(C["rocco_bee_end"] + 4, C["riot_rules"] - 1, riot_one, "out")
CA.push(C["riot_rules_end"] + 2, C["speed"][0] - 1, speed, "out")
CA.push(C["warn"], C["time_up"], frame_(0.6, 20.0) if V else LF.eye_framing(loc.cam_h[0], EYE, 12.8, 0.62), "in")  # the last 10 seconds creep in
CA.shake(C["score"], 10, 0.35)
CA.push(C["bash_close"] - 10, C["bash_close"] - 1, bash_one, "out")
CA.cut(C["laugh"], wide)
EX = 100.0
CA.cut(C["end"], (EX, 9.0, 22.0))

# ---------- on-screen graphics: a camera-attached layer built at ortho 22 (x +-6.2, y +-11) ----------
hud = empty("hud", cam, (0, 0), -8)
CA.hud(hud)
def on_hud(o, xy, hxy=None):
    if V:
        o.parent = hud
        o.location = (xy[0], xy[1], o.location.z)
        return o
    # 16:9: the 9:16 card group (centred, x +-6) moves to the right of the band; a holder carries the size so the
    # props' own pop/slam keys (on their scale) stay 0..1
    xy = hxy or (11.6 + xy[0] * 1.1, 4.6 + (xy[1] - 2.9) * 0.95)
    holder = empty(o.name + "_at", hud, xy, o.location.z)
    holder.scale = (1.15, 1.15, 1) if not hxy else (TS, TS, 1)
    o.parent = holder
    o.location = (0, 0, 0)
    return o

hook = on_hud(props.caption_box("hook", S.hook(cfg), (0, 0), 1.0, w=9.0, size=0.95), (-1.1, 7.05), (-10.2, 8.2))  # left of the timer
set_visible(hook, False, 0)
motion.pop_in(hook, 1, 6, 1.1, 2)
motion.pop_out(hook, C["card1"] - 6, 5)

CARD_XY, MARK_XY = (-0.6, 5.0), (2.3, 2.9)
def word_card(name, word, f_in, f_out):
    card = on_hud(props.prompt_card(name, "alias", word, (0, 0), 0.4, w=6.8, size=1.25), CARD_XY)
    set_visible(card, False, 0)
    motion.card_flip_in(card, f_in)
    motion.pop_out(card, f_out, 5)

def mark_at(name, kind, f_in, f_out, xy=MARK_XY, r_=1.1, slam=True):
    m = on_hud(props.mark(name, kind, (0, 0), 0.7, r_), xy)
    set_visible(m, False, 0)
    if slam:
        motion.slam_in(m, f_in, start=1.7)  # smaller than a stamp: never covers the faces below
    else:
        motion.pop_in(m, f_in)
    motion.pop_out(m, f_out, 4)
    return m

def plus_one(name, f):
    o = on_hud(props.pill(name, "+1", (0, 0), 0.8, bg=props.CATEGORY["social"][0], fg="#FFFFFF", size=0.9), (-3.4, 2.9))  # left of the card, away from the timer
    set_visible(o, False, 0)
    motion.pop_in(o, f, 5)
    motion.float_up(o, f + 5, f + 26, 1.2)

word_card("card1", S.TURN1, C["card1"], C["turn2"] - 6)
mark_at("x1", "cross", C["cross1"], C["turn2"] - 6)
word_card("card2", S.TURN2, C["turn2"], C["riot_rules"] - 6)
mark_at("t1", "tick", C["tick1"], C["riot_rules"] - 6)
plus_one("p1", C["tick1"] + 4)
mark_at("rt", "tick", C["rule_tick"], C["riot_rules_end"] + 2, (-4.0, 3.4), 1.4, False)
mark_at("rx", "cross", C["rule_cross"], C["riot_rules_end"] + 2, (4.0, 3.4), 1.4, False)
for n, (fl, tk) in enumerate(zip(C["speed"], C["speed_tick"])):
    f_out = C["speed"][n + 1] - 3 if n < len(C["speed"]) - 1 else C["time_up"] + 4
    word_card(f"cs{n}", S.SPEED[n], fl, f_out)
    mark_at(f"ts{n}", "tick", tk, f_out)
    plus_one(f"ps{n}", tk + 3)
board = on_hud(props.scoreboard("board", S.SCORES, (0, 0), 0.9), (-0.3, 5.0))  # above the heads
set_visible(board, False, 0)
motion.slam_in(board, C["score"])
motion.pop_out(board, C["bash_close"] - 4, 5)

# timer badge: one text per number shown; it turns red for the last 10 and pulses on every tick
tm = on_hud(props.timer("tm", 60, (0, 0), 0.5), (4.6, 5.3), (17.4, 8.6))  # 16:9: top-right of the band
set_visible(tm, False, 0)
motion.slam_in(tm, C["whistle1"] + 2)
def bump(o, f, s=1.22):
    for fr, v in ((f, 1.0), (f + 2, s), (f + 6, 1.0)):
        o.scale = (v, v, 1)
        o.keyframe_insert("scale", frame=fr)
bump(tm, C["turn2"] + 4, 1.3)  # reset to 60
sched = C["timer"]
for fr, v in sched:
    if fr >= C["warn"]:
        bump(tm, fr, 1.15)
motion.pop_out(tm, C["score"] - 2, 5)
digits = {}
for _, v in sched:
    if v not in digits:
        digits[v] = text(f"tm_d{v}", str(v), 1.15, RED if v <= 10 else OFFBLACK, tm, (0, -0.05), 0.02)
key_frames = sorted({0} | {fr for fr, _ in sched})
for F in key_frames:  # after the pops above, which made every child visible
    cur = max((e for e in sched if e[0] <= F), key=lambda e: e[0], default=(0, None))[1]  # None: badge not in yet
    set_visible(tm["label"], False, F)
    for v, o in digits.items():
        set_visible(o, v == cur, F)

# confetti for the laugh, from above the heads
cf = props.confetti("cf", (0.6, 15.5) if V else (loc.cam_h[0], 15.5), 23, spread=4.5 if V else 8.0)
set_visible(cf, False, 0)
motion.burst(cf, C["laugh"] + 2, 30)

for i, who, text_, _ in S.SCRIPT:
    CA.hud(props.word_captions(i, cam, motion.word_times(text_, vo(i)), C[i], y_px=1320) if V else
           props.word_captions(i, cam, motion.word_times(text_, vo(i)), C[i], fmt=LF.fmt, y_frac=0.8, max_chars=22, size=1.45 * TS))
CA.bake(0, END)

# ---------- end card: coach Riot waves, then a thumbs up ----------
props.end_card("end", f"{S.TITLE} · free on Friendzy", (EX, 9.0), -5, **({} if V else {"fmt": LF.fmt}))
er = cast.riot("coach")
er.root.location = (EX, -12.5, 2) if V else (EX + 10.5, -15.5, 2)
er.root.scale = (1.15, 1.15, 1) if V else (1.75, 1.75, 1)
ea = motion.Anim(er)
ea.expr(0, "hype")
motion.talk(ea, C["end_vo"], vo("riot_end"), text=text_of["riot_end"])
mid = (C["end"] + END) // 2
motion.wave(ea, C["end"] + 4, mid - 4, side=1)  # right paw (the clipboard is in the left); ends before the thumbs up
motion.thumbs_up(ea, mid, hold=END - mid - 10)
ea.add(lambda fr: {"y": 7.0 * motion.curve(fr, [(C["end"], 0, "linear"), (C["end"] + 8, 1.0, "back")]) / 1.15})
ea.bake(C["end"] - 1, END)
for i in range(8):
    l = bpy.data.objects[f"end_l{i}"]
    set_visible(l, False, 0)
    motion.pop_in(l, C["end"] + 2 + i * 2, 5, 1.3, 8)
sub = bpy.data.objects["end_sub"]
set_visible(sub, False, 0)
motion.pop_in(sub, C["end"] + 20, 6)

bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, "scene.blend"))
frames = os.environ.get("FRAMES")
if frames:
    for fr in map(int, frames.split(",")):
        still(sc, os.path.join(OUT, "stills", f"s_{fr:04d}.png"), fr)
else:
    sc.render.filepath = os.path.join(OUT, "frames", "f_")
    bpy.ops.render.render(animation=True)
