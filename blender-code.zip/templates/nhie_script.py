# "Never Have I Ever" at the Campfire: lines + beat timing (pure Python, shared by make.py and the scene).
# Beats: hook caption -> Riot reads the card -> innocent looking around while the target sweats ->
# everyone turns to stare -> the target confesses -> Riot: "Nooo way!" and everyone laughs -> end card.
FPS = 30
TITLE = "Never Have I Ever"
FORMATS = ("vertical", "horizontal")  # make.py --format
HOOK = "the silence said\neverything"
HOOKS = [  # first-second captions; lowercase reads native on TikTok. Pick by prompt so reruns are stable.
    "the silence said\neverything",
    "nobody:\n{target}:",
    "that one friend who\nnever lies",
    "POV: you asked\nthe wrong question",
    "we found out more\nthan we wanted to",
    "it's always the\nquiet ones",
    "game night\nwent too far",
]

CONFESS = {
    "bash": "Okay. ONE time. Maybe twice!",
    "pip": "I-it was ONE time!",
    "rocco": "Mm... okay. One time.",
}


def hook(cfg):
    if cfg.get("hook"):
        return cfg["hook"].replace("\\n", "\n")
    h = HOOKS[sum(map(ord, cfg["prompt"])) % len(HOOKS)]
    return h.replace("{target}", cfg["target"])


def lines(cfg):
    return [
        ("riot_prompt", "riot", cfg["prompt"]),
        ("target_confess", cfg["target"], cfg.get("confess") or CONFESS[cfg["target"]]),
        ("riot_noway", "riot", "Nooo way!"),
        ("riot_end", "riot", f"{TITLE}. Free on Friendzy."),
    ]


def timeline(cfg, dur):
    """dur: {line id: seconds}. Returns frame cues for the scene and the mix."""
    f = lambda s: int(round(s * FPS))
    c = {"card_in": 8, "read": 14}
    c["read_end"] = c["read"] + f(dur["riot_prompt"])
    c["look"] = c["read_end"] + 8
    c["sweat"] = c["look"] + 12
    c["stare"] = c["look"] + 40
    c["confess"] = c["stare"] + 26
    c["confess_end"] = c["confess"] + f(dur["target_confess"])
    c["noway"] = c["confess_end"] + 4
    c["laugh_end"] = c["noway"] + max(f(dur["riot_noway"]) + 18, 44)
    c["wide"] = c["noway"] + 2 + f(dur["riot_noway"])  # close-up on Riot until his line ends, then cut wide
    c["end"] = c["laugh_end"] + 4
    # end card under 2 s (like every template): Riot's line starts just before the cut when it's long
    lead = max(6, f(dur["riot_end"]) + 6 - 57)
    c["end_vo"] = c["end"] - lead
    c["END"] = c["end_vo"] + f(dur["riot_end"]) + 6
    # idle blinks/twitches are drawn over the bake range: keep the old 2.7 s range so every earlier frame is unchanged
    c["BAKE_END"] = c["end"] + 4 + f(dur["riot_end"]) + 10
    s = lambda fr: round(fr / FPS, 3)
    c["voices"] = [["riot_prompt", s(c["read"])], ["target_confess", s(c["confess"])],
                   ["riot_noway", s(c["noway"])], ["riot_end", s(c["end_vo"])]]
    c["sfx"] = [
        ["card_flip", s(c["card_in"]), 0.7], ["pop", s(c["card_in"] + 4), 0.4],
        ["swish", s(c["look"]), 0.35], ["swish", s(c["look"] + 16), 0.3],
        ["whoosh", s(c["stare"] - 2), 0.5], ["sting_suspense", s(c["stare"]), 0.45],
        ["boing", s(c["confess"] - 3), 0.35], ["popper", s(c["wide"]), 0.55],
        ["sting_fanfare", s(c["end"]), 0.5], ["slam", s(c["end"]), 0.3],
    ]
    c["ambience"] = [["fire", 0.0, 0.22]]
    c["music"] = ["chill", 0.0, 0.22, s(c["stare"]), s(c["confess_end"])]  # mood, start, gain, drop out from..to
    return c
