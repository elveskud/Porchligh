# Blender scene for "Challenges" in Game Night HQ, day (challenges_script.py).
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import joke
from joke import *
import challenges_script as S

J = joke.Joke(S, lambda: locations.living_room("day"), {"bash": None, "pip": None, "riot": None, "rocco": None})
C, A = J.C, J.A
r, b, p, k_ = A["riot"], A["bash"], A["pip"], A["rocco"]
for who in A:
    A[who].expr(0, "happy")
r.expr(0, "cocky")
motion.present(r, C["card_in"] - 2, hold=C["riot_card_end"] - C["card_in"], side=-1)
J.talk("riot", "riot_card")
J.listen_all("riot", "riot_card")
b.expr(C["bash_easy"] - 2, "cocky")
J.talk("bash", "bash_easy", energy=1.1)
motion.thumbs_up(b, C["bash_easy"] + 2, hold=12)
for who in ("pip", "riot", "rocco"):
    A[who].look(C["bash_easy"] - 2, J.side(who, "bash"), 5)
# every Bash move first (his bake comes next, so the book can ride on his head)
b.expr(C["timer"], "drumroll")
motion.take(b, C["drop"] + 2, "shocked", 0.6)
b.expr(C["bash_defect"] - 4, "suspicious")
J.talk("bash", "bash_defect", energy=0.8)
motion.laugh(b, C["laugh"] + 6, C["end"] - 2)  # Bash laughs at himself too
b.bake(0, J.END)
# the book: placed on Bash's head, wobbles on the timer, slides off and lands on the floor
head = J.ch["bash"].extras["head"]
bk = props.book("book", None, (0, 0), 23)
for fr in range(0, J.END + 1):
    J.sc.frame_set(fr)
    hp = head.matrix_world.translation
    if fr < C["drop"]:
        bk.location = (hp.x, hp.y + 2.05, 23)
        bk.rotation_euler.z = rad(3) * math.sin(fr * 0.9) * (fr >= C["timer"])
    else:
        t = min(1.0, (fr - C["drop"]) / (C["land"] - C["drop"]))
        bk.location = (hp.x + 2.4 * t, hp.y + 2.05 - 6.6 * t * t, 23)
        bk.rotation_euler.z = rad(-70) * t
    bk.keyframe_insert("location", frame=fr)
    bk.keyframe_insert("rotation_euler", frame=fr)
set_visible(bk, False, 0)
set_visible(bk, True, C["book_on"])
for who in ("pip", "riot", "rocco"):
    A[who].expr(C["land"] + 4, "shocked" if who == "pip" else "side_eye_l")
    A[who].look(C["bash_defect"] - 2, J.side(who, "bash"), 5)
J.munch(C["land"] + 6, 2)
for who in ("pip", "riot", "rocco"):
    motion.laugh(A[who], C["laugh"] + {"riot": 0, "pip": 4, "rocco": 8}[who], C["end"] - 2)
J.A.pop("bash")  # baked already; finish() bakes the others
# camera + graphics
CA = J.camera("wide", band=True)
CA.push(C["card_out"], C["bash_easy"] - 1, J.frame("close:bash"), "out")
CA.shake(C["land"], 10, 0.35)
CA.cut(C["laugh"], J.frame("wide"))
J.hook(C["card_out"] - 4)
J.card(props.prompt_card("ch", "challenge", S.CHALLENGE, (0, 0), 0.6, w=10.4, size=0.8), C["card_in"], C["card_out"], vxy=(0.0, J.F.hud_y(0.4)))
tm = J.on_hud(props.timer("tm", 30, (0, 0), 0.5), (4.4, J.F.hud_y(0.2)), (15.5, 7.6))
set_visible(tm, False, 0)
motion.slam_in(tm, C["timer"])
motion.pop_out(tm, C["laugh"], 5)
J.captions(["riot_card", "bash_easy", "bash_defect"], y_px=1400)
J.confetti(C["laugh"] + 2)
J.finish(S.TITLE)
