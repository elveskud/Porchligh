# Blender scene for "Mafia" in the Night Village (mafia_script.py).
#   Blender --background --python mafia_scene.py -- <video dir>
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import joke
from joke import *
import mafia_script as S

J = joke.Joke(S, locations.village_night, {"bash": None, "pip": None, "riot": "mafia", "rocco": None})
C, A = J.C, J.A
r, b, p, k_ = A["riot"], A["bash"], A["pip"], A["rocco"]
loc = J.loc

# 1. role reveal: Riot alone sees "YOU ARE / Mafia", tips his shades down and smirks
for who in A:
    A[who].expr(0, "happy")
r.expr(0, "cocky")
glasses = J.ch["riot"].extras["glasses"]
g0 = glasses.location.y
for fr, dy in ((0, 0), (C["smirk"] - 4, 0), (C["smirk"] + 2, -0.28), (C["role_out"] + 6, -0.28), (C["role_out"] + 12, 0)):
    glasses.location.y = g0 + dy
    glasses.keyframe_insert("location", frame=fr)
r.look(C["smirk"], 0.0, 4)
J.munch(6, 2)
p.look(4, -0.4, 6)
b.look(8, 0.4, 6)

# 2. night falls: windows go dark, a deep blue wash
tint = locations.mood_tint(loc, "#0A1030", 0.38, name="night")
set_visible(tint, True, C["dark"])
set_visible(tint, False, C["day"])
for w in loc.extras["windows"]:
    set_visible(w, False, C["dark"])
    set_visible(w, True, C["day"])
for who in A:
    A[who].expr(C["dark"], "suspicious" if who != "riot" else "cocky")
    A[who].look(C["dark"] + 2, (-0.5, 0.5)[hash(who) % 2], 5)

# 3. day: Bash accuses Pip, Pip protests
b.expr(C["bash_accuse"] - 2, "yelling")
J.talk("bash", "bash_accuse", energy=1.3)
motion.point_at(b, C["bash_accuse"] + 2, 1, hold=C["pip_innocent_end"] - C["bash_accuse"], expr="yelling")
motion.nervous(p, C["bash_accuse"] + 4, C["pip_innocent_end"] + 4)
p.look(C["bash_accuse"], -1.0, 4)
J.talk("pip", "pip_innocent")
r.look(C["bash_accuse"], -1.0, 6)
k_.look(C["bash_accuse"], -1.0, 6)
J.munch(C["bash_accuse"] + 10, 2)

# 4. the verdict: Pip was... a Civilian. Bash's take; Pip relieved
motion.take(b, C["verdict"] + 10, "shocked", 0.9)
p.expr(C["verdict"] + 12, "happy")
motion.hop(p, C["verdict"] + 14, 0.4)
r.expr(C["verdict"], "side_eye_l")

# 5. everyone slowly turns to the quiet one
for k, who in enumerate(("bash", "pip", "rocco")):
    A[who].look(C["turn"] + k * 4, J.side(who, "riot"), 8)
    A[who].expr(C["turn"] + k * 4, "suspicious")
r.look(C["turn"] + 2, 0.0, 6)
r.expr(C["riot_shh"] - 4, "cocky")
J.shh("riot", C["riot_shh"] - 2, C["riot_shh_end"])
J.talk("riot", "riot_shh", energy=0.7)

# 6. everyone laughs (Riot first)
J.laugh_all(C["laugh"], C["end"] - 2)

# ---- camera + graphics ----
CA = J.camera("wide", band=True)
CA.push(C["smirk"] - 8, C["smirk"] - 1, J.frame("close:riot"), "out")
CA.cut(C["narr"] - 4, J.frame("wide"))
CA.shake(C["dark"], 10, 0.3)
CA.push(C["bash_accuse"] - 10, C["bash_accuse"] - 1, J.frame("two:bash,pip"), "out")
CA.cut(C["verdict"] - 1, J.frame("wide", band=True))
CA.push(C["turn"], C["riot_shh"] - 1, J.frame("close:riot"), "out")  # lands before the punchline
CA.cut(C["laugh"], J.frame("wide"))
J.hook(C["narr"] - 6)
J.card(props.reveal_card("role", "YOU ARE", "Mafia", (0, 0), 0.6, color=OFFBLACK, tint="#FFF6C7"),
       C["role_in"], C["role_out"], vxy=(0.0, J.F.hud_y(0.42)), hxy=(10.6, 5.6), s=0.9)
J.card(props.reveal_card("verdict", S.VERDICT[0], S.VERDICT[1], (0, 0), 0.6, color=ORANGE),
       C["verdict"], C["turn"] - 2, s=0.95, flip=False)
J.captions(["narr", "bash_accuse", "pip_innocent", "riot_shh"])
J.confetti(C["laugh"] + 2)
J.finish(S.TITLE, "mafia")
