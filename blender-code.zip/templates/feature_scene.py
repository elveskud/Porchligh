# Blender scene for app feature spots (feature_script.py) in the Party Room.
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import joke
from joke import *
import feature_script as S
import features

J = joke.Joke(S, locations.party_room, {"bash": None, "pip": None, "riot": None, "rocco": None})
C, A = J.C, J.A
k = S.key(J.cfg)
shot = features.shot(k)
sp = S.SPOTS[k]
loc = J.loc
if k == "rooms":  # the TV shows the same code as the real lobby screenshot
    loc.extras["code"].data.body = "DNTX"
for who in A:
    A[who].expr(0, "happy")
A["riot"].expr(0, "hype")
J.hold_screen("riot", shot, C["phone_up"], C["laugh"] - 2)
J.talk("riot", "riot_pitch")
J.listen_all("riot", "riot_pitch")
others = [i for i in C["order"][1:]]
for i in others:  # each friend joins: their own phone pops up with a ding, a happy hop, their line
    who = i.split("_")[0]
    J.hold_phone(who, C[i] - 4, C["laugh"] - 2, side=1 if who == "rocco" else -1)
    A[who].expr(C[i] - 2, "hype" if who != "rocco" else "cocky")
    J.talk(who, i)
    motion.hop(A[who], C[i], 0.3)
    for w in A:
        if w != who:
            A[w].look(C[i] - 2, J.side(w, who) * 0.6, 4)
J.laugh_all(C["laugh"], C["end"] - 2)
# camera: wide, push in on Riot's phone, then the real screen fills the frame on the camera layer
CA = J.camera("wide")
def below_tv(f):
    """Close-ups leave the TV out entirely (no half-cut room code): the top of the frame stays under its bottom edge."""
    x, y, o = f
    if J.V:
        o = min(o, 11.0)
    tv_bottom = 15.6 - 2.7 if J.V else 13.5 - 2.7 * 0.68  # party_room TV (16:9: lowered and scaled by widen)
    return (x, min(y, tv_bottom - 0.25 - o / 2), o)


CA.cut(C["riot_pitch"] + 18, below_tv(J.frame("close:riot")))  # a cut, not a push: a push passes through a half-cut TV
CA.cut(C["zoom_out"], J.frame("wide"))
J.hook(C["riot_pitch"] + 24)
big = J.on_hud(props.app_phone("bigscreen", shot, None, (0, 0), 0.8, 16.0 if J.V else 19.5), (0.0, -0.6), (0.0, 0.0), 1.0, hs=1.0)
set_visible(big, False, 0)
motion.pop_in(big, C["zoom"], 7, 1.06, 2)
motion.pop_out(big, C["zoom_out"], 5)
J.captions([i for i in C["order"]], y_px=1400)
J.confetti(C["laugh"] + 2)
J.finish(sp["title"])
