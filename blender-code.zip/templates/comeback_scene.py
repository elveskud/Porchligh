# Blender scene for "Comeback" in the Party Room (comeback_script.py).
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import joke
from joke import *
import comeback_script as S

J = joke.Joke(S, locations.party_room, {"bash": None, "pip": None, "riot": None, "rocco": None})
C, A = J.C, J.A
r, b, p, k_ = A["riot"], A["bash"], A["pip"], A["rocco"]
loc = J.loc
bpy.data.objects["pr_tv_t"].data.body = "COMEBACK"
loc.extras["code"].data.body = "VOTE!"
for who in A:
    A[who].expr(0, "happy")
    ph = J.hold_phone(who, 0, C["laugh"] - 2, side=1 if who == "rocco" else -1)
    for k, fr in enumerate([C["type"] + i * 9 + J.seat[who] * 2 for i in range(3)] + [C["vote"] + J.seat[who] * 2]):
        for f_, v in ((fr, 1.0), (fr + 2, 1.08), (fr + 5, 1.0)):
            ph.scale = (v, v, 1)
            ph.keyframe_insert("scale", frame=f_)
# Riot reads, cocky... then realises the prompt is about him
r.expr(0, "cocky")
J.talk("riot", "riot_q")
J.listen_all("riot", "riot_q")
motion.double_take(r, C["realise"] - 26, 0.0)
for who in ("bash", "pip", "rocco"):
    A[who].expr(C["type"], "cocky")
# the vote: the evil-laugh answer wins
for who in ("bash", "pip", "rocco"):
    A[who].expr(C["win"] + 4, "laughing")
r.expr(C["win"] + 4, "shocked")
# "Who wrote that?!" -- three quick denials, eyes darting
r.expr(C["riot_who"] - 2, "suspicious")
J.talk("riot", "riot_who", energy=1.2)
for who in ("bash", "pip", "rocco"):
    A[who].look(C["riot_who"], J.side(who, "riot"), 4)
    A[who].expr(C[f"{who}_not"] - 2, "happy" if who != "pip" else "nervous")
    J.talk(who, f"{who}_not")
    A[who].look(C[f"{who}_not"] + 6, (-0.5, 0.5)[J.seat[who] % 2], 4)
    r.look(C[f"{who}_not"] - 2, J.side("riot", who) * 0.7, 3)
J.munch(C["rocco_not_end"] + 2, 1)
# ...and then he does it anyway
r.look(C["riot_mwaha"] - 8, 0.0, 6)
r.expr(C["riot_mwaha"] - 4, "cocky")
J.talk("riot", "riot_mwaha", energy=1.2)
r.add(lambda fr: None if not (C["riot_mwaha"] <= fr <= C["riot_mwaha_end"] + 6) else {
    "sq": 1 + 0.04 * abs(math.sin(fr * 0.9)), "head_rot": 6 * math.sin(fr * 0.45)})
J.laugh_all(C["laugh"], C["end"] - 2)
# camera + graphics
CA = J.camera("wide", band=True)
CA.push(C["realise"] - 4, C["realise"] + 6, J.frame("close:riot"), "out")
CA.cut(C["answers"] - 2, J.frame("wide", band=True))
CA.shake(C["win"], 8, 0.25)
CA.cut(C["riot_who"] - 2, J.frame("close:riot"))
CA.cut(C["bash_not"] - 1, J.frame("wide"))
CA.push(C["riot_mwaha"] - 10, C["riot_mwaha"] - 1, J.frame("close:riot"), "out")
CA.cut(C["laugh"], J.frame("wide"))
J.hook(C["card_in"] + 30)
J.card(props.prompt_card("q", "hottakes", S.PROMPT, (0, 0), 0.6, w=10.4, size=0.8), C["card_in"] + 30, C["realise"] - 4,
       vxy=(0.0, J.F.hud_y(0.38)))
bpy.data.objects["q_hdr"].data.body = "COMEBACK"
# 16:9: the prompt was just on screen, so the vote card is the answers only (shorter, so it fits bigger)
vc = J.card(props.trivia_card("v", S.PROMPT if J.V else "", S.ANSWERS, (0, 0), 0.6, header="ANONYMOUS ANSWERS · VOTE", letters=False,
                                     row_size=0.82),
            C["answers"], C["card_out"], vxy=(0.0, J.F.hud_y(0.34)), s=0.85, hxy=(12.2, 6.9), hs=0.8)
for i in range(len(S.ANSWERS)):
    for kind in ("good", "bad"):
        o = bpy.data.objects[f"v_{kind}{i}"]
        set_visible(o, False, 0)
        set_visible(o, False, C["answers"])
        if kind == "good" and i == S.WINNER:
            set_visible(o, True, C["win"])
J.captions(["riot_q", "riot_who", "bash_not", "pip_not", "rocco_not", "riot_mwaha"], y_px=1400)
J.confetti(C["laugh"] + 2)
J.finish(S.TITLE)
