# "Truth or Dare" in Game Night HQ (day), Riot in his dare costume: lines + beat timing.
# Beats: hook + the app's choice screen ("Riot's Turn") -> Riot: "Dare." and slams DARE -> the "?" card flips
# to the red dare card -> Riot reads it -> he performs it a little too well (room goes red) -> lights snap back,
# the target's deadpan line -> everyone laughs, Riot first -> end card.
#   python3 make.py tod --prompt "Do 10 seconds of the most dramatic evil laughter you have." --target rocco
FPS = 30
STANDALONE = True   # --prompt / --target are optional (defaults below)
FORMATS = ("vertical", "horizontal")  # make.py --format
TITLE = "Truth or Dare"
DEFAULT_PROMPT = "Do 10 seconds of the most dramatic evil laughter you have."
DEFAULT_TARGET = "rocco"

# Real dares from TruthOrDarePromptLibrary.swift that Riot can act out in ~2s, each with his performance,
# the room mood while he does it, and the deadpan line the target says after.
DARES = {
    "Do 10 seconds of the most dramatic evil laughter you have.": dict(
        perform="Mwahaha... HA HA HA HA!", tint="#B0102A",
        hook="never give the fox\nthe evil laugh dare", react="...He didn't need the dare."),
    "Howl at the ceiling as a wolf for 10 full seconds.": dict(
        perform="Awoooooooo!", tint="#2A3A8C",
        hook="he picked dare\nin 0.2 seconds", react="...Wrong animal. Same energy."),
    "Talk like a robot for the next 2 complete minutes.": dict(
        perform="BEEP. BOOP. I. AM. RIOT.", tint="#1F7A8C",
        hook="he picked dare\nin 0.2 seconds", react="...Can he stay like that?"),
}


def prompt(cfg):
    p = cfg.get("prompt") or DEFAULT_PROMPT
    if p not in DARES:
        raise SystemExit(f"tod: no performance written for this dare yet. Pick one of:\n  " + "\n  ".join(DARES))
    return p


def target(cfg):
    return cfg.get("target") or DEFAULT_TARGET


def hook(cfg):
    if cfg.get("hook"):
        return cfg["hook"].replace("\\n", "\n")
    return DARES[prompt(cfg)]["hook"]


def lines(cfg):
    d = DARES[prompt(cfg)]
    return [
        ("riot_dare", "riot", "Dare."),
        ("riot_read", "riot", prompt(cfg)),
        ("riot_perform", "riot", d["perform"]),
        ("target_react", target(cfg), d["react"]),
        ("riot_end", "riot", f"{TITLE}. Free on Friendzy."),
    ]


def timeline(cfg, dur):
    """dur: {line id: seconds}. Returns frame cues for the scene and the mix."""
    f = lambda s: int(round(s * FPS))
    s = lambda fr: round(fr / FPS, 3)
    c = {"choice_in": 1, "dare": 12}
    c["dare_end"] = c["dare"] + f(dur["riot_dare"])
    c["tap"] = c["dare_end"] + 1                      # paw hits DARE right as the word ends
    c["mystery"] = c["tap"] + 7
    c["flip"] = c["mystery"] + 16                      # a short drumroll on the "?" card
    c["read"] = c["flip"] + 6
    c["read_end"] = c["read"] + f(dur["riot_read"])
    c["perform"] = c["read_end"] + 8
    c["perform_end"] = c["perform"] + f(dur["riot_perform"])
    c["snap"] = c["perform_end"] + 4                   # lights back on
    c["react"] = c["snap"] + 6
    c["react_end"] = c["react"] + f(dur["target_react"])
    c["laugh"] = c["react_end"] + 3
    c["end"] = c["laugh"] + 38
    # end card under 2s: Riot's line starts just before the cut (over the laugh) when it's long
    lead = max(6, f(dur["riot_end"]) + 6 - 57)
    c["end_vo"] = c["end"] - lead
    c["END"] = c["end_vo"] + f(dur["riot_end"]) + 6
    c["voices"] = [["riot_dare", s(c["dare"])], ["riot_read", s(c["read"])], ["riot_perform", s(c["perform"])],
                   ["target_react", s(c["react"])], ["riot_end", s(c["end_vo"])]]
    c["sfx"] = [
        ["pop", s(c["choice_in"]), 0.45], ["slam", s(c["tap"]), 0.35], ["tap", s(c["tap"]), 0.5],
        ["pop", s(c["mystery"]), 0.35], ["drumroll_short", s(c["mystery"] + 1), 0.4],
        ["card_flip", s(c["flip"]), 0.7], ["pop", s(c["flip"] + 4), 0.3],
        ["boom", s(c["perform"] - 2), 0.45], ["sting_suspense", s(c["perform"]), 0.35],
        ["scratch", s(c["snap"]), 0.45],
        ["popper", s(c["laugh"] + 2), 0.5], ["sting_fanfare", s(c["end"]), 0.45],
    ]
    c["ambience"] = []
    # music drops out for the dare and the deadpan line, back on the laugh
    c["music"] = ["hype", 0.0, 0.16, s(c["perform"] - 6), s(c["react_end"])]
    return c
