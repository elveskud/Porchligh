# "Comeback" in the Party Room (room game: everyone writes the funniest answer on their phone, nobody sees who wrote
# it, the room votes). The prompt is about Riot himself; the winning answer is his evil laugh (the Truth or Dare video).
#   python3 make.py comeback --name comeback_01 [--format horizontal]
from jokecues import end_cues, sequence

FPS = 30
STANDALONE = True
FORMATS = ("vertical", "horizontal")
TITLE = "Comeback"
HOOK = "the prompt was\nabout riot"
PROMPT = "What Riot the fox really does when nobody's playing"   # real (Friendzy/Models/RoomGameDecks.swift, Comeback)
ANSWERS = ["Practises his evil laugh", "Talks to his own tail", "Eats Rocco's snacks"]   # player-written in the game
WINNER = 0

SCRIPT = [  # id, speaker, line, pause before (frames)
    ("riot_q", "riot", PROMPT + ".", 12),
    ("riot_who", "riot", "...Who wrote that?!", 86),      # the gap = typing, the answers, the vote
    ("bash_not", "bash", "Not me.", 6),
    ("pip_not", "pip", "Not me!", 2),
    ("rocco_not", "rocco", "Mm. Not me.", 2),
    ("riot_mwaha", "riot", "...Mwahaha.", 16),
]


def hook(cfg):
    return (cfg.get("hook") or HOOK).replace("\\n", "\n")


def lines(cfg):
    return [(i, w, t) for i, w, t, _ in SCRIPT] + [("riot_end", "riot", f"{TITLE}. Free on Friendzy.")]


def timeline(cfg, dur):
    f = lambda s: int(round(s * FPS))
    s = lambda fr: round(fr / FPS, 3)
    c = {"card_in": 8}
    sequence(c, dur, f, SCRIPT)
    c["realise"] = c["riot_q_end"] - 8
    c["type"] = c["riot_q_end"] + 4
    c["answers"] = c["type"] + 26
    c["vote"] = c["answers"] + 26
    c["win"] = c["vote"] + 16
    c["card_out"] = c["riot_who"] - 4
    c["laugh"] = c["riot_mwaha_end"] + 4
    end_cues(c, dur, f)
    c["voices"] = [[i, s(c[i])] for i, *_ in SCRIPT] + [["riot_end", s(c["end_vo"])]]
    c["sfx"] = [["tap", s(c["type"] + k * 5), 0.35] for k in range(6)] + [
        ["card_flip", s(c["card_in"]), 0.6], ["boing", s(c["realise"]), 0.35], ["card_flip", s(c["answers"]), 0.5],
        ["tap", s(c["vote"]), 0.5], ["tap", s(c["vote"] + 4), 0.5], ["tap", s(c["vote"] + 7), 0.5],
        ["drumroll_short", s(c["vote"] + 9), 0.35], ["ting", s(c["win"]), 0.5], ["sparkle", s(c["win"] + 3), 0.4],
        ["whoosh", s(c["bash_not"] - 2), 0.3], ["boom", s(c["riot_mwaha"] - 2), 0.3],
        ["popper", s(c["laugh"] + 2), 0.5], ["sting_fanfare", s(c["end"]), 0.45]]
    c["ambience"] = []
    c["music_segments"] = [["hype", 0.0, s(c["END"]), 0.15, [[s(c["riot_who"] - 4), s(c["riot_mwaha_end"])]]]]
    return c
