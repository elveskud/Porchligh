# "Spy" in the Party Room (room game: every phone shows the location, except the spy's). Riot is the spy, bluffs
# perfectly, and Bash accuses Pip anyway (running jokes #1 Bash is never right, #6 the quiet twist is always Riot).
# The app's flow: "THE LOCATION IS ..." / "You are the SPY" -> ask each other questions -> accuse -> reveal.
#   python3 make.py spy --name spy_sunscreen_01 [--format horizontal]
from jokecues import end_cues, sequence

FPS = 30
STANDALONE = True
FORMATS = ("vertical", "horizontal")
TITLE = "Spy"
HOOK = "the spy was\nRIGHT there"
LOCATION = "Beach Resort"     # real location (Friendzy/Features/Spy/Models/SpyGameState.swift)

SCRIPT = [  # id, speaker, line, pause before (frames)
    ("bash_ask", "bash", "Riot. What do you wear here?", 70),     # the gap = the two phone screens
    ("riot_bluff", "riot", "...Sunscreen.", 14),
    ("pip_wow", "pip", "Wow. He knows.", 10),
    ("bash_accuse", "bash", "Then it's PIP!", 12),
]


def hook(cfg):
    return (cfg.get("hook") or HOOK).replace("\\n", "\n")


def lines(cfg):
    return [(i, w, t) for i, w, t, _ in SCRIPT] + [("riot_heh", "riot", "Heh."), ("riot_end", "riot", f"{TITLE}. Free on Friendzy.")]


def timeline(cfg, dur):
    f = lambda s: int(round(s * FPS))
    s = lambda fr: round(fr / FPS, 3)
    c = {"loc_card": 6, "spy_card": 36}
    sequence(c, dur, f, SCRIPT)
    c["cards_out"] = c["bash_ask"] - 6
    c["verdict"] = c["bash_accuse_end"] + 8
    c["riot_heh"] = c["verdict"] + 30
    c["riot_heh_end"] = c["riot_heh"] + f(dur["riot_heh"])
    c["laugh"] = c["riot_heh_end"] + 4
    end_cues(c, dur, f)
    c["voices"] = [[i, s(c[i])] for i, *_ in SCRIPT] + [["riot_heh", s(c["riot_heh"])], ["riot_end", s(c["end_vo"])]]
    c["sfx"] = [["pop", s(c["loc_card"]), 0.4], ["ting", s(c["loc_card"] + 4), 0.35], ["sting_dun_dun_dunnn", s(c["spy_card"]), 0.4],
                ["whoosh", s(c["bash_ask"] - 4), 0.3], ["slam", s(c["bash_accuse"] + 4), 0.25], ["card_flip", s(c["verdict"]), 0.6],
                ["sting_sad_trombone", s(c["verdict"] + 12), 0.3], ["swish", s(c["riot_heh"] - 6), 0.35],
                ["popper", s(c["laugh"] + 2), 0.5], ["sting_fanfare", s(c["end"]), 0.45]]
    c["ambience"] = []
    c["music_segments"] = [["suspense", 0.0, s(c["laugh"]), 0.2, [[s(c["verdict"] - 2), s(c["laugh"])]]],
                           ["hype", s(c["laugh"]), s(c["END"]), 0.16, []]]
    return c
