# "Close Call" in the Party Room (room game: everyone types a number on their phone, closest wins).
# Bash goes huge, Rocco goes tiny, quiet Pip is exactly right.
#   python3 make.py closecall --name closecall_bones_01 [--format horizontal]
from jokecues import end_cues, sequence

FPS = 30
STANDALONE = True
FORMATS = ("vertical", "horizontal")
TITLE = "Close Call"
HOOK = "the quiet one\nwas EXACTLY right"
QUESTION, ANSWER = "How many bones are in an adult human body?", "206"   # real (RoomGameDecks.swift, Close Call)
GUESSES = [("bash", "1000"), ("rocco", "7"), ("pip", "206"), ("riot", "150")]

SCRIPT = [  # id, speaker, line, pause before (frames)
    ("riot_q", "riot", QUESTION, 12),
    ("bash_g", "bash", "A THOUSAND!", 44),       # the gap = everyone typing
    ("rocco_g", "rocco", "...Seven.", 10),
    ("pip_g", "pip", "Two hundred and six?", 10),
    ("pip_read", "pip", "I read a lot.", 40),    # the gap = the answer reveal
]


def hook(cfg):
    return (cfg.get("hook") or HOOK).replace("\\n", "\n")


def lines(cfg):
    return [(i, w, t) for i, w, t, _ in SCRIPT] + [("riot_end", "riot", f"{TITLE}. Free on Friendzy.")]


def timeline(cfg, dur):
    f = lambda s: int(round(s * FPS))
    s = lambda fr: round(fr / FPS, 3)
    c = {"card_in": 8}
    sequence(c, dur, f, SCRIPT)
    c["type"] = c["riot_q_end"] + 4
    c["card_out"] = c["bash_g"] - 4
    c["answer"] = c["pip_g_end"] + 10
    c["laugh"] = c["pip_read_end"] + 4
    end_cues(c, dur, f)
    c["voices"] = [[i, s(c[i])] for i, *_ in SCRIPT] + [["riot_end", s(c["end_vo"])]]
    c["sfx"] = [["tap", s(c["type"] + k * 5), 0.35] for k in range(7)] + [
        ["card_flip", s(c["card_in"]), 0.6], ["pop", s(c["bash_g"]), 0.35], ["pop", s(c["rocco_g"]), 0.35], ["pop", s(c["pip_g"]), 0.35],
        ["drumroll_short", s(c["answer"] - 16), 0.4], ["stamp", s(c["answer"]), 0.35], ["sparkle", s(c["answer"] + 4), 0.45],
        ["popper", s(c["laugh"] + 2), 0.5], ["sting_fanfare", s(c["end"]), 0.45]]
    c["ambience"] = []
    c["music_segments"] = [["hype", 0.0, s(c["END"]), 0.15, [[s(c["answer"] - 18), s(c["pip_read_end"])]]]]
    return c
