# "Hot Takes" at the Campfire: Riot reads a real topic from the app, Bash rants, Pip quietly disagrees, Bash caves.
# Running joke #1: Bash is never right (and laughs about it). The app gives a topic; players improvise their take.
#   python3 make.py hottakes --name hottakes_pineapple_01 [--format horizontal]
from jokecues import end_cues, sequence

FPS = 30
STANDALONE = True
FORMATS = ("vertical", "horizontal")
TITLE = "Hot Takes"
HOOK = "bash's hottest take\nlasted 4 seconds"
TOPIC = "Pineapple on pizza is..."   # real topic (Friendzy/Models/GamePromptLibraries.swift, Hot Takes)

SCRIPT = [  # id, speaker, line, pause before (frames)
    ("riot_topic", "riot", "Hot take. Pineapple on pizza is...", 12),
    ("bash_rant", "bash", "A CRIME! Fruit does NOT go on pizza!", 8),
    ("pip_like", "pip", "I-I kind of like it...", 10),
    ("bash_cave", "bash", "...Fine. It's amazing.", 40),       # the gap = Bash takes a bite
]


def hook(cfg):
    return (cfg.get("hook") or HOOK).replace("\\n", "\n")


def lines(cfg):
    return [(i, w, t) for i, w, t, _ in SCRIPT] + [("riot_end", "riot", f"{TITLE}. Free on Friendzy.")]


def timeline(cfg, dur):
    f = lambda s: int(round(s * FPS))
    s = lambda fr: round(fr / FPS, 3)
    c = {"card_in": 8}
    sequence(c, dur, f, SCRIPT)
    c["card_out"] = c["bash_rant"] - 2
    c["bite"] = c["bash_cave"] - 30
    c["laugh"] = c["bash_cave_end"] + 4
    end_cues(c, dur, f)
    c["voices"] = [[i, s(c[i])] for i, *_ in SCRIPT] + [["riot_end", s(c["end_vo"])]]
    c["sfx"] = [["card_flip", s(c["card_in"]), 0.6], ["pop", s(c["card_in"] + 4), 0.35], ["slam", s(c["bash_rant"] + 4), 0.25],
                ["whoosh", s(c["pip_like"] - 3), 0.3], ["crunch", s(c["bite"]), 0.6], ["crunch", s(c["bite"] + 9), 0.5],
                ["slide_down", s(c["bash_cave"] - 4), 0.3], ["popper", s(c["laugh"] + 2), 0.5], ["sting_fanfare", s(c["end"]), 0.45]]
    c["ambience"] = [["fire", 0.0, 0.16]]
    c["music_segments"] = [["chill", 0.0, s(c["END"]), 0.18, [[s(c["bite"] - 4), s(c["bash_cave_end"])]]]]
    return c
