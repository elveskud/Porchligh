# Real prompts from the app's libraries, ranked for short-form video.
#   python3 prompts.py nhie 10          -> prints the 10 best unused Never Have I Ever prompts
import csv, glob, json, os, random, re, sys

HERE = os.path.dirname(os.path.abspath(__file__))
APP = os.path.normpath(os.path.join(HERE, "../../Friendzy/Models"))
TRACKER = os.path.normpath(os.path.join(HERE, "../videos/tracker.csv"))
PATTERNS = {"nhie": r'"(Never have I ever [^"\\]{8,110})"',
            "dare": r'TruthOrDarePrompt\(text: "([^"\\]{8,110})", type: \.dare\)'}
# words that tend to make a prompt relatable / funny on camera
SPICE = ("accidentally", "pretend", "pretending", "secretly", "panic", "hid", "blamed", "forgot", "rehearsed", "laughed", "cried", "googled", "screenshot", "ghost", "wrong person", "replied",
         "nodded", "walked into", "tripped", "waved at", "on my way", "talked to myself")


# fine inside the game, wrong for public marketing aimed at a young audience
AVOID = ("fire", "fake", "stole", "steal", "shoplift", "cheat", "police", "arrest", "hospital", "drunk", "alcohol",
         "beer", "wine", "vape", "smok", "kiss", "date", "crush", "ex ", "naked", "underwear", "toilet", "pee",
         "vomit", "threw up", "fight", "punch", "hate", "stalking", "lied to my parents", "snuck out", "skipped school",
         "stood up", "dumped", "breakup", "break up")


def ok_for_marketing(p):
    low = p.lower()
    return not any(w in low for w in AVOID)


def load(kind):
    seen, out = set(), []
    for f in sorted(glob.glob(os.path.join(APP, "*.swift"))):
        for m in re.finditer(PATTERNS[kind], open(f, encoding="utf-8").read()):
            t = m.group(1).strip()
            if t.lower() not in seen:
                seen.add(t.lower())
                out.append(t)
    return out


def used():
    if not os.path.exists(TRACKER):
        return set()
    return {row["prompt"].lower() for row in csv.DictReader(open(TRACKER))}


def score(p):
    s = sum(3 for w in SPICE if w in p.lower())
    s += 2 if len(p) <= 80 else (0 if len(p) <= 95 else -10)  # must read aloud in ~4s and fit the card
    s -= 3 if p.count(",") > 1 else 0
    return s


def pick(kind, n, seed=None):
    pool = [p for p in load(kind) if p.lower() not in used() and len(p) <= 95 and ok_for_marketing(p)]
    rnd = random.Random(seed)
    rnd.shuffle(pool)
    pool.sort(key=score, reverse=True)
    top = pool[: max(n * 4, 20)]  # sample from the best, so batches stay varied
    rnd.shuffle(top)
    return top[:n]


if __name__ == "__main__":
    kind, n = sys.argv[1], int(sys.argv[2]) if len(sys.argv) > 2 else 10
    print(f"{len(load(kind))} prompts in the app")
    for p in pick(kind, n, 1):
        print(f"  [{score(p):2d}] {p}")
