# App feature spots: Riot holds up his phone and the screen is a REAL app screenshot (features.py), then the camera
# zooms into it. One beat per feature. Proof: feature_rooms_01 (party rooms: every phone joins with one code).
#   python3 make.py feature --prompt rooms --name feature_rooms_01 [--format horizontal]
from jokecues import end_cues, sequence
import features

FPS = 30
STANDALONE = True
FORMATS = ("vertical", "horizontal")
DEFAULT_PROMPT = "rooms"   # --prompt = the feature key (rooms, tonight, roadtrip, classics, podium, spanish)

SPOTS = {  # what the cast says for each feature (Riot pitches it, a friend gets the last word)
    "rooms": dict(hook="every phone joins.\none code.", title="Party rooms",
                  lines=[("riot_pitch", "riot", "Party rooms! One code, and every phone joins."),
                         ("bash_join", "bash", "I'm IN!"), ("pip_join", "pip", "Me too!"), ("rocco_join", "rocco", "Mm. Even me.")]),
    "tonight": dict(hook="can't pick a game?", title="Tonight's Pack",
                    lines=[("riot_pitch", "riot", "Can't pick a game? Tonight's Pack picks three."), ("bash_join", "bash", "I'd have picked those!")]),
    "roadtrip": dict(hook="long drive?\nwe got you", title="Road Trip",
                     lines=[("riot_pitch", "riot", "Long drive? Road Trip mode. No phone passing."), ("pip_join", "pip", "Are we there yet?")]),
    "classics": dict(hook="44 games.\nno phone needed", title="Classic games",
                     lines=[("riot_pitch", "riot", "Forty-four classic games. We give you the rules."), ("rocco_join", "rocco", "Mm. Forty-four.")]),
    "spanish": dict(hook="¡ahora en\nespañol!", title="Friendzy en español",
                    lines=[("riot_pitch", "riot", "Friendzy, now in Spanish too!"), ("pip_join", "pip", "¡Hola!")]),
}


def key(cfg):
    k = cfg.get("prompt") or DEFAULT_PROMPT
    features.shot(k)  # refuses features without a real screenshot
    if k not in SPOTS:
        raise SystemExit(f"feature: no lines written for {k!r} yet (feature_script.SPOTS)")
    return k


def hook(cfg):
    return (cfg.get("hook") or SPOTS[key(cfg)]["hook"]).replace("\\n", "\n")


def lines(cfg):
    sp = SPOTS[key(cfg)]
    return list(sp["lines"]) + [("riot_end", "riot", f"{sp['title']}. Free on Friendzy.")]


def timeline(cfg, dur):
    f = lambda s: int(round(s * FPS))
    s = lambda fr: round(fr / FPS, 3)
    sp = SPOTS[key(cfg)]
    script = [(i, w, t, (12 if k == 0 else 50 if k == 1 else 12)) for k, (i, w, t) in enumerate(sp["lines"])]
    c = {"phone_up": 6}
    sequence(c, dur, f, script)
    c["order"] = [i for i, *_ in sp["lines"]]
    c["zoom"] = c["riot_pitch_end"] + 4        # the screen fills the frame
    c["zoom_out"] = c["zoom"] + 42
    c["laugh"] = c["t"] + 6
    end_cues(c, dur, f)
    c["voices"] = [[i, s(c[i])] for i, *_ in script] + [["riot_end", s(c["end_vo"])]]
    joins = [i for i in c["order"][1:]]
    c["sfx"] = [["pop", s(c["phone_up"]), 0.4], ["whoosh", s(c["zoom"] - 2), 0.4], ["ting", s(c["zoom"] + 4), 0.4]] + \
               [[f"rise{k + 1}", s(c[i] - 2), 0.5] for k, i in enumerate(joins[:4])] + \
               [["popper", s(c["laugh"] + 2), 0.5], ["sting_fanfare", s(c["end"]), 0.45]]
    c["ambience"] = []
    c["music_segments"] = [["hype", 0.0, s(c["END"]), 0.16, []]]
    return c
