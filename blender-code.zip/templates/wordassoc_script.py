# "Word Association" in the Party Room (room game: a word appears, everyone types the first word that pops into
# their head, matches score). Three of them say CHEESE. Rocco does not. Running joke #3: Rocco and snacks.
#   python3 make.py wordassoc --name wordassoc_pizza_01 [--format horizontal]
from jokecues import end_cues, sequence

FPS = 30
STANDALONE = True
FORMATS = ("vertical", "horizontal")
TITLE = "Word Association"
HOOK = "3 of us matched.\nthen there's rocco"
WORD = "Pizza"     # real word (Friendzy/Models/WordAssociationPrompts.swift)
ANSWERS = [("bash", "CHEESE"), ("pip", "Cheese"), ("riot", "Cheese"), ("rocco", "Breakfast")]

SCRIPT = [  # id, speaker, line, pause before (frames)
    ("riot_word", "riot", "First word that pops into your head. Pizza!", 10),
    ("rocco_why", "rocco", "...What? It's breakfast.", 108),      # the gap = typing, the reveal, the stare
]


def hook(cfg):
    return (cfg.get("hook") or HOOK).replace("\\n", "\n")


def lines(cfg):
    return [(i, w, t) for i, w, t, _ in SCRIPT] + [("riot_end", "riot", "Word Association. Free on Friendzy.")]


def timeline(cfg, dur):
    f = lambda s: int(round(s * FPS))
    s = lambda fr: round(fr / FPS, 3)
    c = {"card_in": 8}
    sequence(c, dur, f, SCRIPT)
    c["type"] = c["riot_word_end"] + 4
    c["card_out"] = c["type"] + 30
    c["reveal"] = c["type"] + 36          # CHEESE, Cheese, Cheese... (one every 7 frames)
    c["odd"] = c["reveal"] + 26            # ...Breakfast
    c["stare"] = c["odd"] + 8
    c["laugh"] = c["rocco_why_end"] + 4
    end_cues(c, dur, f)
    c["voices"] = [[i, s(c[i])] for i, *_ in SCRIPT] + [["riot_end", s(c["end_vo"])]]
    c["sfx"] = [["tap", s(c["type"] + k * 5), 0.35] for k in range(6)] + [
        ["card_flip", s(c["card_in"]), 0.6], ["rise1", s(c["reveal"]), 0.5], ["rise2", s(c["reveal"] + 7), 0.5],
        ["rise3", s(c["reveal"] + 14), 0.5], ["scratch", s(c["odd"]), 0.45], ["swish", s(c["stare"]), 0.35],
        ["popper", s(c["laugh"] + 2), 0.5], ["sting_fanfare", s(c["end"]), 0.45]]
    c["ambience"] = []
    c["music_segments"] = [["hype", 0.0, s(c["END"]), 0.15, [[s(c["odd"] - 2), s(c["rocco_why_end"])]]]]
    return c
