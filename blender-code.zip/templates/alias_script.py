# "How to play Alias" in Game Night HQ (day), ~30s. Coach Riot teaches the rules through one joke:
# Bash can't stop saying the word. Bash's turn: ASTRONAUT -> "An ASTRO-" -> whistle, skip. Pip's turn:
# BEEKEEPER -> Rocco gets it without looking up -> tick / skip explained -> speed round (Rocco, instantly) ->
# buzzer, "Time! Most points wins!", scoreboard 5-0 -> "I was SO close!" -> everyone laughs, Bash too -> end card.
#   python3 make.py alias --name alias_howto_01
FPS = 30
STANDALONE = True
FORMATS = ("vertical", "horizontal")  # make.py --format
LENGTH = (20, 34)  # a how-to runs longer than the 12-16s joke formats
TITLE = "Alias"
HOOK = "the ONE rule bash\ncan't follow"
TURN1 = "Astronaut"
TURN2 = "Beekeeper"
SPEED = ["Lifeguard", "Magician", "Zookeeper", "Pinocchio"]  # real words from the app's Alias list
SCORES = [("PIP & ROCCO", 5), ("BASH", 0)]

SCRIPT = [  # id, speaker, line, frames of pause before this line
    ("riot_intro", "riot", "Alias! Describe the word. Just don't SAY it.", 10),
    ("bash_astro", "bash", "Easy! Guy in space. Big helmet. An ASTRO...", 20),
    ("riot_skip", "riot", "Ooh. Said it. Skip!", 10),
    ("pip_bee", "pip", "Um... their job is... honey?", 30),
    ("rocco_bee", "rocco", "Beekeeper.", 4),
    ("riot_rules", "riot", "Got it? Tap tick. Stuck? Skip!", 22),
    ("rocco_g1", "rocco", "Lifeguard.", 30),
    ("rocco_g2", "rocco", "Magician.", 22),
    ("rocco_g3", "rocco", "Zookeeper.", 22),
    ("rocco_g4", "rocco", "Pinocchio.", 22),
    ("riot_time", "riot", "Time! Most points wins!", 20),   # gap = the buzzer
    ("bash_close", "bash", "I was SO close!", 26),          # gap = the scoreboard
]


def hook(cfg):
    return (cfg.get("hook") or HOOK).replace("\\n", "\n")


def lines(cfg):
    return [(i, w, t) for i, w, t, _ in SCRIPT] + [("riot_end", "riot", f"{TITLE}. Free on Friendzy.")]


def timeline(cfg, dur):
    f = lambda s: int(round(s * FPS))
    s = lambda fr: round(fr / FPS, 3)
    c, t = {}, 0
    for i, who, text, gap in SCRIPT:
        t += gap
        c[i] = t
        t += f(dur[i])
        c[i + "_end"] = t
    c["whistle1"] = 2                                  # hook: Riot's whistle + the timer slams in
    c["card1"] = c["riot_intro_end"] + 2               # ASTRONAUT
    c["whistle2"] = c["bash_astro_end"] - 2            # cut him off mid-word
    c["cross1"] = c["whistle2"] + 4
    c["turn2"] = c["riot_skip_end"] + 6                # BEEKEEPER, timer resets
    c["tick1"] = c["rocco_bee_end"] + 1
    c["rule_tick"] = c["riot_rules"] + int(f(dur["riot_rules"]) * 0.32)
    c["rule_cross"] = c["riot_rules"] + int(f(dur["riot_rules"]) * 0.72)
    c["speed"] = [c[f"rocco_g{k}"] - 12 for k in (1, 2, 3, 4)]   # card flips; Rocco answers before Pip can start
    c["speed_tick"] = [c[f"rocco_g{k}_end"] + 1 for k in (1, 2, 3, 4)]
    c["time_up"] = c["rocco_g4_end"] + 8
    c["score"] = c["riot_time"] + 12
    c["laugh"] = c["bash_close_end"] + 2
    c["end"] = c["laugh"] + 50
    c["end_vo"] = c["end"] + 4
    c["END"] = c["end_vo"] + f(dur["riot_end"]) + 10
    # countdown shown on the badge: [frame, seconds]. Bash's turn runs in real time; Pip's turn is a
    # fast-forward from 60 to 0 between BEEKEEPER and the buzzer.
    timer = [[c["whistle1"] + 2, 60]]
    for fr in range(c["card1"] + FPS, c["turn2"], FPS):
        timer.append([fr, timer[-1][1] - 1])
    span = c["time_up"] - c["turn2"]
    for fr in range(c["turn2"], c["time_up"] + 1):
        v = max(0, 60 - int(60 * (fr - c["turn2"]) / span))
        if fr == c["turn2"] or v != timer[-1][1]:
            timer.append([fr, v])
    c["timer"] = timer
    c["warn"] = next(fr for fr, v in timer if fr >= c["turn2"] and v <= 10)
    c["voices"] = [[i, s(c[i])] for i, *_ in SCRIPT] + [["riot_end", s(c["end_vo"])]]
    sfx = [
        ["whistle", s(c["whistle1"]), 0.45], ["slam", s(c["whistle1"] + 2), 0.3],
        ["card_flip", s(c["card1"]), 0.6],
        ["whistle", s(c["whistle2"]), 0.55], ["stamp", s(c["cross1"]), 0.4],
        ["card_flip", s(c["turn2"]), 0.6], ["pop", s(c["turn2"] + 4), 0.35],
        ["ting", s(c["tick1"]), 0.5], ["pop", s(c["tick1"] + 6), 0.3],
        ["pop", s(c["rule_tick"]), 0.4], ["pop", s(c["rule_cross"]), 0.4],
        ["buzzer", s(c["time_up"]), 0.5], ["slam", s(c["score"]), 0.35],
        ["popper", s(c["laugh"] + 2), 0.45], ["sting_fanfare", s(c["end"]), 0.45],
    ]
    for fl, tk in zip(c["speed"], c["speed_tick"]):
        sfx += [["card_flip", s(fl), 0.5], ["ting", s(tk), 0.45]]
    sfx += [["tick", s(fr), 0.35] for fr, v in timer if fr >= c["warn"] and 0 < v <= 10]
    c["sfx"] = sfx
    c["ambience"] = []
    c["music"] = ["hype", 0.0, 0.16, s(c["whistle2"]), s(c["riot_skip"])]  # the bed cuts out on the whistle
    return c
