# Blender scene for "Hot Takes" at the Campfire (hottakes_script.py).
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import joke
from joke import *
import hottakes_script as S

J = joke.Joke(S, locations.campfire, {"bash": None, "pip": None, "riot": None, "rocco": None})
C, A = J.C, J.A
r, b, p, k_ = A["riot"], A["bash"], A["pip"], A["rocco"]
loc = J.loc
motion.flicker(loc.extras["flames"], 0, J.END, 0.1)
motion.flicker(loc.extras["glow"], 0, J.END, 0.05, seed=7)
for who in A:
    A[who].expr(0, "happy")
r.expr(0, "hype")
motion.present(r, C["card_in"] - 2, hold=C["riot_topic_end"] - C["card_in"])
J.talk("riot", "riot_topic")
J.listen_all("riot", "riot_topic")
# Bash's rant
b.expr(C["bash_rant"] - 2, "yelling")
J.talk("bash", "bash_rant", energy=1.4)
motion.yell(b, C["bash_rant"], C["bash_rant_end"], 1)
J.listen_all("bash", "bash_rant")
# Pip, small voice
p.expr(C["pip_like"] - 2, "nervous")
J.talk("pip", "pip_like", energy=0.8)
motion.take(b, C["pip_like_end"] + 2, "shocked", 0.9)
for who in ("bash", "riot", "rocco"):
    A[who].look(C["pip_like"] - 2, J.side(who, "pip"), 5)
# Rocco offers his slice; Bash bites (paw to mouth, like Rocco's munch), then caves
J.munch(C["card_in"] + 20, 2)
b.add(lambda fr: None if not (C["bite"] - 8 <= fr <= C["bite"] + 26) else {  # the slice up to his mouth, two bites
    "face1": motion.curve(fr, [(C["bite"] - 8, 0, "linear"), (C["bite"] - 1, 1, "back"), (C["bite"] + 5, 0.8, "smooth"),
                               (C["bite"] + 9, 1, "smooth"), (C["bite"] + 18, 1, "linear"), (C["bite"] + 26, 0, "smooth")]),
    "face_y": -0.9, "hand1": "fist"})
hand = J.ch["bash"].hands[1]["fist"]
slice_ = props.pizza_slice("slice", hand.parent, (hand.location.x, hand.location.y + 0.5), hand.location.z + 0.05, 1.1)
set_visible(slice_, False, 0)
set_visible(slice_, True, C["bite"] - 8)
set_visible(slice_, False, C["bite"] + 26)
b.expr(C["bite"] + 4, "suspicious")
b.expr(C["bash_cave"] - 2, "happy")
J.talk("bash", "bash_cave", energy=0.8)
for who in ("pip", "riot", "rocco"):
    A[who].look(C["bite"] - 6, J.side(who, "bash"), 5)
p.expr(C["bash_cave"] + 4, "hype")
J.laugh_all(C["laugh"], C["end"] - 2, order=("riot", "bash", "pip", "rocco"))
# camera + graphics
CA = J.camera("wide", band=True)
CA.cut(C["card_out"], J.frame("two:bash,pip"))
CA.shake(C["bash_rant"] + 4, 8, 0.25)
CA.push(C["bite"] - 10, C["bite"] - 1, J.frame("close:bash"), "out")
CA.cut(C["laugh"], J.frame("wide"))
J.hook(C["card_out"] - 4)
J.card(props.prompt_card("topic", "hottakes", S.TOPIC, (0, 0), 0.6, w=10.4, size=0.9), C["card_in"], C["card_out"], vxy=(0.0, J.F.hud_y(0.4)))
J.captions(["riot_topic", "bash_rant", "pip_like", "bash_cave"], y_px=1400)
J.confetti(C["laugh"] + 2)
J.finish(S.TITLE)
