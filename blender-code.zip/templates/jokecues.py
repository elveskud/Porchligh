# Pure-Python timing helpers shared by the joke templates' *_script.py files (no Blender imports).


def end_cues(c, dur, f, line_id="riot_end", hold=38):
    """laugh -> end card under 2 s, with Riot's app line starting just before the cut when it's long."""
    c["end"] = c["laugh"] + hold
    lead = max(6, f(dur[line_id]) + 6 - 57)
    c["end_vo"] = c["end"] - lead
    c["END"] = c["end_vo"] + f(dur[line_id]) + 6
    return c


def sequence(c, dur, f, script):
    """Lay out SCRIPT = [(id, speaker, text, pause_before_frames)] one after another from c's current 't'."""
    t = c.get("t", 0)
    for i, _, _, gap in script:
        t += gap
        c[i] = t
        t += f(dur[i])
        c[i + "_end"] = t
    c["t"] = t
    return c
