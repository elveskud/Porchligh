# App features -> real app screenshots (never invented UI). Used by the `feature` template and the episode
# "feature" game beat. Screens are copies of the App Store captures (Friendzy-marketing/app-store-assets/src, made by
# FriendzyUITests/StoreScreenshotsUITests + PartyRoomUITests in screenshot mode) kept in characters/refs/app/.
import os

APP = os.path.normpath(os.path.join(os.path.dirname(os.path.abspath(__file__)), "../characters/refs/app"))

FEATURES = {  # key: (screenshot file or None, label, where it came from)
    "rooms":    ("rooms_lobby.png",   "Party rooms",            "app-store-assets/src/en-iphone-rooms/comeback-lobby.png (ROOM CODE DNTX)"),
    "tonight":  ("tonights_pack.png", "Tonight's Pack",         "app-store-assets/src/en-iphone/K-tonight.png"),
    "roadtrip": ("road_trip.png",     "Road Trip mode",         "app-store-assets/src/en-iphone/K2-roadtrip.png"),
    "classics": ("classic_games.png", "44 classic games",       "app-store-assets/src/en-iphone/I-rules.png"),
    "podium":   ("room_podium.png",   "Room results podium",    "app-store-assets/src/en-iphone-rooms/comeback-podium.png"),
    "spanish":  ("spanish_home.png",  "Now in Spanish",         "app-store-assets/src/es-iphone-rooms/A-home.png"),
    # no capture yet: take one with the UI-test screenshot mode first (StoreScreenshotsUITests / ContentPackUITests)
    "recap":    (None, "Crew / game-night recap", "not captured yet"),
    "share":    (None, "Share-an-answer card",    "not captured yet"),
    "seasonal": (None, "Seasonal packs",          "not captured yet (ContentPackUITests can capture the Halloween pack)"),
}


def shot(key):
    """Absolute path of a feature's real screenshot; refuses features that have none (never invent UI)."""
    if key not in FEATURES:
        raise SystemExit(f"feature: unknown feature {key!r} ({', '.join(FEATURES)})")
    f, label, src = FEATURES[key]
    if not f:
        raise SystemExit(f"feature {key!r} ({label}) has no real screenshot yet: {src}. Capture one, add it to "
                         f"characters/refs/app/ and to FEATURES in templates/features.py.")
    return os.path.join(APP, f)
