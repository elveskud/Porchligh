# Blender scene for "Word Association" in the Party Room (wordassoc_script.py).
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import joke
from joke import *
import wordassoc_script as S

J = joke.Joke(S, locations.party_room, {"bash": None, "pip": None, "riot": None, "rocco": None})
C, A = J.C, J.A
r, b, p, k_ = A["riot"], A["bash"], A["pip"], A["rocco"]
loc = J.loc
loc.extras["code"].data.body = S.WORD.upper()
bpy.data.objects["pr_tv_t"].data.body = "THE WORD IS"
for who in A:
    A[who].expr(0, "happy")
    ph = J.hold_phone(who, 0, C["laugh"] - 2, side=1 if who == "rocco" else -1)
    for k in range(3):
        fr = C["type"] + k * 9 + J.seat[who] * 2
        for f_, v in ((fr, 1.0), (fr + 2, 1.08), (fr + 5, 1.0)):
            ph.scale = (v, v, 1)
            ph.keyframe_insert("scale", frame=f_)
r.expr(0, "hype")
J.talk("riot", "riot_word")
J.listen_all("riot", "riot_word")
# the matches pop up with rising dings and happy hops
for k, who in enumerate(("bash", "pip", "riot")):
    A[who].expr(C["reveal"] + k * 7, "hype")
    motion.hop(A[who], C["reveal"] + k * 7 + 1, 0.35)
# ...then Rocco's. Everyone stares
for who in ("bash", "pip", "riot"):
    A[who].look(C["stare"] + J.seat[who] * 2, J.side(who, "rocco"), 4)
    A[who].expr(C["stare"] + 2, "suspicious")
k_.expr(C["rocco_why"] - 4, "side_eye_l")
J.munch(C["stare"] + 4, 1)
J.talk("rocco", "rocco_why")
motion.shrug(k_, C["rocco_why"] + 4, hold=14)
J.laugh_all(C["laugh"], C["end"] - 2, order=("riot", "pip", "bash", "rocco"))
# camera + graphics
CA = J.camera("wide")
CA.push(C["riot_word"], C["type"] - 2, (lambda x, y, o: (x, y + 0.3, o * 0.94))(*J.frame("wide")), "smooth")
CA.cut(C["reveal"] - 2, J.frame("wide"))
CA.push(C["odd"] + 2, C["rocco_why"] - 1, J.frame("close:rocco"), "out")
CA.cut(C["laugh"], J.frame("wide"))
J.hook(C["card_in"] + 30)
words = dict(S.ANSWERS)
for k, who in enumerate(("bash", "pip", "riot")):
    pl = props.pill(f"w_{who}", words[who], (J.X[who], J.eye(who) + 3.0 + 1.3 * (J.seat[who] % 2)), 22,
                    bg=props.CATEGORY["social"][0], fg="#FFFFFF", size=0.8)
    set_visible(pl, False, 0)
    motion.pop_in(pl, C["reveal"] + k * 7, 6)
    motion.pop_out(pl, C["laugh"] - 4, 4)
odd = props.pill("w_rocco", words["rocco"], (J.X["rocco"], J.eye("rocco") + 4.3), 22, bg=RED, fg="#FFFFFF", size=0.8)
set_visible(odd, False, 0)
motion.slam_in(odd, C["odd"], start=1.8)
motion.pop_out(odd, C["laugh"] - 4, 4)
q = props.emote("odd_q", "question", (J.X["rocco"] + 2.6, J.eye("rocco") + 5.6), 23, 0.9)
set_visible(q, False, 0)
motion.pop_in(q, C["stare"] + 6, 6)
motion.pop_out(q, C["laugh"], 4)
J.captions(["riot_word", "rocco_why"], y_px=1400)
J.confetti(C["laugh"] + 2)
J.finish(S.TITLE)
