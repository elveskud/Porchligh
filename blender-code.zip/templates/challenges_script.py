# "Challenges" in Game Night HQ (day): Riot deals Bash a real physical challenge; Bash is sure; the book lasts 0 seconds.
# Running joke #2: Bash insists he's good at things. He isn't, and he laughs about it.
#   python3 make.py challenges --name challenges_book_01 [--format horizontal]
from jokecues import end_cues, sequence

FPS = 30
STANDALONE = True
FORMATS = ("vertical", "horizontal")
TITLE = "Challenges"
HOOK = "30 seconds.\nhow hard can it be"
CHALLENGE = "Balance a book on your head for 30 seconds."   # real (Friendzy/Models/GamePromptLibraries.swift, Challenges)

SCRIPT = [  # id, speaker, line, pause before (frames)
    ("riot_card", "riot", "Bash. " + CHALLENGE, 12),
    ("bash_easy", "bash", "Easy. Watch this.", 10),
    ("bash_defect", "bash", "...The book was defective.", 44),   # the gap = timer, the drop, the silence
]


def hook(cfg):
    return (cfg.get("hook") or HOOK).replace("\\n", "\n")


def lines(cfg):
    return [(i, w, t) for i, w, t, _ in SCRIPT] + [("riot_end", "riot", f"{TITLE}. Free on Friendzy.")]


def timeline(cfg, dur):
    f = lambda s: int(round(s * FPS))
    s = lambda fr: round(fr / FPS, 3)
    c = {"card_in": 8}
    sequence(c, dur, f, SCRIPT)
    c["card_out"] = c["bash_easy"] - 2
    c["book_on"] = c["bash_easy_end"] + 2
    c["timer"] = c["book_on"] + 8
    c["drop"] = c["timer"] + 8
    c["land"] = c["drop"] + 9
    c["laugh"] = c["bash_defect_end"] + 4
    end_cues(c, dur, f)
    c["voices"] = [[i, s(c[i])] for i, *_ in SCRIPT] + [["riot_end", s(c["end_vo"])]]
    c["sfx"] = [["card_flip", s(c["card_in"]), 0.6], ["pop", s(c["book_on"]), 0.4], ["whistle", s(c["timer"]), 0.35],
                ["tick", s(c["timer"] + 2), 0.4], ["slide_down", s(c["drop"]), 0.45], ["thunk", s(c["land"]), 0.6],
                ["sting_sad_trombone", s(c["land"] + 6), 0.3], ["popper", s(c["laugh"] + 2), 0.5], ["sting_fanfare", s(c["end"]), 0.45]]
    c["ambience"] = []
    c["music_segments"] = [["hype", 0.0, s(c["END"]), 0.15, [[s(c["timer"]), s(c["bash_defect_end"])]]]]
    return c
