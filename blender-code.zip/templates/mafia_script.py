# "Mafia" in the Night Village, Riot in his Mafia costume (pinstripe suit, fedora, round shades, red tie).
# Beats (the app's real flow): Riot privately sees "YOU ARE / Mafia" and smirks -> Narrator: night falls, the windows
# go dark -> day: Bash accuses Pip, Pip protests -> the vote verdict "Pip was... / a Civilian" -> everyone slowly
# turns to Riot -> "Shhh... heh." -> laugh -> end card. Running joke #6: the quiet one is always Riot.
#   python3 make.py mafia --name mafia_quiet_01 [--format horizontal]
from jokecues import end_cues, sequence

FPS = 30
STANDALONE = True
FORMATS = ("vertical", "horizontal")
TITLE = "Mafia"
HOOK = "it's always the\nquiet one"
HOOKS = ["it's always the\nquiet one", "POV: you trusted\nthe quiet friend", "game night\nwent too far"]
VERDICT = ("Pip was…", "a Civilian")   # the app's vote result screen: "<name> was…" + role

SCRIPT = [  # id, speaker, line, pause before (frames)
    ("narr", "narrator", "Night falls on the village...", 50),
    ("bash_accuse", "bash", "It's PIP! I KNOW it was you!", 10),
    ("pip_innocent", "pip", "I-I'm innocent!", 6),
]


def hook(cfg):
    return (cfg.get("hook") or HOOK).replace("\\n", "\n")


def lines(cfg):
    return [(i, w, t) for i, w, t, _ in SCRIPT] + [("riot_shh", "riot", "Shhh... heh."), ("riot_end", "riot", f"{TITLE}. Free on Friendzy.")]


def timeline(cfg, dur):
    f = lambda s: int(round(s * FPS))
    s = lambda fr: round(fr / FPS, 3)
    c = {"role_in": 2, "smirk": 22, "role_out": 44}
    sequence(c, dur, f, SCRIPT)
    c["dark"] = c["narr"] + 10
    c["day"] = c["narr_end"] + 4
    c["verdict"] = c["pip_innocent_end"] + 8
    c["turn"] = c["verdict"] + 34
    c["riot_shh"] = c["turn"] + 12
    c["riot_shh_end"] = c["riot_shh"] + f(dur["riot_shh"])
    c["laugh"] = c["riot_shh_end"] + 4
    end_cues(c, dur, f)
    c["voices"] = [[i, s(c[i])] for i, *_ in SCRIPT] + [["riot_shh", s(c["riot_shh"])], ["riot_end", s(c["end_vo"])]]
    c["sfx"] = [
        ["pop", s(c["role_in"]), 0.4], ["sting_dun_dun_dunnn", s(c["role_in"] + 6), 0.4], ["ting", s(c["smirk"]), 0.35],
        ["whoosh", s(c["narr"] - 4), 0.4], ["boom", s(c["dark"]), 0.35],
        ["whoosh", s(c["day"]), 0.3], ["slam", s(c["bash_accuse"] + 6), 0.25],
        ["card_flip", s(c["verdict"]), 0.6], ["sting_sad_trombone", s(c["verdict"] + 14), 0.3],
        ["swish", s(c["turn"]), 0.4], ["swish", s(c["turn"] + 4), 0.3],
        ["popper", s(c["laugh"] + 2), 0.5], ["sting_fanfare", s(c["end"]), 0.45],
    ]
    c["ambience"] = []
    c["music_segments"] = [["suspense", 0.0, s(c["laugh"]), 0.2, [[s(c["verdict"] - 2), s(c["laugh"])]]],
                           ["hype", s(c["laugh"]), s(c["END"]), 0.16, []]]
    return c
