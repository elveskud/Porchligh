# Blender scene for "Most Likely To" in the car (mlt_script.py).
#   Blender --background --python mlt_scene.py -- <video dir>
import os, sys, json
HERE_T = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE_T, "../characters"))
sys.path.insert(0, HERE_T)
from toon import *
import cast, props, locations, motion, layout
import mlt_script as S

OUT = sys.argv[sys.argv.index("--") + 1]
cfg = json.load(open(os.path.join(OUT, "config.json")))
C = json.load(open(os.path.join(OUT, "cues.json")))
END = C["END"]
vo = lambda i: os.path.join(OUT, "vo", f"{i}.wav")
text_of = {i: t for i, _, t in S.lines(cfg)}

F = layout.from_cfg(cfg)
V = F.vertical  # the 9:16 numbers below are the original ones; 16:9 has its own framing
TS = F.text_scale
sc = reset()
F.setup(sc, OFFBLACK)
sc.frame_start, sc.frame_end = 0, END

# ---------- set & cast: Pip + Rocco in the back, Riot shotgun, Bash driving ----------
loc = locations.car()
if not V:
    locations.widen(loc)
seat = {"pip": 0, "rocco": 1, "riot": 2, "bash": 3}
ch = {"bash": cast.bear(), "pip": cast.bunny(), "riot": cast.riot(), "rocco": cast.raccoon()}
for k, c in ch.items():
    loc.seat(c, seat[k])
set_visible(ch["pip"].extras["sweat"], False)
A = {k: motion.Anim(c) for k, c in ch.items()}
r, b, p, k_ = A["riot"], A["bash"], A["pip"], A["rocco"]
locations.drive(loc, 0, END, 1.0)

# Riot reads the card, turned toward the back seat
r.expr(0, "hype")
r.look(4, 0.7, 8)
motion.present(r, C["riot_q"] + 2, hold=C["riot_q_end"] - C["riot_q"] - 4)
motion.talk(r, C["riot_q"], vo("riot_q"), text=text_of["riot_q"])
b.expr(0, "happy")
p.expr(0, "happy")
p.look(C["riot_q"] + 4, -0.6, 8)
b.look(C["riot_q"] + 20, -0.5, 8)   # glances back, eyes mostly on the road
b.look(C["riot_q_end"] - 10, 0.0, 8)
beats = [C["riot_q"] + e for e in motion.phrase_ends(vo("riot_q"))]
motion.listen(p, C["riot_q"] + 6, C["riot_q_end"] + 4, -1.0, beats)
motion.listen(b, C["riot_q"] + 6, C["riot_q_end"] + 4, -0.3, beats, 0.6)  # small nods: he's driving
# Rocco is asleep the whole time Riot reads
k_.expr(0, "sleepy")
k_.add(lambda fr: {"head_rot": -7 + 2 * math.sin(fr * 0.12), "head_y": -0.06} if fr < C["point"] + 6 else None)

# everyone points at Rocco at once
for who in ("riot", "pip"):
    motion.point_at(A[who], C["point"] + (1 if who == "pip" else 0), 1, hold=C["rocco_wake_end"] - C["point"], expr="cocky")
b.expr(C["point"] + 2, "side_eye_l")  # hands stay on the wheel
p.look(C["point"], 1.0, 4)
r.look(C["point"], 0.9, 4)
b.look(C["point"], -0.8, 4)
# Rocco wakes with a start, then denies it
motion.take(k_, C["point"] + 6, "shocked", 0.7)
k_.look(C["point"] + 10, -0.6, 5)
k_.expr(C["rocco_wake"], "suspicious")
motion.talk(k_, C["rocco_wake"], vo("rocco_wake"), text=text_of["rocco_wake"])
# Pip calls him out, laughing
p.expr(C["pip_call"], "laughing")
motion.talk(p, C["pip_call"], vo("pip_call"), text=text_of["pip_call"])
# everyone laughs, Rocco too
for who, a in A.items():
    motion.laugh(a, C["laugh"] + {"riot": 0, "pip": 5, "bash": 2, "rocco": 9}[who], C["end"] - 2)
    a.look(C["laugh"] + 6, 0.0, 6)
motion.shrug(k_, C["laugh"] - 4, hold=14)
for a in A.values():
    a.bake(0, END)

# ---------- props ----------
hook = props.caption_box("hook", S.hook(cfg), (0.6, 17.4), 21, w=11.2, size=1.0)  # 16:9: moved onto the camera layer below
set_visible(hook, False, 0)
motion.pop_in(hook, 1, 6, 1.1, 2)
motion.pop_out(hook, C["point"] - 6, 5)
card = props.prompt_card("card", "mlt", S.PROMPT, (0.4, 13.6), 20, w=10.4, size=0.72)  # 16:9: camera layer below
set_visible(card, False, 0)
motion.card_flip_in(card, C["riot_q"] + 6)
motion.pop_out(card, C["point"] - 2, 5)
sc.frame_set(0)
rh = ch["rocco"].extras["head"].matrix_world.translation.copy()
zz = props.emote("zz", "zzz", (rh.x + 0.8, rh.y + 2.0), 21, 0.8)
set_visible(zz, False, 0)
motion.pop_in(zz, 8, 6)
motion.float_up(zz, 14, C["point"] + 6, 0.6)
ex = props.emote("ex", "exclaim", (rh.x - 0.2, rh.y + 2.6), 22, 0.9)
set_visible(ex, False, 0)
motion.pop_in(ex, C["point"] + 7, 5)
motion.pop_out(ex, C["rocco_wake"] + 4, 4)
cf = props.confetti("cf", (0.6, 14.5), 23, spread=4.5 if V else 8.0)  # above the heads, so it rains down instead of covering faces
set_visible(cf, False, 0)
motion.burst(cf, C["laugh"] + 2, 30)

# ---------- camera ----------
wide = loc.cam if V else loc.cam_h
cam = F.camera(sc, *wide)
CA = motion.CamAnim(cam, wide, loc.parallax)
CA.intro()                                                           # moving from frame 0
CA.push(C["riot_q"], C["riot_q_end"], (0.4, 9.2, 23.0) if V else (0.0, 8.5, 11.4), "smooth")
CA.push(C["point"] + 4, C["point"] + 16, (0.9, 8.6, 15.0) if V else (0.6, 9.4, 8.0), "out")    # punch in on the back seat
CA.shake(C["point"] + 4, 10, 0.3)
CA.cut(C["laugh"], wide)                                              # held through the lines, then cut wide for the laugh
if not V:  # 16:9: hook top-left and card top-right ride on the camera layer, above the back row
    hud = empty("hud", cam, (0, 0), -8)
    CA.hud(hud)
    for o, xy, k in ((hook, (-10.4, 8.4), 1.2), (card, (11.6, 7.5), 1.2)):
        holder = empty(o.name + "_at", hud, xy, o.location.z - 30)
        holder.scale = (k, k, 1)
        o.parent = holder
        o.location = (0, 0, 0)
EX = 100.0
CA.cut(C["end"], (EX, 9.0, 22.0))
for i in ("rocco_wake", "pip_call"):
    CA.hud(props.word_captions(i, cam, motion.word_times(text_of[i], vo(i)), C[i], y_px=1320) if V else
           props.word_captions(i, cam, motion.word_times(text_of[i], vo(i)), C[i], fmt=F.fmt, y_frac=0.8, max_chars=22, size=1.45 * TS))
CA.bake(0, END)

# ---------- end card ----------
props.end_card("end", f"{S.TITLE} · free on Friendzy", (EX, 9.0), -5, **({} if V else {"fmt": F.fmt}))
er = cast.riot()
er.root.location = (EX, -12.5, 2) if V else (EX + 10.5, -15.5, 2)
er.root.scale = (1.15, 1.15, 1) if V else (1.75, 1.75, 1)
ea = motion.Anim(er)
ea.expr(0, "hype")
motion.talk(ea, C["end_vo"], vo("riot_end"), text=text_of["riot_end"])
mid = (C["end"] + END) // 2  # wave, then a thumbs up: never one pose for the whole card
motion.wave(ea, C["end"] + 4, mid + 4, side=-1)
motion.thumbs_up(ea, mid, hold=END - mid - 10)
ea.add(lambda fr: {"y": 7.0 * motion.curve(fr, [(C["end"], 0, "linear"), (C["end"] + 8, 1.0, "back")]) / 1.15})
ea.bake(C["end"] - 1, END)
for i in range(8):
    l = bpy.data.objects[f"end_l{i}"]
    set_visible(l, False, 0)
    motion.pop_in(l, C["end"] + 2 + i * 2, 5, 1.3, 8)
sub = bpy.data.objects["end_sub"]
set_visible(sub, False, 0)
motion.pop_in(sub, C["end"] + 20, 6)

bpy.ops.wm.save_as_mainfile(filepath=os.path.join(OUT, "scene.blend"))
frames = os.environ.get("FRAMES")
if frames:
    for fr in map(int, frames.split(",")):
        still(sc, os.path.join(OUT, "stills", f"s_{fr:04d}.png"), fr)
else:
    sc.render.filepath = os.path.join(OUT, "frames", "f_")
    bpy.ops.render.render(animation=True)
