# Shared scaffolding for the 10-15 s game joke templates (mafia, trivia, room, hottakes, challenges, spy,
# closecall, wordassoc): set + cast, framing for 9:16 and 16:9, the camera-attached HUD, hook, captions,
# end card and render. Each <game>_scene.py builds a Joke, adds its own beats, then calls finish().
#   J = joke.Joke(S, locations.village_night, {"bash": None, "pip": None, "riot": "mafia", "rocco": None})
import os, sys, json
HERE_T = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE_T, "../characters"))
from toon import *
from mathutils import Vector
import cast, props, locations, motion, layout

SEATS = {"bash": 0, "pip": 1, "riot": 2, "rocco": 3}
MAKE = {"riot": lambda cos: cast.riot(cos or "hoodie"), "bash": lambda cos: cast.bear(), "pip": lambda cos: cast.bunny(),
        "rocco": lambda cos: cast.raccoon()}


class Joke:
    def __init__(self, S, build_loc, cast_map, seats=None, bg=OFFBLACK):
        self.S = S
        self.OUT = sys.argv[sys.argv.index("--") + 1]
        self.cfg = json.load(open(os.path.join(self.OUT, "config.json")))
        self.C = json.load(open(os.path.join(self.OUT, "cues.json")))
        self.END = self.C["END"]
        self.text_of = {i: t for i, _, t in S.lines(self.cfg)}
        self.F = layout.from_cfg(self.cfg)
        self.V = self.F.vertical
        self.TS = self.F.text_scale
        self.sc = reset()
        self.F.setup(self.sc, bg)
        self.sc.frame_start, self.sc.frame_end = 0, self.END
        self.loc = build_loc()
        if not self.V:
            locations.widen(self.loc)
        self.seat = dict(SEATS, **(seats or {}))
        self.ch, self.A = {}, {}
        for who, cos in cast_map.items():
            c = MAKE[who](cos)
            self.loc.seat(c, self.seat[who])
            if who == "pip":
                set_visible(c.extras["sweat"], False)
            self.ch[who] = c
            self.A[who] = motion.Anim(c)
        self.X = {k: self.loc.seats[self.seat[k]][0] for k in cast_map}
        self.cam = self.CA = None
        self.hud = None

    # ---- helpers ----
    def vo(self, i):
        return os.path.join(self.OUT, "vo", f"{i}.wav")

    def beats(self, i):
        return [self.C[i] + e for e in motion.phrase_ends(self.vo(i))]

    def side(self, who, at):
        return 1.0 if self.X[at] > self.X[who] else -1.0

    def eye(self, who="riot"):
        _, hip, s, _ = self.loc.seats[self.seat[who]]
        return hip + 5.4 * s

    def talk(self, who, i, **kw):
        motion.talk(self.A[who], self.C[i], self.vo(i), text=self.text_of[i], **kw)

    def listen_all(self, speaker, i, skip=()):
        for who, a in self.A.items():
            if who != speaker and who not in skip:
                a.look(self.C[i] - 4, self.side(who, speaker), 6)
                motion.listen(a, self.C[i] + 2, self.C[i + "_end"] + 4, self.side(who, speaker), self.beats(i))

    def munch(self, f, n=2, who="rocco"):
        """Rocco: chips up to the mouth and back, n times (left paw holds the bag). Returns the end frame."""
        keys = [(f, 8, "linear")]
        for i in range(n):
            keys += [(f + 6 + i * 10, -128, "back"), (f + 11 + i * 10, -95, "smooth")]
        keys.append((f + 12 + n * 10, 8, "smooth"))
        self.A[who].add(lambda fr: None if not (f <= fr <= keys[-1][0]) else
                        {"arm-1": -8, "hand-1": "fist", "elbow-1": motion.curve(fr, keys)})
        return keys[-1][0]

    def upright(self, who, side, arm, elbow):
        """Local z-rotation that keeps a prop on this forearm upright while the arm is posed at (arm, elbow):
        poses the arm, measures the forearm's world rotation, then puts the arm back."""
        c = self.ch[who]
        hand = c.hands[side]["paw"]
        a, e = c.arms[side].rotation_euler.z, c.elbows[side].rotation_euler.z
        c.arm(side, arm, elbow=elbow)
        bpy.context.view_layer.update()
        m = hand.parent.matrix_world
        rot = m.to_euler().z
        mirrored = m.to_3x3().determinant() < 0  # left limbs are mirrored: a child's rotation then subtracts
        c.arms[side].rotation_euler.z, c.elbows[side].rotation_euler.z = a, e
        bpy.context.view_layer.update()
        return (rot if mirrored else -rot), mirrored

    def _grip(self, who, side, arm, elbow, off):
        """An empty in the paw that stays upright and un-mirrored while the arm holds (arm, elbow): the left limbs
        are mirrored, so it flips back on that side, then keeps whichever rotation measures upright with the arm posed."""
        c = self.ch[who]
        hand = c.hands[side]["paw"]
        g = empty(f"grip_{who}{side}_{len(bpy.data.objects)}", hand.parent, (hand.location.x + off[0], hand.location.y + off[1]),
                  hand.location.z + 0.05)
        a0, e0 = c.arms[side].rotation_euler.z, c.elbows[side].rotation_euler.z
        c.arm(side, arm, elbow=elbow)
        bpy.context.view_layer.update()
        if hand.parent.matrix_world.to_3x3().determinant() < 0:
            g.scale.x = -1  # flip back so the screen and logo read the right way
        best = None
        for k in range(72):  # 5-degree steps, then refine
            g.rotation_euler.z = math.radians(5 * k)
            bpy.context.view_layer.update()
            err = abs(math.atan2(math.sin(g.matrix_world.to_euler().z), math.cos(g.matrix_world.to_euler().z)))
            if best is None or err < best[0]:
                best = (err, g.rotation_euler.z)
        g.rotation_euler.z = best[1]
        bpy.context.view_layer.update()
        g.rotation_euler.z -= g.matrix_world.to_euler().z * (1 if g.matrix_world.to_3x3().determinant() > 0 else -1)
        c.arms[side].rotation_euler.z, c.elbows[side].rotation_euler.z = a0, e0
        bpy.context.view_layer.update()
        return g

    def hold_phone(self, who, f0, f1, s=1.0, side=-1, arm=5, elbow=-60):
        """A phone (the Friendzy app on screen) in one paw, forearm raised in front of the shoulder, from f0 to f1.
        Seated characters' chests are hidden by the furniture, so the phone rides on the forearm, not at the chest.
        Like the host's mic: a closed paw keeps the arm in front of the neighbours, and the phone is counter-rotated
        to stay upright. Left paw by default, so the right one is free to point. Returns the phone (bump it for typing)."""
        c = self.ch[who]
        hand = c.hands[side]["paw"]
        ph = props.phone(f"phone_{who}", self._grip(who, side, arm, elbow, (0, 0)), (0, 0), 0.0, s)
        set_visible(ph, False, 0)
        set_visible(ph, True, f0)
        set_visible(ph, False, f1)
        self.A[who].add(lambda fr: None if not (f0 - 6 <= fr <= f1 + 6) else {
            f"arm{side}": 10 + (arm - 10) * motion.envelope(fr, f0 - 6, f1 + 6, 6),
            f"elbow{side}": 8 + (elbow - 8) * motion.envelope(fr, f0 - 6, f1 + 6, 6), f"hand{side}": "fist"})
        return ph  # (paw at belly height, a little out to the side: the whole face and mouth stay visible)

    def pills(self, words, f_in, f_out, stagger=6, color=OFFBLACK, fg=CHALK, size=1.0, dy=3.1):
        """Answers popping up above heads, one after another: words = [(who, text)]. Returns {who: pill}."""
        out = {}
        for k, (who, word) in enumerate(words):
            pl = props.pill(f"pill_{who}", word, (self.X[who], self.eye(who) + dy), 22, bg=color, fg=fg, size=size)
            set_visible(pl, False, 0)
            motion.pop_in(pl, f_in + k * stagger, 6)
            motion.pop_out(pl, f_out, 4)
            out[who] = pl
        return out

    def hold_screen(self, who, shot, f0, f1, side=1, h=2.4):
        """Hold up a phone showing a real app screenshot (props.app_phone): forearm raised like the host's mic."""
        c = self.ch[who]
        hand = c.hands[side]["paw"]
        ph = props.app_phone(f"screen_{who}", shot, self._grip(who, side, 16, 98, (0, 0.4)), (0, 0), 0.0, h)
        set_visible(ph, False, 0)
        set_visible(ph, True, f0)
        set_visible(ph, False, f1)
        self.A[who].add(lambda fr: None if not (f0 - 6 <= fr <= f1 + 6) else {
            f"arm{side}": 10 + 6 * motion.envelope(fr, f0 - 6, f1 + 6, 6),
            f"elbow{side}": 8 + 90 * motion.envelope(fr, f0 - 6, f1 + 6, 6), f"hand{side}": "fist"})
        return ph

    def shh(self, who, f0, f1):
        """Finger to the lips (Riot's "Shhh..."), leaning in."""
        self.A[who].add(lambda fr: None if not (f0 <= fr <= f1 + 8) else {
            "face1": motion.curve(fr, [(f0, 0, "linear"), (f0 + 5, 1, "back"), (f1, 1, "linear"), (f1 + 8, 0, "smooth")]),
            "hand1": "point", "face_y": -2.2, "head_y": 0.12 * motion.envelope(fr, f0, f1 + 8)})

    def frame(self, spec="wide", band=False):
        """Camera (x, y, ortho): 'wide', 'close:<who>', 'two:<a>,<b>'. band=True lifts the wide shot so a card fits above."""
        if spec == "wide":
            x, y, o = self.loc.cam if self.V else self.loc.cam_h
            if band:
                return self.F.eye_framing(x, self.eye(), o * (0.84 if self.V else 1.0), 0.68 if self.V else 0.6)
            return (x, y, o)
        kind, _, who = spec.partition(":")
        names = who.split(",")
        if kind == "close" and len(names) == 1:
            if self.V:
                return (self.X[names[0]] + 0.3, self.eye(names[0]) + 0.4, 13.0)
            return self.F.clean_close(self.loc, self.seat[names[0]], 7.5, self.eye(names[0]), 0.46)
        xs = [self.X[n] for n in names]
        if self.V:
            return ((min(xs) + max(xs)) / 2 + 0.2, self.eye(names[0]) + 0.4, max(14.0, (max(xs) - min(xs) + 4.6) / self.F.aspect))
        return self.F.clean_span(self.loc, [self.seat[n] for n in names], self.eye(names[0]), 0.46)

    def camera(self, start="wide", band=False):
        f0 = self.frame(start, band)
        self.cam = self.F.camera(self.sc, *f0)
        self.CA = motion.CamAnim(self.cam, f0, self.loc.parallax)
        self.CA.intro()
        self.hud = empty("hud", self.cam, (0, 0), -8)
        self.CA.hud(self.hud)
        return self.CA

    def on_hud(self, o, vxy, hxy, s=1.0, hs=None):
        """Pin a prop to the camera layer: vxy for 9:16 (HUD units, ortho 22), hxy for 16:9; 16:9 also scales by text_scale."""
        holder = empty(o.name + "_at", self.hud, vxy if self.V else hxy, o.location.z)
        k = s if self.V else (hs if hs is not None else s * self.TS)  # hs: an explicit 16:9 scale
        holder.scale = (k, k, 1)
        o.parent = holder
        o.location = (0, 0, 0)
        return o

    HALF_W, HALF_H, MARGIN = 19.55, 11.0, 0.9  # the 16:9 camera layer (ortho 22) and the margin from its edges

    def extent(self, o):
        """(width, height) of a prop's drawing in its own units (all mesh/text children)."""
        bpy.context.view_layer.update()
        inv = o.matrix_world.inverted()
        xs, ys = [], []
        for ch in [o] + list(o.children_recursive):
            if ch.type in ("MESH", "FONT"):
                for corner in ch.bound_box:
                    p = inv @ (ch.matrix_world @ Vector(corner))
                    xs.append(p.x)
                    ys.append(p.y)
        return (max(xs) - min(xs), max(ys) - min(ys)) if xs else (1.0, 1.0)

    def fit16(self, o, corner="right", max_w=14.5, max_h=9.6, max_k=1.6):
        """16:9: scale a card to NHIE-card size (max_w x max_h HUD units) and pin it to the top corner with a margin."""
        w, h = self.extent(o)
        k = min(max_w / w, max_h / h, max_k)
        x = (self.HALF_W - self.MARGIN - w * k / 2) * (1 if corner == "right" else -1)
        return (x, self.HALF_H - self.MARGIN - h * k / 2), k

    def hook(self, f_out):
        """The hook caption (named 'hook' for QA), on from frame 1."""
        text_ = self.S.hook(self.cfg)
        if self.V:
            h = self.on_hud(props.caption_box("hook", text_, (0, 0), 1.0, w=10.4, size=0.95), (0.0, self.F.hud_y(0.17)), None)
        else:  # 16:9: the box fits its text and sits top-left with a margin, clear of a TV or sign in the middle
            longest = max(len(l) for l in text_.split("\n"))
            box = props.caption_box("hook", text_, (0, 0), 1.0, w=max(5.0, longest * 0.95 * 0.52 + 1.4), size=0.95)
            xy, k = self.fit16(box, "left", max_w=13.0, max_h=6.0, max_k=self.TS)
            h = self.on_hud(box, None, xy, 1.0, hs=k)
        set_visible(h, False, 0)
        motion.pop_in(h, 1, 6, 1.1, 2)
        motion.pop_out(h, f_out, 5)
        return h

    def card(self, o, f_in, f_out, vxy=None, hxy=None, s=1.0, flip=True, hs=None):
        """A card on the camera layer. 9:16: at vxy, scale s. 16:9: always auto-fitted to NHIE-card size in the top-right
        corner with a margin (hxy/hs are ignored, so every template's 16:9 cards read the same)."""
        if not self.V:
            hxy, hs = self.fit16(o)
        o = self.on_hud(o, vxy or (0.0, self.F.hud_y(0.3)), hxy, s, hs)
        set_visible(o, False, 0)
        (motion.card_flip_in if flip else motion.pop_in)(o, f_in)
        motion.pop_out(o, f_out, 5)
        return o

    def captions(self, ids, y_px=1300):
        """Word-by-word captions; y_px (9:16) 1300 sits above the bottom safe zone, 1440 for low 'band' framings."""
        for i in ids:
            words = motion.word_times(self.text_of[i], self.vo(i))
            self.CA.hud(props.word_captions(f"cap_{i}", self.cam, words, self.C[i], y_px=y_px) if self.V else
                        props.word_captions(f"cap_{i}", self.cam, words, self.C[i], fmt=self.F.fmt, y_frac=0.8,
                                            max_chars=22, size=1.45 * self.TS))

    def confetti(self, f):
        cf = props.confetti("cf", (self.frame("wide")[0], self.eye() + 6.6), 23, spread=4.5 if self.V else 8.0)
        set_visible(cf, False, 0)
        motion.burst(cf, f, 30)

    def laugh_all(self, f, f_end, order=("riot", "bash", "pip", "rocco")):
        for k, who in enumerate(w for w in order if w in self.A):
            motion.laugh(self.A[who], f + k * 3, f_end)
            self.A[who].look(f + k * 3 + 4, 0.0, 6)

    def finish(self, title, costume="hoodie", line_id="riot_end"):
        """Bake the cast, add the end card (cut at C['end']), bake the camera, save and render."""
        C, END = self.C, self.END
        for a in self.A.values():
            a.bake(0, END)
        EX = 100.0
        self.CA.cut(C["end"], (EX, 9.0, 22.0))
        props.end_card("end", f"{title} · free on Friendzy", (EX, 9.0), -5, fmt=self.F.fmt)
        er = cast.riot(costume)
        er.root.location = (EX, -12.5, 2) if self.V else (EX + 10.5, -15.5, 2)
        er.root.scale = (1.15, 1.15, 1) if self.V else (1.75, 1.75, 1)
        ea = motion.Anim(er)
        ea.expr(0, "hype")
        motion.talk(ea, C["end_vo"], self.vo(line_id), text=self.text_of[line_id])
        mid = (C["end"] + END) // 2
        motion.wave(ea, C["end"] + 4, mid - 2, side=-1)
        motion.thumbs_up(ea, mid, hold=max(8, END - mid - 10))
        ea.add(lambda fr: {"y": 7.0 * motion.curve(fr, [(C["end"], 0, "linear"), (C["end"] + 6, 1.0, "back")]) / 1.15})
        ea.bake(C["end"] - 1, END)
        for i in range(8):
            l = bpy.data.objects[f"end_l{i}"]
            set_visible(l, False, 0)
            motion.pop_in(l, C["end"] + 1 + i * 2, 5, 1.3, 8)
        sub = bpy.data.objects["end_sub"]
        set_visible(sub, False, 0)
        motion.pop_in(sub, C["end"] + 14, 6)
        self.CA.bake(0, END)
        bpy.ops.wm.save_as_mainfile(filepath=os.path.join(self.OUT, "scene.blend"))
        frames = os.environ.get("FRAMES")
        if frames:
            for fr in map(int, frames.split(",")):
                still(self.sc, os.path.join(self.OUT, "stills", f"s_{fr:04d}.png"), fr)
        else:
            self.sc.render.filepath = os.path.join(self.OUT, "frames", "f_")
            bpy.ops.render.render(animation=True)

