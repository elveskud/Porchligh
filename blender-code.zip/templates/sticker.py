# GIPHY stickers: transparent, seamlessly looping GIF + WebM clips of Riot, made from the motion library.
#
#   python3 Blender/templates/sticker.py hype                      # -> Blender/videos/stickers/riot_hype/
#   python3 Blender/templates/sticker.py laughing --costume dare --seconds 2 --size 480 --name riot_laugh_dare
#   python3 Blender/templates/sticker.py all                       # every sticker in STICKERS
#
# How the loop is made seamless:
#   - every channel (body bounce, arms, head, breathing, tail sway) is a function of (frame mod N), so the drive is
#     exactly periodic; the moves from motion.py are captured and replayed on that clock;
#   - the scene is baked from 2+ loops BEFORE frame 0, so the ear/tail springs have settled into the same
#     cycle by the time the rendered loop starts (frame N == frame 0);
#   - motion.Anim's own idle is switched off (its 78f breath / 64f tail / random blinks don't fit N) and replaced
#     by a periodic one; the slow drift Anim adds to raised arms (43f / 57f) is cancelled and redone on the loop clock;
#   - blinks are re-keyed at fixed loop positions.
#   The script renders frame N as well and checks it against frame 0 (pixel difference is printed).
#
# Output (Blender/videos/stickers/<name>/): <name>.gif, <name>.webm (VP9 + alpha), frames/0000.png... (RGBA),
# preview.png (first / middle / last / first-again on a checkerboard).
import os, sys, math, json, time, shutil, argparse, subprocess

HERE = os.path.dirname(os.path.abspath(__file__))
CHARS = os.path.normpath(os.path.join(HERE, "..", "characters"))
OUT_ROOT = os.path.realpath(os.path.join(HERE, "..", "videos", "stickers"))
BLENDER = "/Applications/Blender.app/Contents/MacOS/Blender"
FPS = 30
RAW = 1200          # raw render size (square); cropped and scaled down afterwards (supersampled edges)
MAX_BYTES = 8 * 1024 * 1024
COSTUMES = ("hoodie", "mafia", "dare", "coach", "host")

# name -> settings. quantum: the loop length N (frames) is rounded to a multiple of it; min: shortest N that works.
# cam = (x, y, ortho) for the raw render; it only has to contain the whole motion (the crop is automatic).
STICKERS = {
    "hype":     dict(quantum=2,  min=46, cam=(0.4, 7.9, 17.5), desc="two happy hops, fists pumping in the air"),
    "laughing": dict(quantum=1,  min=30, cam=(0.4, 7.0, 16.0), desc="belly laugh, paws on the belly, ^ ^ eyes"),
    "shocked":  dict(quantum=1,  min=48, cam=(0.4, 7.4, 16.5), desc="shocked take, frozen trembling, back to a grin"),
    "drumroll": dict(quantum=6,  min=24, cam=(0.4, 7.0, 16.0), desc="gritted teeth, paws drumming on the belly"),
    "waving":   dict(quantum=12, min=24, cam=(0.4, 7.0, 16.0), desc="friendly wave that never stops"),
}


# =====================================================================================================
# Blender side: build Riot, animate one loop, render raw RGBA frames 0..N (frame N is the loop check)
# =====================================================================================================

class Collector:
    """Stands in for motion.Anim so a motion.py move can be captured and replayed on the loop clock."""
    def __init__(self, c, seed):
        self.c, self.seed, self.layers = c, seed, []

    def add(self, fn):
        self.layers.append(fn)

    def expr(self, frame, name):   # stickers own their expression timeline
        pass

    def at(self, frame, fn, prio=1):
        pass

    def look(self, frame, t, dur=6, ease="look"):
        pass


def blender_main(argv):
    import bpy
    sys.path.insert(0, CHARS)
    from toon import reset, setup_render, camera, OFFBLACK
    import cast, motion
    from motion import curve, envelope, ADD, MUL

    kind, costume, N, rawdir = argv[0], argv[1], int(argv[2]), argv[3]
    spec = STICKERS[kind]
    sc = reset()
    setup_render(sc, RAW, RAW, FPS)
    sc.render.film_transparent = True
    sc.render.image_settings.file_format = "PNG"
    sc.render.image_settings.color_mode = "RGBA"
    sc.render.image_settings.color_depth = "8"
    camera(sc, *spec["cam"])

    c = cast.riot(costume)
    seed = sum(map(ord, c.name))
    TAU = 2 * math.pi

    def ph(f, period=N, off=0.0):
        return TAU * ((f % N) / period) + off

    # ---------- one loop, as layer functions of the absolute frame (all periodic in N) ----------
    layers, exprs, blinks = [], [], []   # exprs: [(offset, name)], blinks: loop offsets

    def replay(move, *args, seed_override=None, **kw):
        col = Collector(c, seed if seed_override is None else seed_override)
        move(col, *args, **kw)
        layers.extend((lambda L: lambda fr: L(fr % N))(L) for L in col.layers)   # the move replays every loop

    BIG = N * 100000  # a frame span long enough that envelope() is 1 everywhere we bake (a multiple of N)

    if kind == "hype":
        exprs[:] = [(0, "hype")]
        half = N // 2
        replay(lambda a: (motion.hop(a, 0, 0.75), motion.hop(a, half, 0.75)))
        def pump(t):  # arms dip on the crouch, fling up at the top of the hop, settle on landing
            return curve(t, [(0, 0, "linear"), (3, -0.7, "out"), (8, 1.0, "out"), (13, 0.0, "in"), (16, -0.35, "out"), (24, 0, "smooth")])
        def arms_up(fr):
            t = fr % half
            p1, p2 = pump(t), pump((t - 1) % half)   # left fist trails by a frame
            return {"arm1": 126 + 12 * p1, "arm-1": 126 + 12 * p2, "elbow1": 26 - 14 * p1, "elbow-1": 26 - 14 * p2,
                    "hand1": "fist", "hand-1": "fist", "head_rot": 4 * math.sin(ph(fr)), "ears": -6 * max(0.0, p1)}
        layers.append(arms_up)
        blinks[:] = [round(N * 0.7)]

    elif kind == "laughing":
        exprs[:] = [(0, "laughing")]
        # motion.laugh's bounce (`beat`) and head rock periods come from the seed: pick one whose periods divide N
        best = None
        for s in range(2000):
            beat, rock = 4 + (s % 7) * 0.5, 12 + s % 9
            err = abs(N / beat - round(N / beat)) + abs(N / rock - round(N / rock))
            score = (err > 1e-9, abs(beat - 5.5), abs(rock - 16), s % 3 == 0)
            if best is None or score < best[0]:
                best = (score, s)
        s = best[1]
        if best[0][0]:
            print(f"WARNING: no laugh tempo divides {N} frames exactly; the loop may hitch")
        replay(motion.laugh, -BIG, BIG, seed_override=s)
        layers.append(lambda fr: {"head_y": 0.04 * math.sin(ph(fr, N / 2))})

    elif kind == "shocked":
        f = 3
        exprs[:] = [(0, "hype"), (f + 3, "shocked"), (N - 9, "hype")]
        replay(motion.take, f, "shocked", 1.0)
        def tremble(fr):
            t = fr % N
            k = envelope(t, f + 14, N - 12, 5)
            if not k:
                return None
            return {"x": 0.03 * k * math.sin(t * 2.9), "head_rot": 1.6 * k * math.sin(t * 2.3), "brow": 0.05 * k, "sq": 1 + 0.02 * k}
        layers.append(tremble)
        blinks[:] = [N - 9 - 2]   # the blink that hides the face swap back to the grin

    elif kind == "drumroll":
        exprs[:] = [(0, "drumroll")]
        def drum(fr):
            t = fr % N
            hit = lambda u: abs(math.sin(math.pi * (u % 6) / 6))   # one paw hits every 6 frames, the other 3 later
            h1, h2 = hit(t), hit(t + 3)
            return {"arm1": -6 + 4 * h1, "arm-1": -6 + 4 * h2, "elbow1": -80 + 26 * h1, "elbow-1": -74 + 26 * h2,
                    "hand1": "fist", "hand-1": "fist", "sq": 0.98 + 0.008 * math.sin(ph(fr, 3)),
                    "x": 0.018 * math.sin(ph(fr, 6)), "head_y": -0.06, "head_rot": 2.5 * math.sin(ph(fr)),
                    "brow": -0.03, "ears": 5}
        layers.append(drum)
        blinks[:] = [round(N * 0.55)]

    elif kind == "waving":
        exprs[:] = [(0, "hype")]
        replay(motion.wave, -BIG - BIG % 12, BIG)   # starts on a multiple of 12 so the 12f wave cycle lines up
        layers.append(lambda fr: {"x": 0.04 * math.sin(ph(fr)), "rot": 1.2 * math.sin(ph(fr, N, 0.6))})
        blinks[:] = [round(N * 0.4)]
    else:
        raise SystemExit(f"unknown sticker {kind}")

    # periodic idle (replaces Anim's own): breathing, head bob, tail sway
    layers.insert(0, lambda fr: {"sq": 1 + 0.012 * math.sin(ph(fr)), "head_y": 0.03 * math.sin(ph(fr, N, -0.9)),
                                 "tail": 7 * math.sin(ph(fr, N, 0.4))})

    REST_SH, REST_EL = cast.REST[0], cast.REST[1]

    def loop_layer(fr):
        """All layers merged with Anim.bake's rules (ADD sums, MUL multiplies, arms/hands override), then the
        raised-arm drift that bake() adds on its own 43f/57f clocks is cancelled and redone on the loop clock."""
        out = {}
        for L in layers:
            d = L(fr) or {}
            for k, v in d.items():
                if k in ADD:
                    out[k] = out.get(k, 0.0) + v
                elif k in MUL:
                    out[k] = out.get(k, 1.0) * v
                else:
                    out[k] = v
        for side in (1, -1):
            want = out.get(f"arm{side}", REST_SH)
            w_of = lambda a: min(max((a - 20) / 30, 0.0), 1.0)
            if w_of(want) == 0 and f"arm{side}" not in out:
                continue
            want = want + w_of(want) * 1.5 * math.sin(ph(fr, N, 0.7 * side))     # our own slow drift, periodic
            want_el = out.get(f"elbow{side}", REST_EL) + w_of(want) * 1.8 * math.sin(ph(fr, N, 1.9 + side))
            p = TAU * (fr + seed * side)
            o = want
            for _ in range(6):   # solve o + w(o) * drift = want
                o = want - w_of(o) * 1.8 * math.sin(p / 43)
            out[f"arm{side}"] = o
            out[f"elbow{side}"] = want_el - w_of(o) * 2.2 * math.sin(p / 57 + 1.1)
        return out

    # expression timeline repeated on every loop; Riot starts in the loop's final face so nothing changes at -W
    exprs.sort()
    c.expr(exprs[-1][1])
    a = motion.Anim(c, idle=False)
    a.add(loop_layer)
    cycles = math.ceil(120 / N) + 1
    W = cycles * N
    for k in range(-cycles, 2):
        for off, name in exprs:
            a.expr(k * N + off, name)
    a.bake(-W, N)

    # blinks and eye squash: re-keyed on the loop clock (bake's own blinks are random)
    BLINK = {0: 0.55, 1: 1.0, 2: 0.55}
    def expr_at(t):
        return max((e for e in exprs if e[0] <= t), key=lambda e: e[0])[1]
    for fr in range(0, N + 1):
        t = fr % N
        name = expr_at(t)
        sq = cast.EXPRESSIONS[name][4]
        nxt = next(((off, nm) for off, nm in exprs + [(N + o, nm) for o, nm in exprs] if 0 < off - t <= 2), None)
        if nxt and nxt[1] != name:
            w = 1 - (nxt[0] - t) / 2
            sq = sq + (cast.EXPRESSIONS[nxt[1]][4] - sq) * w
        close = 0.0 if name in cast.ARC_EYES else max((BLINK.get((t - b) % N, 0.0) for b in blinks), default=0.0)
        for e in c.eyes:
            e.scale.y = sq + (0.1 - sq) * close
            e.keyframe_insert("scale", index=1, frame=fr)

    # numeric loop check: every object's world transform and visibility at frame 0 vs frame N
    def state(fr):
        sc.frame_set(fr)
        return {o.name: ([v for row in o.matrix_world for v in row], o.hide_render) for o in sc.objects}
    s0, sN = state(0), state(N)
    diffs = sorted(((max(abs(x - y) for x, y in zip(s0[k][0], sN[k][0])), k) for k in s0), reverse=True)
    dv = [k for k in s0 if s0[k][1] != sN[k][1]]
    print(f"LOOPCHECK transform_max_diff={diffs[0][0]:.5f} ({diffs[0][1]}) visibility_mismatches={len(dv)} {dv[:4]}")

    os.makedirs(rawdir, exist_ok=True)
    sc.frame_start, sc.frame_end = 0, N
    sc.render.filepath = os.path.join(rawdir, "f_")
    bpy.ops.render.render(animation=True)
    print("STICKER RENDERED", kind, N)


# =====================================================================================================
# python3 side: run Blender, crop, scale, encode GIF + WebM, check
# =====================================================================================================

def loop_frames(kind, seconds):
    s = STICKERS[kind]
    n = max(s["min"], round(seconds * FPS))
    q = s["quantum"]
    return max(q, round(n / q) * q)


def run_blender(kind, costume, n, rawdir):
    cmd = [BLENDER, "--background", "--python", os.path.abspath(__file__), "--", "--blender", kind, costume, str(n), rawdir]
    p = subprocess.run(cmd, capture_output=True, text=True)
    log = p.stdout + p.stderr
    if p.returncode or "Traceback (most recent call last)" in log or "STICKER RENDERED" not in log:
        sys.exit(f"FAILED: Blender render of {kind}\n{log[-3000:]}")
    for line in log.splitlines():
        if line.startswith(("LOOPCHECK", "WARNING")):
            print("  " + line)


def checker(w, h, cell=16):
    from PIL import Image
    import numpy as np
    yy, xx = np.mgrid[0:h, 0:w]
    v = np.where(((xx // cell) + (yy // cell)) % 2, 205, 245).astype("uint8")
    return Image.fromarray(np.dstack([v, v, v, np.full_like(v, 255)]), "RGBA")


def gif_durations(n, fps):
    """Per-frame delays in ms, multiples of 10 (GIF's unit) that add up to exactly n / fps seconds."""
    ends = [round(1000 * (i + 1) / fps / 10) * 10 for i in range(n)]
    return [b - a for a, b in zip([0] + ends[:-1], ends)]


def write_gif(frames, path, fps):
    """One global 255-colour palette from the opaque pixels of every frame, no dithering (flat colours stay flat,
    no speckle on the outline), index 255 = transparent (alpha < 128), each frame fully replaces the last."""
    from PIL import Image
    import numpy as np
    arrs = [np.asarray(f) for f in frames]
    px = np.concatenate([a[a[..., 3] >= 128][:, :3] for a in arrs])
    step = max(1, len(px) // 1_500_000)
    px = px[::step]
    sample = Image.fromarray(px.reshape(1, -1, 3), "RGB")
    pal = sample.quantize(colors=255, method=Image.Quantize.MEDIANCUT, dither=Image.Dither.NONE)
    palette = (pal.getpalette()[:255 * 3] + [0] * (255 * 3))[:255 * 3] + [18, 18, 18]
    pal.putpalette(palette)
    out = []
    for a in arrs:
        q = Image.fromarray(np.ascontiguousarray(a[..., :3]), "RGB").quantize(palette=pal, dither=Image.Dither.NONE)
        idx = np.asarray(q).copy()
        idx[a[..., 3] < 128] = 255
        im = Image.fromarray(idx, "P")
        im.putpalette(palette)
        im.info["transparency"] = 255
        out.append(im)
    out[0].save(path, save_all=True, append_images=out[1:], duration=gif_durations(len(out), fps), loop=0,
                transparency=255, disposal=2, optimize=False)


def check_gif(path, frames, step):
    """Decode the GIF back and compare every frame's transparency mask with the source."""
    from PIL import Image, ImageSequence
    import numpy as np
    g = Image.open(path)
    bad = 0
    for i, fr in enumerate(ImageSequence.Iterator(g)):
        m = np.asarray(fr.convert("RGBA"))[..., 3] >= 128
        src = np.asarray(frames[i * step])[..., 3] >= 128
        bad = max(bad, int((m != src).sum()))
    return g.n_frames, bad


def write_webm(framedir, path, fps, crf):
    subprocess.run(["ffmpeg", "-v", "error", "-y", "-framerate", str(fps), "-i", os.path.join(framedir, "%04d.png"),
                    "-c:v", "libvpx-vp9", "-pix_fmt", "yuva420p", "-b:v", "0", "-crf", str(crf), "-auto-alt-ref", "0",
                    "-row-mt", "1", "-an", path], check=True)


def webm_pixfmt(path):
    p = subprocess.run(["ffprobe", "-v", "error", "-c:v", "libvpx-vp9", "-select_streams", "v:0", "-show_entries",
                        "stream=pix_fmt,width,height", "-of", "json", path], capture_output=True, text=True)
    s = json.loads(p.stdout)["streams"][0]
    return s["pix_fmt"], s["width"], s["height"]


def make(kind, costume, seconds, size, name, gif_fps):
    from PIL import Image
    import numpy as np
    t0 = time.time()
    n = loop_frames(kind, seconds)
    name = name or ("riot_" + kind + ("" if costume == "hoodie" else "_" + costume))
    out = os.path.join(OUT_ROOT, name)
    rawdir = os.path.join(out, "_raw")
    shutil.rmtree(out, ignore_errors=True)
    os.makedirs(out)
    print(f"[{name}] {STICKERS[kind]['desc']} · costume {costume} · {n} frames ({n / FPS:.2f}s loop)")
    run_blender(kind, costume, n, rawdir)
    t_render = time.time() - t0

    raw = [Image.open(os.path.join(rawdir, f"f_{i:04d}.png")).convert("RGBA") for i in range(n + 1)]
    # loop check in pixels: the frame after the last one (N) must look like frame 0
    d = np.abs(np.asarray(raw[0]).astype(int) - np.asarray(raw[n]).astype(int))
    print(f"  loop seam: mean pixel diff {d.mean():.4f}, pixels changed by >32: {int((d.max(axis=2) > 32).sum())}")
    # tight crop over every frame of the loop
    box = None
    for im in raw[:n]:
        b = im.getchannel("A").getbbox()
        if b:
            box = b if box is None else (min(box[0], b[0]), min(box[1], b[1]), max(box[2], b[2]), max(box[3], b[3]))
    if box[0] == 0 or box[1] == 0 or box[2] == RAW or box[3] == RAW:
        sys.exit(f"FAILED: Riot touches the edge of the raw render {box}; widen STICKERS['{kind}']['cam']")
    bw, bh = box[2] - box[0], box[3] - box[1]
    pad = 8  # final pixels of empty border
    scale = (size - 2 * pad) / max(bw, bh)
    if scale > 1:
        print(f"  WARNING: upscaling the raw render {scale:.2f}x; raise RAW for sharper edges")
    ev = lambda v: int(math.ceil(v / 2) * 2)
    W, H = ev(bw * scale + 2 * pad), ev(bh * scale + 2 * pad)
    # the crop box in raw pixels that maps exactly onto W x H
    cx, cy = (box[0] + box[2]) / 2, (box[1] + box[3]) / 2
    crop = (cx - W / scale / 2, cy - H / scale / 2, cx + W / scale / 2, cy + H / scale / 2)
    framedir = os.path.join(out, "frames")
    os.makedirs(framedir)
    frames = []
    for i, im in enumerate(raw[:n]):
        f = im.resize((W, H), Image.LANCZOS, box=crop)   # Pillow resamples RGBA premultiplied: no dark/light fringe
        f.save(os.path.join(framedir, f"{i:04d}.png"), optimize=False)
        frames.append(f)
    shutil.rmtree(rawdir)

    # GIF (fall back to fewer frames, then smaller, if it's over GIPHY's limit)
    gif = os.path.join(out, name + ".gif")
    fps_try = [gif_fps] + ([15] if gif_fps > 15 and FPS % 15 == 0 else [])
    for gf in fps_try:
        step = FPS // gf
        write_gif(frames[::step], gif, gf)
        if os.path.getsize(gif) <= MAX_BYTES:
            break
    shrink = 1.0
    while os.path.getsize(gif) > MAX_BYTES:
        shrink *= 0.85
        small = [f.resize((ev(W * shrink), ev(H * shrink)), Image.LANCZOS) for f in frames]
        write_gif(small[::step], gif, gf)
    nf, bad = check_gif(gif, frames, step) if shrink == 1.0 else (len(frames[::step]), 0)
    # WebM (VP9 + alpha)
    webm = os.path.join(out, name + ".webm")
    for crf in (30, 36, 42, 48):
        write_webm(framedir, webm, FPS, crf)
        if os.path.getsize(webm) <= MAX_BYTES:
            break
    pf, ww, wh = webm_pixfmt(webm)

    # preview: first, middle, last, and the first frame again (what follows the last one) on a checkerboard
    picks = [0, n // 2, n - 1]
    sheet = Image.new("RGBA", ((W + 12) * 4 + 12, H + 24), (18, 18, 18, 255))
    for j, im in enumerate([frames[p] for p in picks] + [frames[0]]):
        tile = checker(W, H)
        tile.alpha_composite(im)
        sheet.paste(tile, (12 + j * (W + 12), 12))
    sheet.convert("RGB").save(os.path.join(out, "preview.png"))

    took = time.time() - t0
    kb = lambda p: os.path.getsize(p) / 1024
    print(f"  GIF  {gif}  {W}x{H}  {nf} frames @ {gf}fps  {kb(gif):.0f} KB  mask mismatch vs source: {bad}px"
          + (f"  (shrunk {shrink:.2f}x)" if shrink < 1 else ""))
    print(f"  WebM {webm}  {ww}x{wh}  {pf}  {kb(webm):.0f} KB")
    print(f"  frames {framedir}/0000-{n - 1:04d}.png   preview {os.path.join(out, 'preview.png')}")
    print(f"  took {took:.0f}s (Blender {t_render:.0f}s)")
    return dict(name=name, gif=gif, webm=webm, size=(W, H), gif_kb=kb(gif), webm_kb=kb(webm), seconds=took)


def main():
    ap = argparse.ArgumentParser(description="Transparent looping GIPHY stickers of Riot.")
    ap.add_argument("expression", choices=list(STICKERS) + ["all"])
    ap.add_argument("--costume", default="hoodie", choices=COSTUMES)
    ap.add_argument("--seconds", type=float, default=2.0, help="loop length, 1-3 s (rounded to fit the move)")
    ap.add_argument("--size", type=int, default=480, help="long side in pixels (GIPHY: at least 480)")
    ap.add_argument("--name", help="output folder/file name (default riot_<expression>[_<costume>])")
    ap.add_argument("--gif-fps", type=int, default=30, choices=(15, 30), help="GIF frame rate (WebM is always 30)")
    args = ap.parse_args()
    if not 1 <= args.seconds <= 3:
        ap.error("--seconds must be between 1 and 3")
    kinds = list(STICKERS) if args.expression == "all" else [args.expression]
    if args.name and len(kinds) > 1:
        ap.error("--name only works with a single expression")
    for k in kinds:
        make(k, args.costume, args.seconds, args.size, args.name, args.gif_fps)


if __name__ == "__main__":
    if "--blender" in sys.argv:
        blender_main(sys.argv[sys.argv.index("--blender") + 1:])
    else:
        main()
