# Blender scene for "Who Said That?" in the Party Room (whosaid_script.py).
#   Blender --background --python whosaid_scene.py -- <video dir>
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import joke
from joke import *
import whosaid_script as S

J = joke.Joke(S, locations.party_room, {"bash": None, "pip": None, "riot": None, "rocco": None})
C, A = J.C, J.A
r, b, p, k_ = A["riot"], A["bash"], A["pip"], A["rocco"]
loc = J.loc
for who in A:
    A[who].expr(0, "happy")
r.expr(0, "hype")

# everyone has their own phone the whole time (that's the point of room games); they type their answers
phones = {who: J.hold_phone(who, 0, C["laugh"] - 2, side=1 if who == "rocco" else -1) for who in A}  # Rocco: chips in the left paw
for who, ph in phones.items():
    for k in range(4):
        fr = C["type"] + k * 9 + J.seat[who] * 2
        for f_, v in ((fr, 1.0), (fr + 2, 1.08), (fr + 5, 1.0)):
            ph.scale = (v, v, 1)
            ph.keyframe_insert("scale", frame=f_)
    A[who].look(C["type"], 0.0, 4)
    A[who].expr(C["type"], "cocky" if who == "pip" else "happy")

# the TV: room code -> the question -> "?" -> PIP
tv = loc.extras["tv"]
code_objs = [bpy.data.objects["pr_tv_t"], loc.extras["code"]]
q = text("tv_q", "WHO SAID THAT?", 0.95, CHALK, tv, (0, 0.9), 0.02)
qq = text("tv_qq", "?", 2.4, YELLOW, tv, (0, -0.7), 0.02)
it = text("tv_it", "IT WAS", 0.8, CHALK, tv, (0, 1.1), 0.02)
pipname = text("tv_pip", "PIP!", 2.2, YELLOW, tv, (0, -0.6), 0.02)
for o, on in ((code_objs[0], 0), (code_objs[1], 0), (q, C["riot_q"]), (qq, C["riot_q"]), (it, C["reveal"]), (pipname, C["reveal"])):
    set_visible(o, on == 0, 0)
for o in code_objs:
    set_visible(o, False, C["riot_q"])
for o in (q, qq):
    set_visible(o, True, C["riot_q"])
    set_visible(o, False, C["reveal"])
for o in (it, pipname):
    set_visible(o, True, C["reveal"])

# Riot asks and reads; Bash and everyone point at Rocco; Rocco shrugs, munching
J.talk("riot", "riot_q")
J.talk("riot", "riot_read")
for who in ("bash", "pip", "rocco"):
    A[who].look(C["riot_read"] - 4, J.side(who, "riot"), 5)
b.expr(C["bash_guess"] - 2, "yelling")
J.talk("bash", "bash_guess", energy=1.2)
for who in ("bash", "pip", "riot"):
    motion.point_at(A[who], C["point"] + (2 if who == "pip" else 0), int(J.side(who, "rocco")),
                    hold=C["rocco_no_end"] - C["point"], expr="cocky" if who != "bash" else "yelling")
k_.expr(C["rocco_no"] - 2, "side_eye_l")
J.talk("rocco", "rocco_no")
k_.look(C["rocco_no"] - 6, -0.5, 6)
# the reveal: everyone turns to Pip, who waves
for who in ("bash", "riot", "rocco"):
    A[who].look(C["reveal"] + 2, J.side(who, "pip"), 4)
    motion.take(A[who], C["reveal"] + 4, "shocked", 0.8)
p.expr(C["pip_hi"] - 4, "nervous")
motion.wave(p, C["pip_hi"] - 2, C["pip_hi_end"] + 14, side=1)
J.talk("pip", "pip_hi", energy=0.7)
J.laugh_all(C["laugh"], C["end"] - 2, order=("riot", "pip", "bash", "rocco"))

# ---- camera + graphics ----
CA = J.camera("wide")
CA.push(C["riot_q"], C["sent"] - 2, (lambda x, y, o: (x, y + 0.3, o * 0.94))(*J.frame("wide")), "smooth")
CA.cut(C["sent"], J.frame("wide", band=True))
CA.push(C["rocco_no"] - 8, C["rocco_no"] - 1, J.frame("close:rocco"), "out")
CA.cut(C["reveal"], J.frame("wide"))
CA.shake(C["reveal"] + 2, 10, 0.3)
CA.push(C["reveal"] + 8, C["pip_hi"] - 1, J.frame("close:pip"), "out")
CA.cut(C["laugh"], J.frame("wide"))
J.hook(C["riot_q"] + 20)
J.card(props.quote_card("ans", "EVERYONE SEES", S.ANSWER, (0, 0), 0.6), C["sent"] + 4, C["rocco_no"] - 10, s=0.95)
J.captions(["riot_q", "bash_guess", "rocco_no", "pip_hi"], y_px=1400)
J.confetti(C["laugh"] + 2)
J.finish("Who Said That?")
