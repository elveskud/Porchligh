# Render later (deferred on 28 Oct 2026: stills-only round)

Everything below has code + stills/reference proofs; the mp4s were not rendered on purpose. When you approve real posts:

```bash
cd Blender/templates
python3 render_week.py ../../marketing/weekly/_render_later_new.json --dry-run      # ~6 new videos, then run without --dry-run
python3 render_week.py ../../marketing/weekly/_render_later_refresh.json --dry-run  # then run with --force (these passed QA before)
```

**New (no mp4 yet):** `tod_evil_laugh_01_h`, `mlt_car_01_h`, `alias_howto_01_h`, `comeback_01_h`, `hottakes_pineapple_01_h`, `feature_rooms_01` (+ cover), `feature_rooms_01_h` (+ thumbnail).

**Refresh (`--force`):** their mp4s predate a code change.
- Phone hold (now at belly height, a little to the side, upright, logo the right way round; faces and mouths clear): `whosaid_pizza_01`, `spy_sunscreen_01`, `closecall_bones_01`, `wordassoc_pizza_01`, `comeback_01`.
- 16:9 cards auto-fitted to NHIE-card size with a margin, hook sized to its text top-left: `mafia_quiet_01_h` (every other joke template's 16:9 has no mp4 yet).
- 16:9 edge props moved out of frame / living-room & party-room 16:9 framing centred: `nhie_bash_halloween_a_h`. (`campfire_confessions_ep01_h` was dropped from this list on 28 Oct: the series moved out of the advertiser.)

**Animation pass (28 Oct):** every mp4 in `videos/` predates the acting upgrade (bigger performances, torso lean, talk gestures, listeners reacting, smears, living set light, camera drift; see CHARACTERS.md "Acting controls"). Re-render anything you post with `--force --reuse-voices`.

**Single images (no video needed):** `python3 thumbnail.py ../videos/<name> [--cover]` for any finished video.
