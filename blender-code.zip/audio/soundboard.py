# Renders every sound in sfxkit to refs/sounds/<name>.wav plus one listen-through reel.
#   ../voices/.venv/bin/python soundboard.py
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import numpy as np
import sfxkit as K

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "../characters/refs/sounds")
os.makedirs(OUT, exist_ok=True)

SOUNDS = [
    ("pop", K.pop), ("whoosh", K.whoosh), ("swish", K.swish), ("slam", K.slam), ("stamp", K.stamp),
    ("card_flip", K.card_flip), ("ting", K.ting), ("sparkle", K.sparkle), ("boing", K.boing),
    ("slide_up", lambda: K.slide_whistle(True)), ("slide_down", lambda: K.slide_whistle(False)),
    ("drumroll", K.drumroll), ("crash", K.crash), ("boom", K.boom), ("scratch", K.scratch), ("tick", K.tick),
    ("clock", K.clock), ("fire", K.fire), ("slurp", K.slurp), ("crunch", K.crunch), ("popper", K.popper), ("tap", K.tap),
    ("sting_dun_dun_dunnn", K.dun_dun_dunnn), ("sting_fanfare", K.fanfare), ("sting_sad_trombone", K.sad_trombone),
    ("sting_suspense", K.suspense),
    ("bed_hype", lambda: K.bed("hype", 4)), ("bed_suspense", lambda: K.bed("suspense", 4)), ("bed_chill", lambda: K.bed("chill", 4)),
]

reel = []
for name, fn in SOUNDS:
    x = fn()
    K.save(os.path.join(OUT, f"{name}.wav"), x * 0.9)
    reel += [x * 0.8, np.zeros(int(K.SR * 0.5))]
    print(f"{name:22s} {len(x) / K.SR:5.2f}s")
K.save(os.path.join(OUT, "_sound_reel.wav"), np.concatenate(reel))
print("REEL", round(sum(len(r) for r in reel) / K.SR, 1), "s")
