# Riot walks up to the camera and says "Are you ready to play?"
# Flat 2D cutout style, rendered with Workbench.
#
# Full render:   Blender --background --python riot_intro.py
# Test frames:   FRAMES=0,40,95 Blender --background --python riot_intro.py
import bpy, bmesh, math, os
from mathutils import Vector

HERE = os.path.dirname(os.path.abspath(__file__))
FONT = os.path.join(HERE, "../../Friendzy/Resources/Fonts/Boogaloo-Regular.ttf")
END = 179
SHOW_BUBBLE = True

bpy.ops.wm.read_factory_settings(use_empty=True)
sc = bpy.context.scene
col = sc.collection


# ---------- helpers ----------

def lin(c):
    return c / 12.92 if c <= 0.04045 else ((c + 0.055) / 1.055) ** 2.4

MATS = {}
def mat(h):
    if h not in MATS:
        m = bpy.data.materials.new(h)
        r, g, b = (int(h[i:i + 2], 16) / 255 for i in (1, 3, 5))
        m.diffuse_color = (lin(r), lin(g), lin(b), 1)
        MATS[h] = m
    return MATS[h]

def empty(name, parent=None, loc=(0, 0), z=0.0):
    o = bpy.data.objects.new(name, None)
    col.objects.link(o)
    o.parent = parent
    o.location = (loc[0], loc[1], z)
    return o

def ccw(pts):
    n = len(pts)
    a = sum(pts[i][0] * pts[(i + 1) % n][1] - pts[(i + 1) % n][0] * pts[i][1] for i in range(n))
    return pts if a > 0 else pts[::-1]

def offset(pts, w):
    n, out = len(pts), []
    for i in range(n):
        p0, p1, p2 = Vector(pts[i - 1]), Vector(pts[i]), Vector(pts[(i + 1) % n])
        e1, e2 = (p1 - p0).normalized(), (p2 - p1).normalized()
        n1, n2 = Vector((e1.y, -e1.x)), Vector((e2.y, -e2.x))
        m = n1 + n2
        m = n1 if m.length < 1e-6 else m.normalized()
        out.append(tuple(p1 + m * (w / max(m.dot(n1), 0.35))))
    return out

def mesh_obj(name, pts, color, parent, z):
    me = bpy.data.meshes.new(name)
    bm = bmesh.new()
    bm.faces.new([bm.verts.new((x, y, 0)) for x, y in pts])
    bm.to_mesh(me)
    bm.free()
    me.materials.append(mat(color))
    o = bpy.data.objects.new(name, me)
    col.objects.link(o)
    o.parent = parent
    o.location.z = z
    return o

def shape(name, pts, color, parent, z, ol=0.12):
    pts = ccw(pts)
    o = mesh_obj(name, pts, color, parent, z)
    if ol > 0:
        mesh_obj(name + "_ol", offset(pts, ol), "#111111", parent, z - 0.005)
    return o

def ell(cx, cy, rx, ry, n=40, rot=0.0):
    c, s = math.cos(rot), math.sin(rot)
    pts = []
    for i in range(n):
        a = 2 * math.pi * i / n
        x, y = rx * math.cos(a), ry * math.sin(a)
        pts.append((cx + x * c - y * s, cy + x * s + y * c))
    return pts

def vcap(cx, ytop, ybot, hw, n=10):
    pts = [(cx + hw * math.cos(math.pi * i / n), ytop + hw * math.sin(math.pi * i / n)) for i in range(n + 1)]
    pts += [(cx + hw * math.cos(math.pi + math.pi * i / n), ybot + hw * math.sin(math.pi + math.pi * i / n)) for i in range(n + 1)]
    return pts

def rect(x0, y0, x1, y1):
    return [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]

def mx(pts, s):
    return [(x * s, y) for x, y in pts]

def mirror_half(half):
    # half: right side from bottom-center to top-center
    return half + [(-x, y) for x, y in reversed(half[1:-1])]

def lerp_keys(keys, f):
    for (f0, v0), (f1, v1) in zip(keys, keys[1:]):
        if f0 <= f <= f1:
            t = (f - f0) / (f1 - f0)
            t = t * t * (3 - 2 * t)
            return v0 + (v1 - v0) * t
    return keys[-1][1]

def smooth(a, b, f):
    t = min(max((f - a) / (b - a), 0), 1)
    return t * t * (3 - 2 * t)

def pop(f, a):
    if f < a:
        return 0.0
    t = (f - a) / 6
    if t >= 1:
        return 1.0
    return 1.12 * (t / 0.6) if t < 0.6 else 1.12 - 0.12 * (t - 0.6) / 0.4

rad = math.radians

ORANGE, ORANGE_D, CREAM, BLACK = "#FF6B00", "#E85A00", "#F5F0E8", "#1A1A1A"

# ---------- background ----------

shape("sky", rect(-8, -12, 8, 12), "#FFD600", None, -2.0, ol=0)
shape("floor", rect(-8, -12, 8, 4), "#F5BE00", None, -1.9, ol=0)

# ---------- Riot ----------

root = empty("root")
shape("shadow", ell(0, 0.05, 2.1, 0.42), "#D9A300", root, -1.0, ol=0)

legs = {}
for s, name in ((-1, "legL"), (1, "legR")):
    p = empty(name, root, (0.75 * s, 3.6), 0.1)
    shape(name + "_fur", vcap(0, -0.2, -3.0, 0.47), ORANGE, p, 0.0)
    shape(name + "_sock", vcap(0, -2.1, -3.0, 0.47), BLACK, p, 0.004, ol=0)
    shape(name + "_foot", ell(0.2 * s, -3.35, 0.72, 0.38), BLACK, p, 0.008)
    legs[s] = p

upper = empty("upper", root, (0, 3.6))

tail = empty("tail", upper, (0.8, 0.3), 0.02)
shape("tail_fur", [(0, -0.25), (0.9, -0.3), (1.9, 0.2), (2.7, 1.0), (3.1, 2.0), (2.9, 3.0),
                   (2.4, 3.4), (2.2, 2.6), (1.9, 1.6), (1.3, 0.9), (0.6, 0.5), (0, 0.3)], ORANGE, tail, 0.0)
shape("tail_tip", [(2.98, 2.25), (2.9, 3.0), (2.4, 3.4), (2.2, 2.6), (2.15, 2.3), (2.35, 2.05),
                   (2.55, 2.3), (2.75, 2.05)], CREAM, tail, 0.004, ol=0)

torso = [(-1.45, -0.3), (1.45, -0.3), (1.6, 0.2), (1.75, 2.6), (1.5, 3.05), (0.6, 3.2),
         (-0.6, 3.2), (-1.5, 3.05), (-1.75, 2.6), (-1.6, 0.2)]
shape("hoodie", torso, BLACK, upper, 0.2)
shape("hem", rect(-1.47, -0.28, 1.47, 0.15), "#333333", upper, 0.204, ol=0)
shape("zip", rect(-0.05, 0.15, 0.05, 3.0), "#8A8A8A", upper, 0.206, ol=0)
for s in (-1, 1):
    shape(f"piping{s}", rect(0.45 * s - 0.05, 0.3, 0.45 * s + 0.05, 2.9), ORANGE, upper, 0.206, ol=0)
shape("hood", ell(0, 3.1, 1.55, 0.55), BLACK, upper, 0.25)

arms = {}
for s, name in ((-1, "armL"), (1, "armR")):
    p = empty(name, upper, (1.5 * s, 2.7), 0.3)
    shape(name + "_sleeve", vcap(0, 0.1, -2.2, 0.42), BLACK, p, 0.0)
    shape(name + "_stripe", rect(0.22 * s - 0.05, -2.0, 0.22 * s + 0.05, 0.25), ORANGE, p, 0.004, ol=0)
    shape(name + "_cuff", rect(-0.42, -2.25, 0.42, -1.95), "#333333", p, 0.006, ol=0)
    shape(name + "_paw", ell(0, -2.6, 0.5, 0.45), ORANGE, p, 0.01)
    arms[s] = p

head = empty("head", upper, (0, 3.1), 0.4)
for s in (-1, 1):
    ear = empty(f"ear{s}", head, (1.1 * s, 2.4), -0.05)
    shape(f"ear{s}_fur", mx([(-0.65, 0), (0.7, -0.25), (0.75, 1.9)], s), ORANGE, ear, 0.0)
    shape(f"ear{s}_in", mx([(-0.35, 0.15), (0.45, 0.0), (0.6, 1.4)], s), "#8B1A2B", ear, 0.004, ol=0)

shape("face", mirror_half([(0, -0.35), (0.9, -0.1), (1.6, 0.25), (2.5, 0.35), (1.95, 0.75), (2.3, 1.0),
                           (1.85, 1.35), (1.9, 2.0), (1.4, 2.6), (0.6, 2.95), (0, 3.0)]), ORANGE, head, 0.0, ol=0.13)
shape("muzzle", mirror_half([(0, -0.22), (0.85, 0.0), (1.45, 0.35), (2.15, 0.42), (1.6, 0.7),
                             (1.0, 0.75), (0.45, 1.05), (0, 1.1)]), CREAM, head, 0.02, ol=0)

eyes = []
for s in (-1, 1):
    e = empty(f"eye{s}", head, (0.78 * s, 1.6), 0.04)
    shape(f"eye{s}_white", ell(0, 0, 0.52, 0.32, rot=rad(12 * s)), "#FFD600", e, 0.0, ol=0.07)
    shape(f"eye{s}_pupil", ell(-0.08 * s, -0.02, 0.17, 0.17), "#111111", e, 0.004, ol=0)
    shape(f"eye{s}_shine", ell(-0.03 * s, 0.05, 0.05, 0.05, n=12), "#FFFFFF", e, 0.008, ol=0)
    brow = [(0.78 * s + x * s, 1.6 + y) for x, y in [(-0.6, 0.22), (0.6, 0.58), (0.62, 0.42), (-0.55, 0.08)]]
    shape(f"brow{s}", brow, "#111111", head, 0.06, ol=0)
    eyes.append(e)

shape("nose", [(-0.3, 1.1), (0.3, 1.1), (0.12, 0.85), (0, 0.78), (-0.12, 0.85)], "#111111", head, 0.07, ol=0)

mouth = empty("mouth", head, (0, 0.55), 0.05)
W = 0.75
top = [(x, 0.18 * (x / W) ** 2) for x in [W * (i / 6 - 1) for i in range(13)]]
bottom = [(x, 0.18 * (x / W) ** 2 - 0.65 * (1 - (x / W) ** 2)) for x in [W * (1 - i / 6) for i in range(1, 12)]]
shape("mouth_in", top + bottom, "#6B0F1A", mouth, 0.0, ol=0.06)
shape("tongue", ell(0, -0.45, 0.28, 0.14), "#E8506A", mouth, 0.004, ol=0)
teeth_top = [(x, 0.18 * (x / W) ** 2) for x in [0.6 * (i / 5 - 1) for i in range(11)]]
shape("teeth", teeth_top + [(x, y - 0.14) for x, y in reversed(teeth_top)], "#FFFFFF", mouth, 0.008, ol=0)

# ---------- speech bubble ----------

bubble = empty("bubble", None, (0.9, 4.5), 1.0)
lines = []
if SHOW_BUBBLE:
    cx, cy, hw, hh, r = -0.9, 3.1, 4.5, 1.75, 0.7
    pts = []
    for (ax, ay, a0) in ((cx + hw - r, cy - hh + r, -90), (cx + hw - r, cy + hh - r, 0),
                         (cx - hw + r, cy + hh - r, 90), (cx - hw + r, cy - hh + r, 180)):
        pts += [(ax + r * math.cos(rad(a0 + 90 * i / 6)), ay + r * math.sin(rad(a0 + 90 * i / 6))) for i in range(7)]
    pts += [(-0.5, cy - hh), (0, 0), (0.4, cy - hh)]
    shape("bubble_bg", pts, "#FFFFFF", bubble, 0.0, ol=0.14)

    font = bpy.data.fonts.load(FONT)
    for i, (body, y) in enumerate((("ARE YOU", 3.75), ("READY TO PLAY?", 2.4))):
        cu = bpy.data.curves.new(f"line{i}", "FONT")
        cu.body, cu.font, cu.size = body, font, 1.25
        cu.align_x, cu.align_y = "CENTER", "CENTER"
        cu.materials.append(mat("#121212"))
        o = bpy.data.objects.new(f"line{i}", cu)
        col.objects.link(o)
        o.parent = bubble
        o.location = (cx, y, 0.02)
        lines.append(o)

# ---------- animation ----------

MOUTH_OPEN = [(0, .22), (91, .22), (95, .95), (99, .3), (103, .6), (106, .3), (111, .8), (114, .35),
              (117, .55), (120, .3), (124, .5), (127, .3), (133, 1.0), (140, .9), (146, .22), (180, .22)]
MOUTH_WIDE = [(0, 1), (100, 1), (103, .7), (106, 1), (121, 1), (124, .72), (127, 1), (180, 1)]

def key(o, *paths, f):
    for p in paths:
        o.keyframe_insert(data_path=p, frame=f)

for f in range(0, END + 1):
    # approach: feet slide down from the horizon as Riot grows
    t = min(f / 75, 1)
    s = 1 / (2.6 - 1.6 * t)
    root.location = (0, 4 + (-7.5 - 4) * s, 0)
    root.scale = (s, s, 1)
    key(root, "location", "scale", f=f)

    w = 1 - smooth(68, 82, f)
    ph = 2 * math.pi * f / 36
    sn = math.sin(ph)
    legs[-1].scale.y = 1 - 0.22 * max(0, sn) * w
    legs[1].scale.y = 1 - 0.22 * max(0, -sn) * w
    key(legs[-1], "scale", f=f)
    key(legs[1], "scale", f=f)

    upper.location.y = 3.6 + 0.12 * abs(math.cos(ph)) * w
    upper.rotation_euler.z = -rad(3) * sn * w
    key(upper, "location", "rotation_euler", f=f)

    tilt = rad(8) * (smooth(138, 146, f) - smooth(160, 172, f))
    head.rotation_euler.z = rad(2.5) * sn * w + tilt
    key(head, "rotation_euler", f=f)

    tail.rotation_euler.z = rad(9) * math.sin(2 * math.pi * f / 40)
    key(tail, "rotation_euler", f=f)

    arms[-1].rotation_euler.z = -rad(8) + rad(12) * sn * w
    u = smooth(88, 98, f) - smooth(150, 162, f)
    walk_r = rad(8) + rad(12) * sn * w
    arms[1].rotation_euler.z = (1 - u) * walk_r + u * (rad(150) + rad(18) * math.sin(2 * math.pi * (f - 90) / 12))
    key(arms[-1], "rotation_euler", f=f)
    key(arms[1], "rotation_euler", f=f)

    blink = 1.0
    for b in (45, 165):
        if b <= f <= b + 4:
            blink = 1 - 0.9 * (1 - abs(f - b - 2) / 2)
    for e in eyes:
        e.scale.y = blink
        key(e, "scale", f=f)

    mouth.scale = (lerp_keys(MOUTH_WIDE, f), lerp_keys(MOUTH_OPEN, f), 1)
    key(mouth, "scale", f=f)

    if SHOW_BUBBLE:
        b = pop(f, 88)
        bubble.scale = (b, b, 1)
        key(bubble, "scale", f=f)
        l2 = pop(f, 106)
        lines[1].scale = (l2, l2, 1)
        key(lines[1], "scale", f=f)

# ---------- camera + render ----------

cam_data = bpy.data.cameras.new("cam")
cam_data.type = "ORTHO"
cam_data.ortho_scale = 20
cam = bpy.data.objects.new("cam", cam_data)
col.objects.link(cam)
cam.location = (0, 0, 50)
sc.camera = cam

sc.render.engine = "BLENDER_WORKBENCH"
sc.display.shading.light = "FLAT"
sc.display.shading.color_type = "MATERIAL"
sc.display.render_aa = "16"
sc.view_settings.view_transform = "Standard"
sc.render.resolution_x, sc.render.resolution_y = 1080, 1920
sc.render.fps = 30
sc.frame_start, sc.frame_end = 0, END
sc.render.image_settings.file_format = "PNG"

bpy.ops.wm.save_as_mainfile(filepath=os.path.join(HERE, "riot_intro.blend"))

frames = os.environ.get("FRAMES")
if frames:
    for f in map(int, frames.split(",")):
        sc.frame_set(f)
        sc.render.filepath = os.path.join(HERE, "test", f"t_{f:04d}.png")
        bpy.ops.render.render(write_still=True)
else:
    sc.render.filepath = os.path.join(HERE, "frames", "f_")
    bpy.ops.render.render(animation=True)
