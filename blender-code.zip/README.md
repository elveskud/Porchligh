# Friendzy Videos — Start Here

Short, vertical, voiced cartoon videos for TikTok, Reels and Shorts, starring Riot and his friends.
Everything is generated locally and for free.

## 1. Check the setup (always first)
```bash
python3 Blender/doctor.py
```
It must end with `ALL GOOD`. Any `BAD` line prints its own fix.

## 2. Make a video
```bash
cd Blender/templates
python3 prompts.py nhie 10                       # browse the best unused real prompts from the app
python3 make.py nhie --prompt "Never have I ever ..." --target bash --hook "line one\nline two"
python3 make.py mlt --name mlt_car_02            # Most Likely To in the car (fixed script)
python3 make.py convo --name convo_02            # casual conversation test
python3 make.py episode --script examples/campfire-confessions/ep01.json [--format horizontal]   # episode from JSON (section 5)
python3 make.py tod --prompt "Do 10 seconds of the most dramatic evil laughter you have." --target rocco   # Truth or Dare: Riot picks DARE and overdoes it
python3 make.py mafia --name mafia_quiet_01      # one template per game: see the table below
```

**One joke template per game** (10–15 s, real app prompts, both formats via `--format`, shared scaffolding in `templates/joke.py`; each fixed script is in `<template>_script.py` and is easy to copy for a new prompt):
| Template | Game | Set | The joke |
|---|---|---|---|
| `nhie` | Never Have I Ever | campfire | `--prompt` + `--target`: Riot reads, the target confesses |
| `mlt` | Most Likely To | car | everyone points at sleeping Rocco |
| `tod` | Truth or Dare | living room | Riot (devil horns) picks DARE and overdoes it (`--prompt` from `tod_script.DARES`) |
| `alias` | Alias (30 s how-to) | living room | coach Riot explains, Bash can't follow the rule |
| `mafia` | Mafia | night village | "YOU ARE / Mafia" → night falls → Bash accuses Pip → "Pip was… a Civilian" → Riot: "Shhh… heh." |
| `trivia` | Trivia | game-show stage | real question; Bash buzzes wrong, Pip quietly right, "…I'm moving to Scotland." |
| `whosaid` | Who Said That? (room) | party room, phones | everyone guesses Rocco wrote it; it was Pip |
| `hottakes` | Hot Takes | campfire | "Pineapple on pizza is…" Bash: "A CRIME!" … one bite later: "…It's amazing." |
| `challenges` | Challenges | living room | the book lasts zero of its 30 seconds |
| `spy` | Spy (room) | party room, phones | Riot is the spy, bluffs perfectly; Bash accuses Pip |
| `closecall` | Close Call (room) | party room, phones | Bash 1000, Rocco 7, Pip exactly 206 |
| `wordassoc` | Word Association (room) | party room, phones | three CHEESE, one Breakfast |
| `comeback` | Comeback (room) | party room, phones | the prompt is about Riot; the winning answer is his evil laugh |
| `feature` | app feature spot | party room | `--prompt rooms\|tonight\|roadtrip\|classics\|spanish`: Riot holds up the phone, the REAL app screenshot fills the frame (section 7b) |
| `convo`, `teaser` | — | living room | casual test / room-games mystery teaser (vertical only) |
- Add `--stills 30,150,300` to preview a few frames first; it takes about 1 minute.
- `--format horizontal` renders 1920×1080 for YouTube (default `vertical`, 1080×1920). Only templates that list it in their script's `FORMATS` support it: every template in the table except `convo` and `teaser`. Horizontal names get an `_h` suffix by default.
- After changing only visuals, add `--reuse-voices`.
- `tod` only takes the dares listed in `tod_script.DARES` (each needs Riot's performance line written); `--target` picks who says the deadpan line.
- Output lands in `Blender/videos/<name>/`:
  - `<name>.mp4`, plus `<name>_silent.mp4`
  - `qa.txt` and `qa_sheet.png`: one frame per second with TikTok's UI zones shaded
  - `scene.blend`
- Every finished video adds a row to `videos/tracker.csv`. Re-rendering the same `--name` updates that row and keeps your stats and hashtags. After posting, fill in its views and watch time.
- QA's "hook in first second" is a real check: the scene's `hook` caption must be on screen, at least half size, by frame 30. Name a new template's hook caption `hook`.
- Git: renders (`videos/`, except `tracker.csv`), voice/Rhubarb downloads, `.blend`/`.mp4`/`.wav` reference renders and `__pycache__` are in `.gitignore`. Run `doctor.py` on a fresh clone; it prints how to re-download anything missing.

A full video takes about 3–4 minutes: voices around 80s, then render and encode.

## 3. Rules the user set (don't break these)
- **Style:** the code-drawn cast in `characters/cast.py`. The Gemini image cut-out Riot (`characters/artrig.py`) was **rejected**: don't use it.
- **Riot** is always the main character. Videos run about 12–16 seconds, with a hook in the first second.
- **Sound is generated only** (`audio/sfxkit.py`). No recorded sound libraries and no recorded human voices.
- **Voices:** Kokoro base voice plus Chatterbox acting (`voices/speak.py`). Don't change the per-character settings.
- **Show a script first** and get approval before generating new videos.
- **Family-friendly.** Use `prompts.py`'s AVOID filter for public marketing.

## 4. Where things are
| Folder | What |
|---|---|
| `characters/` | `toon.py` drawing toolkit, `cast.py` characters, `motion.py` moves, `props.py` graphics, `locations.py` sets |
| `characters/CHARACTERS.md` | Character bible plus the full animation reference |
| `characters/refs/` | Model sheets, motion clips, sounds, voice samples, location plates |
| `templates/` | `make.py` engine, one `<name>_script.py` + `<name>_scene.py` per format, `WRITING.md` (hooks and rules) |
| `audio/` | Generated sound kit and soundboard |
| `voices/` | Voice generation (`.venv`, Kokoro model, base voices) |
| `tools/` | Rhubarb lip sync (Intel build; runs via Rosetta) |
| `videos/` | Finished videos and `tracker.csv` |

## 5. Episodes from JSON (`episode` template)
Multi-beat videos from a JSON script. The example lives in `templates/examples/campfire-confessions/ep01.json` (a test episode from an earlier series idea, kept as the format reference). The story series *Porchlight* is a separate project in `~/Desktop/Porchlight`; the advertiser doesn't make series episodes.

Sets: `campfire`, `living_room_day`/`night`, `game_show` (Trivia), `village_night` (Mafia), `party_room` (room games), `car` (vertical only). Plates: `characters/refs/loc_<set>_{empty,cast,guide,wide}.png`.

```bash
python3 make.py episode --script examples/campfire-confessions/ep01.json                       # 30-60 s vertical
python3 make.py episode --script examples/campfire-confessions/ep01.json --format horizontal   # 2-4 min horizontal
```
- The video is named `<series folder>_<ep>` (`_h` for horizontal). Output: the mp4, `chapters.txt` (YouTube chapters, first at 0:00, each at least 10 s), QA, and a tracker row (template `episode`, `series=... ep=...` in notes).
- QA length band: 30–60 s vertical, 120–240 s horizontal. The hook is the first beat's `text`. Beats with `"formats": ["horizontal"]` appear only in the long cut, which also paces a little slower.
- Voices are made once per line and reused until that line's speaker or text changes (line ids come from the beat `id`, so both cuts share voices if you copy `vo/` across).
- Long renders split over `--jobs N` Blender processes (default 3; use 4). Horizontal episodes animate **on twos** (each drawing held 2 frames, a classic 2D look) at half the anti-aliasing samples: ~165 s of render per minute of video, so a 3-min episode takes ~8 min. `--ones` renders every frame (~2x slower).

**JSON shape**
| Field | |
|---|---|
| `series`, `episode`, `title` | names; `next` = next episode title for the end card ("Next episode: ...") |
| `previously` | optional recap line, said by Riot after the cold open, shown under a PREVIOUSLY label |
| `beats[]` | in order. Each beat: `id` (unique), `chapter` (optional YouTube chapter title), `text` (on-screen caption; the first beat's is the hook), `location` (`campfire`, `living_room_day`, `living_room_night`, `game_show`, `village_night`, `party_room`, `car` — car is vertical only), `cast` ({who: costume or null}; Riot must be in every beat; costumes: hoodie, mafia, dare, coach, host), `camera` (`wide`, `close:<who>`, `two:<who>,<who>`), `mood` (`normal` chill bed, `tense` suspense bed, `party` hype bed + confetti), `sfx` (names from `mix.py` SOUNDS, `"popper@1.5"` = 1.5 s into the beat), `formats`, `hold` (frames after the last line) |
| `lines[]` | `who`, `say`, and optionally `do` (take, laugh, cheer, nervous, yell, shrug, facepalm, wave, thumbs, present, hop, double_take, point, munch), `face` (an expression), `look`/`target` (who to face/point at), `camera` (cut before the line), `pause` (frames before it) |
| `game` | a real game moment, played with the app's props. `{"type": "nhie", "prompt", "target", "confess"}`, `{"type": "mlt", "prompt", "target"}`, `{"type": "td", "player", "choice": "dare"/"truth", "prompt", "perform"}`, `{"type": "alias", "describer", "guesser", "word", "clue", "guess"}`; all take `after` (follow-up lines; the camera goes to each speaker unless the line sets `camera`) and `laugh` (default true: group laugh + confetti). Prompts must be real app prompts. |
| `prop` | shown for the whole beat: `{"type": "prompt_card", "game", "text"}`, `td_card`, `td_choice`, `timer`, `phone` |
| `after[]` | lines after the game (same shape as `lines`) |

**Full example** (`templates/examples/campfire-confessions/ep01.json`, shortened to two beats):
```json
{
  "series": "Campfire Confessions", "episode": 1, "title": "One Time",
  "previously": "Bash's Halloween costume was... a tomato.", "next": "Bash Tries to Win",
  "beats": [
    {"id": "open", "chapter": "Cold open", "text": "rocco said \"one time\"\nit was never one time",
     "location": "campfire", "camera": "wide", "mood": "normal",
     "lines": [{"who": "riot", "say": "Welcome to Campfire Confessions!", "do": "wave", "face": "hype"},
               {"who": "rocco", "say": "Mm... marshmallows.", "do": "munch"}]},
    {"id": "round2", "chapter": "Round 2: Rocco", "location": "campfire", "mood": "tense",
     "game": {"type": "nhie", "prompt": "Never have I ever forgotten someone's name mid-conversation.",
              "target": "rocco", "confess": "Mm... one time.",
              "after": [{"who": "pip", "say": "You called me Snack for a WEEK!", "do": "yell", "target": "rocco"}]}},
    {"id": "rules", "chapter": "How it works", "formats": ["horizontal"], "camera": "close:riot",
     "lines": [{"who": "riot", "say": "I read a card. If you've done it, you confess.", "do": "present"}]}
  ]
}
```

## 6. Instagram carousels and story images (`carousel.py`)
```bash
python3 templates/carousel.py ../marketing/carousels/wyr-sample.json             # all slides + contact.png
python3 templates/carousel.py ../marketing/carousels/wyr-sample.json --preview 3 # just slide 3
```
- One headless Blender run draws every slide's set and cast (code-drawn cast), then Pillow adds the text and the app's sticker card above the faces Blender reports back. 6 slides take ~30 s.
- Output: `videos/carousels/<name>/01.png …`, `contact.png`, `layout.json` (face boxes, layout problems). `--name` overrides the JSON name, `--out DIR` the folder.
- `"kind": "carousel"` = 1080×1350; the **last slide is always Riot + "Friendzy — link in bio"** (added if missing). `"kind": "story"` = 1080×1920 with the top 220 px text-free and the **bottom 640 px empty for the poll sticker**.
- It exits 1 with a warning on text over a face, overlapping faces, text in the 60 px margin or anything in the poll zone.
- Real prompts only (`Friendzy/Models/*.swift`), family-friendly (`prompts.py` AVOID). WYR cards are written like the app: `"option 1\nOR\noption 2"`.

| Slide field | Values |
|---|---|
| `text` | headline (Boogaloo); `*word*` = Electric Yellow; `\n` forces a break |
| `sub` | optional smaller yellow line |
| `riot` | `pose` (idle, point, wave, cheer, thumbs, shrug, crossed, facepalm, present, explain, mic), `expr`, `costume` (hoodie, mafia, dare, coach, host) |
| `friends` | up to 2 `{"who": "pip"\|"bash"\|"rocco", "expr", "pose"}`, always smaller than Riot |
| `background` | `living_room_day`, `living_room_night`, `campfire`, `car`, `orange`, `offblack` |
| `card` | optional `{"game": "wyr"\|"nhie"\|"mlt"\|"truth"\|"dare"\|…, "text": "real app prompt"}` |
| `end` | `true` marks the end slide |

Example (`marketing/carousels/wyr-story-sample.json`):
```json
{"kind": "story", "name": "wyr-story-sample", "slides": [
  {"text": "Would you *rather?*", "background": "living_room_day",
   "riot": {"pose": "present", "expr": "drumroll"}, "friends": [{"who": "rocco", "expr": "laughing"}],
   "card": {"game": "wyr", "text": "Have a super loud laugh you can't control\nOR\nHave a super weird sneeze you can't control"}}]}
```

## 7. GIPHY stickers (`sticker.py`)
```bash
python3 templates/sticker.py hype            # or laughing | shocked | drumroll | waving | all
python3 templates/sticker.py laughing --costume dare --seconds 2 --size 480 --name riot_laugh_dare
```
- Seamless 1–3 s loops of Riot (default 2 s) from `motion.py` moves, transparent background.
- Output in `videos/stickers/<name>/`: `<name>.gif` (transparent, one palette, no dithering), `<name>.webm` (VP9 with alpha), `frames/*.png` (RGBA, cropped tight), `preview.png`. Both files stay under 8 MB automatically; a 2 s sticker is ~1.5 MB GIF + ~0.2 MB WebM and takes ~25 s.
- Each run prints `LOOPCHECK`: frame N must equal frame 0. To add a sticker: an entry in `STICKERS` and a branch in `blender_main`, every channel a function of `frame % N`.

## 7b. App feature beats (`feature` template + episode `"game": {"type": "feature"}`)
A character holds up the phone and its screen is a **real app screenshot**, then it fills the frame. Never invent UI:
the screenshots are the App Store captures (made by `FriendzyUITests/StoreScreenshotsUITests` and the `PartyRoomUITests`
screenshot mode), copied into `characters/refs/app/` and mapped in `templates/features.py`. A feature with no
screenshot refuses to render until one is captured.

| Feature | Key | Screenshot (`characters/refs/app/`) | From |
|---|---|---|---|
| Party rooms (every phone joins with a code) | `rooms` | `rooms_lobby.png` (ROOM CODE DNTX) | app-store-assets/src/en-iphone-rooms/comeback-lobby.png |
| Tonight's Pack | `tonight` | `tonights_pack.png` | en-iphone/K-tonight.png |
| Road Trip mode | `roadtrip` | `road_trip.png` | en-iphone/K2-roadtrip.png |
| 44 classic games | `classics` | `classic_games.png` | en-iphone/I-rules.png |
| Room results podium | `podium` | `room_podium.png` | en-iphone-rooms/comeback-podium.png |
| Spanish | `spanish` | `spanish_home.png` | es-iphone-rooms/A-home.png |
| Crew / game-night recap | `recap` | — not captured yet | |
| Share-an-answer card | `share` | — not captured yet | |
| Seasonal packs | `seasonal` | — not captured yet (ContentPackUITests can capture the Halloween pack) | |

```bash
python3 make.py feature --prompt rooms --name feature_rooms_01 [--format horizontal]
```
In an episode: `{"id": "rooms", "game": {"type": "feature", "feature": "rooms", "who": "riot", "say": "One code, every phone joins."}}`
(no group laugh unless `"laugh": true`). Lines per feature for the template: `feature_script.SPOTS`.

## 7c. Thumbnails and covers (`thumbnail.py`)
```bash
python3 make.py <template> ... --thumbnail --cover        # with a render (horizontal episodes always get a thumbnail)
python3 templates/thumbnail.py videos/<name> [--cover] [--text "ONE TIME?!"]   # any finished video, no re-render
```
- Thumbnail: 1280×720 `<name>_thumb.png` next to the mp4: an expressive close-up of 1–2 characters on the video's set, 2–4 words of big Boogaloo (the episode JSON's `thumb_text`, else its title / the game's name), a small FRIENDZY mark top-right, the bottom-right timestamp corner left empty.
- Cover: 1080×1920 `<name>_cover.png` for Shorts/Reels/TikTok, text and faces clear of the top 220 px, bottom 440 px and the right-hand buttons.
- Episode JSON can choose the shot: `"thumb_text": "ONE TIME?!", "thumb": {"location": "campfire", "cast": [{"who": "rocco", "expr": "cocky"}, {"who": "riot", "expr": "shocked", "pose": "point"}]}`.

## 7d. Render the week (`render_week.py`)
```bash
python3 templates/render_week.py ../marketing/weekly/<monday>_renders.json --dry-run   # jobs, skips, estimated minutes
python3 templates/render_week.py ../marketing/weekly/<monday>_renders.json             # render (add --force to redo passed ones)
```
Runs the jobs in order, skips anything already rendered with QA passed (or an image that exists), keeps going after a
failure, prints a table (item, file, length, QA, render time) and writes it to `<monday>_renders.txt`. A video's
`thumbnail`/`cover` (and every horizontal episode's thumbnail) run as their own follow-up jobs. Sample:
`marketing/weekly/_sample_renders.json`.

| Job type | Fields |
|---|---|
| `video` | `template`, `name` (required, so reruns can skip it), any `make.py` flag: `prompt`, `target`, `hook`, `confess`, `format`; `voices_from` (A/B: reuse hook A's voices), `reuse_voices`, `thumbnail`, `cover`, `thumb_text` |
| `episode` | `script` (episode JSON), `format`, optional `name`, `jobs` (default 4) |
| `carousel` / `story` | `json` (slides JSON), optional `name` |
| `thumbnail` / `cover` | `video` (the video's folder name), optional `text` |
| `sticker` | `expr`, optional `costume`, `name` |

```json
{"week": "2026-11-02", "jobs": [
  {"id": "short A", "type": "video", "template": "nhie", "name": "nhie_pip_02", "prompt": "Never have I ever ...", "target": "pip", "hook": "line one\nline two", "cover": true},
  {"id": "short B", "type": "video", "template": "nhie", "name": "nhie_pip_02_b", "voices_from": "nhie_pip_02", "prompt": "Never have I ever ...", "target": "pip", "hook": "other hook"},
  {"id": "16:9 cut", "type": "video", "template": "mafia", "name": "mafia_quiet_02_h", "format": "horizontal"},
  {"id": "carousel", "type": "carousel", "json": "marketing/carousels/wyr-02.json"},
  {"id": "sticker", "type": "sticker", "expr": "hype", "costume": "dare"}]}
```

## 8. Layout for both formats
`characters/layout.py`: `F = layout.from_cfg(cfg)`, then `F.setup(sc, bg)`, `F.camera(sc, *F.default_cam(loc))`.
- The camera's ortho is always the frame **height**; the HUD layer is built at ortho 22.
- Place things by fraction of the frame (`F.hud_xy(fx, fy)`, `F.eye_framing(x, eye_y, ortho, fy)`), not 1920-pixel maths.
- For 16:9, call `locations.widen(loc)` first (every set: campfire, living room, game show, village, party room, car): it extends the set sideways, swaps the vignette and sets `loc.cam_h`.
- `props.end_card(..., fmt=F.fmt)` and `props.word_captions(..., fmt=F.fmt, y_frac=..., size=1.45 * F.text_scale)` have 16:9 layouts.
- 16:9 text: scale HUD text by `F.text_scale` (1.5): the same fraction of frame height reads ~1.8x smaller on a sideways phone. Pin the hook and cards to the camera layer so they don't drift.
- 16:9 framing: `widen()` spreads the seats (`SPREAD` 5.2) so there are gaps between characters; wide shots fill ~60% of the height; use `F.clean_close(loc, seat, ortho)` for close-ups, which moves/zooms until neither frame edge cuts a body (in practice: the target plus whole neighbours).
- To add horizontal to a template: put `FORMATS = ("vertical", "horizontal")` in its script and give the scene a 16:9 branch (see `nhie_scene.py`), keeping the vertical numbers as they are.

## 9. Adding a new format
Copy `templates/mlt_script.py` and `templates/mlt_scene.py`.
- **The script file** holds the lines plus a `timeline()` that returns the frame cues, sound effects and music.
- **The scene file** seats the cast in a set, adds `motion` moves, `talk()`, props, captions and the camera.
- **Then** run `make.py <name> --stills ...` to check it.
